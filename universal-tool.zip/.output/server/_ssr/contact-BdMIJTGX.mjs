import { o as __toESM } from "../_runtime.mjs";
import { nt as require_react } from "../_libs/@hookform/resolvers+[...].mjs";
import { r as require_jsx_runtime } from "../_libs/react+tanstack__react-query.mjs";
import { n as Layout, t as CopyInline } from "./Layout-8Jn4q3kq.mjs";
import { t as Reveal } from "./Reveal-CydLpVW7.mjs";
import { n as string, t as object } from "../_libs/zod.mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/contact-BdMIJTGX.js
var import_react = /* @__PURE__ */ __toESM(require_react());
var import_jsx_runtime = require_jsx_runtime();
var EMAIL = "prashantnadar2223@gmail.com";
var PHONE_DISPLAY = "+91 96533 86506";
var PHONE_TEL = "+919653386506";
var emailRegex = /^[A-Za-z0-9._%+-]+@[A-Za-z0-9.-]+\.[A-Za-z]{2,}$/;
var hasLetter = /[A-Za-z]/;
var contactSchema = object({
	name: string().min(1, "Name is required").max(50, "Name must be 50 characters or less").regex(/^[A-Za-z]+(?: [A-Za-z]+)*$/, "Only letters and spaces between words are allowed"),
	email: string().trim().min(1, "Email is required").max(50, "Email must be 50 characters or less").regex(emailRegex, "Enter a valid email address"),
	subject: string().trim().min(10, "Subject must be at least 10 characters").max(100, "Subject must be 100 characters or less").regex(hasLetter, "Subject can't be only numbers or symbols"),
	message: string().trim().min(20, "Message must be at least 20 characters").max(500, "Message must be 500 characters or less").regex(hasLetter, "Message can't be only numbers or symbols")
});
function Contact() {
	const [errors, setErrors] = (0, import_react.useState)({});
	const [status, setStatus] = (0, import_react.useState)("");
	const onSubmit = (e) => {
		e.preventDefault();
		const data = new FormData(e.currentTarget);
		const parsed = contactSchema.safeParse({
			name: data.get("name"),
			email: data.get("email"),
			subject: data.get("subject"),
			message: data.get("message")
		});
		if (!parsed.success) {
			const errs = {};
			for (const issue of parsed.error.issues) {
				const k = issue.path[0];
				if (k && !errs[k]) errs[k] = issue.message;
			}
			setErrors(errs);
			setStatus("Please fix the highlighted fields.");
			return;
		}
		setErrors({});
		const { name, email, subject, message } = parsed.data;
		const body = `Hi Prashant,\n\n${message}\n\n— ${name}\nReply-to: ${email}`;
		const url = `mailto:${EMAIL}?subject=${encodeURIComponent(`[UniversalTools] ${subject}`)}&body=${encodeURIComponent(body)}`;
		setStatus("Opening your email app…");
		window.location.href = url;
	};
	const fieldCls = (err) => `mt-1 w-full rounded-lg border bg-white px-3 py-2 text-sm outline-none focus:ring-2 focus:ring-blue-500/20 dark:bg-slate-950 dark:text-white ${err ? "border-red-500 focus:border-red-500" : "border-slate-200 focus:border-blue-500 dark:border-slate-700"}`;
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Layout, { children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("section", {
		className: "mx-auto max-w-2xl px-4 py-20 sm:px-6",
		children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Reveal, { children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h1", {
				className: "text-4xl font-bold text-slate-900 sm:text-5xl dark:text-white",
				style: { fontFamily: "'Space Grotesk', sans-serif" },
				children: "Get in touch"
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
				className: "mt-3 text-slate-600 dark:text-slate-400",
				children: "Questions, ideas, bug reports — we read everything."
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "mt-4 space-y-2 text-sm text-slate-700 dark:text-slate-300",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
					className: "flex flex-wrap items-center gap-2",
					children: [
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
							className: "font-medium",
							children: "Email:"
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("a", {
							href: `mailto:${EMAIL}?subject=UniversalTools%20Inquiry`,
							className: "text-blue-600 hover:underline dark:text-blue-400",
							children: EMAIL
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)(CopyInline, {
							value: EMAIL,
							label: "email"
						})
					]
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
					className: "flex flex-wrap items-center gap-2",
					children: [
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
							className: "font-medium",
							children: "Phone:"
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("a", {
							href: `tel:${PHONE_TEL}`,
							className: "text-blue-600 hover:underline dark:text-blue-400",
							children: PHONE_DISPLAY
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)(CopyInline, {
							value: PHONE_DISPLAY,
							label: "phone number"
						})
					]
				})]
			})
		] }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Reveal, {
			delay: .1,
			children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("form", {
				onSubmit,
				noValidate: true,
				className: "mt-10 space-y-4 rounded-2xl border border-slate-200 bg-white p-6 shadow-sm dark:border-slate-800 dark:bg-slate-900",
				children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("label", {
							htmlFor: "name",
							className: "block text-sm font-medium text-slate-700 dark:text-slate-200",
							children: ["Name", /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
								"aria-hidden": true,
								className: "text-red-500",
								children: " *"
							})]
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
							id: "name",
							name: "name",
							required: true,
							maxLength: 50,
							"aria-invalid": !!errors.name,
							"aria-describedby": errors.name ? "name-err" : void 0,
							className: fieldCls(errors.name)
						}),
						errors.name && /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
							id: "name-err",
							className: "mt-1 text-xs text-red-600",
							children: errors.name
						})
					] }),
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("label", {
							htmlFor: "email",
							className: "block text-sm font-medium text-slate-700 dark:text-slate-200",
							children: ["Email", /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
								"aria-hidden": true,
								className: "text-red-500",
								children: " *"
							})]
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
							id: "email",
							name: "email",
							type: "email",
							required: true,
							maxLength: 50,
							"aria-invalid": !!errors.email,
							"aria-describedby": errors.email ? "email-err" : void 0,
							className: fieldCls(errors.email)
						}),
						errors.email && /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
							id: "email-err",
							className: "mt-1 text-xs text-red-600",
							children: errors.email
						})
					] }),
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("label", {
							htmlFor: "subject",
							className: "block text-sm font-medium text-slate-700 dark:text-slate-200",
							children: ["Subject", /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
								"aria-hidden": true,
								className: "text-red-500",
								children: " *"
							})]
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
							id: "subject",
							name: "subject",
							required: true,
							minLength: 10,
							maxLength: 100,
							"aria-invalid": !!errors.subject,
							"aria-describedby": errors.subject ? "subject-err" : void 0,
							className: fieldCls(errors.subject)
						}),
						errors.subject && /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
							id: "subject-err",
							className: "mt-1 text-xs text-red-600",
							children: errors.subject
						})
					] }),
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("label", {
							htmlFor: "msg",
							className: "block text-sm font-medium text-slate-700 dark:text-slate-200",
							children: ["Message", /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
								"aria-hidden": true,
								className: "text-red-500",
								children: " *"
							})]
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("textarea", {
							id: "msg",
							name: "message",
							required: true,
							minLength: 20,
							maxLength: 500,
							rows: 5,
							"aria-invalid": !!errors.message,
							"aria-describedby": errors.message ? "msg-err" : void 0,
							className: fieldCls(errors.message)
						}),
						errors.message && /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
							id: "msg-err",
							className: "mt-1 text-xs text-red-600",
							children: errors.message
						})
					] }),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
						type: "submit",
						className: "w-full rounded-lg bg-blue-600 px-4 py-2.5 font-semibold text-white shadow-sm shadow-blue-600/30 transition hover:bg-blue-700",
						children: "Send message"
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
						role: "status",
						"aria-live": "polite",
						className: "min-h-[1.25rem] text-sm text-slate-600 dark:text-slate-400",
						children: status
					})
				]
			})
		})]
	}) });
}
//#endregion
export { Contact as component };
