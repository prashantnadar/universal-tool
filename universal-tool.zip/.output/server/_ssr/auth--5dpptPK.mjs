import { o as __toESM } from "../_runtime.mjs";
import { n as useForm, nt as require_react, t as u } from "../_libs/@hookform/resolvers+[...].mjs";
import { t as supabase } from "./client-CxWkeBjE.mjs";
import { g as Link, v as useNavigate, y as useSearch } from "../_libs/@tanstack/react-router+[...].mjs";
import { r as require_jsx_runtime } from "../_libs/react+tanstack__react-query.mjs";
import { r as useAuth } from "./auth-context-DS3dl-5u.mjs";
import { n as toast } from "../_libs/sonner.mjs";
import { n as Layout } from "./Layout-8Jn4q3kq.mjs";
import { n as string, t as object } from "../_libs/zod.mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/auth--5dpptPK.js
var import_react = /* @__PURE__ */ __toESM(require_react());
var import_jsx_runtime = require_jsx_runtime();
var emailSchema = string().trim().min(1, "Email is required").max(50, "Email must be 50 characters or less").regex(/^[A-Za-z0-9._%+-]+@[A-Za-z0-9.-]+\.[A-Za-z]{2,}$/, "Enter a valid email address");
var nameSchema = string().trim().min(1, "Name is required").max(50, "Name must be 50 characters or less").regex(/^[A-Za-z]+(?: [A-Za-z]+)*$/, "Only letters and spaces between words are allowed");
var signInSchema = object({
	email: emailSchema,
	password: string().min(8, "At least 8 characters").max(20, "At most 20 characters").regex(/[a-z]/, "Must include a lowercase letter").regex(/[A-Z]/, "Must include an uppercase letter").regex(/[0-9]/, "Must include a number").regex(/[^A-Za-z0-9]/, "Must include a special character")
});
var signUpSchema = signInSchema.extend({ display_name: nameSchema });
var forgotSchema = object({ email: emailSchema });
function safeRedirect(target) {
	if (!target) return "/dashboard";
	try {
		if (target.startsWith("/") && !target.startsWith("//")) return target;
	} catch {}
	return "/dashboard";
}
function AuthPage() {
	const { mode = "signin", redirect } = useSearch({ from: "/auth" });
	const navigate = useNavigate();
	const { isAuthenticated, loading } = useAuth();
	const [googleBusy, setGoogleBusy] = (0, import_react.useState)(false);
	const to = safeRedirect(redirect);
	(0, import_react.useEffect)(() => {
		if (!loading && isAuthenticated) navigate({
			to,
			replace: true
		});
	}, [
		loading,
		isAuthenticated,
		navigate,
		to
	]);
	const handleGoogle = async () => {
		setGoogleBusy(true);
		try {
			const { error } = await supabase.auth.signInWithOAuth({
				provider: "google",
				options: { redirectTo: `${window.location.origin}/auth` }
			});
			if (error) {
				toast.error("Google sign-in failed");
				setGoogleBusy(false);
				return;
			}
		} catch {
			toast.error("Google sign-in failed");
			setGoogleBusy(false);
		}
	};
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Layout, { children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("section", {
		className: "mx-auto grid min-h-[80vh] max-w-md place-items-center px-4 py-12 sm:px-6",
		children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
			className: "w-full rounded-2xl border border-slate-200 bg-white p-8 shadow-xl shadow-blue-900/5 dark:border-slate-800 dark:bg-slate-900",
			children: [
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
					className: "mb-6 flex gap-2 rounded-lg bg-slate-100 p-1 text-sm dark:bg-slate-800",
					role: "tablist",
					children: ["signin", "signup"].map((m) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Link, {
						to: "/auth",
						search: {
							mode: m,
							redirect
						},
						role: "tab",
						"aria-selected": mode === m,
						className: `flex-1 rounded-md px-3 py-1.5 text-center font-medium transition ${mode === m ? "bg-white text-blue-700 shadow-sm dark:bg-slate-950 dark:text-blue-300" : "text-slate-600 dark:text-slate-300"}`,
						children: m === "signin" ? "Log in" : "Sign up"
					}, m))
				}),
				mode === "forgot" ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)(ForgotForm, {}) : mode === "signup" ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)(SignUpForm, { to }, "signup") : /* @__PURE__ */ (0, import_jsx_runtime.jsx)(SignInForm, { to }, "signin"),
				/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "my-5 flex items-center gap-3 text-xs text-slate-400",
					children: [
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", { className: "h-px flex-1 bg-slate-200 dark:bg-slate-700" }),
						"or",
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", { className: "h-px flex-1 bg-slate-200 dark:bg-slate-700" })
					]
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("button", {
					type: "button",
					onClick: handleGoogle,
					disabled: googleBusy,
					className: "inline-flex w-full items-center justify-center gap-2 rounded-lg border border-slate-200 bg-white px-4 py-2.5 text-sm font-semibold text-slate-700 shadow-sm transition hover:bg-slate-50 disabled:opacity-60 dark:border-slate-700 dark:bg-slate-950 dark:text-white dark:hover:bg-slate-900",
					"aria-label": "Continue with Google",
					title: "Continue with Google",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("svg", {
						viewBox: "0 0 24 24",
						className: "h-4 w-4",
						"aria-hidden": "true",
						children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("path", {
							fill: "#EA4335",
							d: "M12 10.2v3.9h5.5c-.24 1.4-1.7 4.1-5.5 4.1-3.3 0-6-2.7-6-6.1s2.7-6.1 6-6.1c1.9 0 3.1.8 3.8 1.5l2.6-2.5C16.8 3.5 14.6 2.5 12 2.5 6.8 2.5 2.6 6.7 2.6 12s4.2 9.5 9.4 9.5c5.4 0 9-3.8 9-9.2 0-.6-.07-1.1-.16-1.6H12z"
						})
					}), googleBusy ? "Connecting…" : "Continue with Google"]
				}),
				mode !== "forgot" && /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
					className: "mt-4 text-center text-xs text-slate-500 dark:text-slate-400",
					children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Link, {
						to: "/auth",
						search: { mode: "forgot" },
						className: "hover:text-blue-600",
						children: "Forgot password?"
					})
				})
			]
		})
	}) });
}
function PasswordInput({ id, autoComplete, register }) {
	const [show, setShow] = (0, import_react.useState)(false);
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "relative",
		children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
			id,
			type: show ? "text" : "password",
			autoComplete,
			maxLength: 20,
			...register(id),
			className: inputCls + " pr-10"
		}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
			type: "button",
			onClick: () => setShow((s) => !s),
			"aria-label": show ? "Hide password" : "Show password",
			className: "absolute right-2 top-1/2 -translate-y-1/2 rounded p-1 text-slate-500 hover:text-slate-800 dark:hover:text-white",
			children: show ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("svg", {
				width: "18",
				height: "18",
				viewBox: "0 0 24 24",
				fill: "none",
				stroke: "currentColor",
				strokeWidth: "2",
				children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("path", { d: "M17.94 17.94A10.94 10.94 0 0 1 12 20c-7 0-11-8-11-8a19.8 19.8 0 0 1 5.06-5.94M9.9 4.24A10.94 10.94 0 0 1 12 4c7 0 11 8 11 8a19.8 19.8 0 0 1-4.2 5.19M1 1l22 22M9.88 9.88a3 3 0 1 0 4.24 4.24" })
			}) : /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("svg", {
				width: "18",
				height: "18",
				viewBox: "0 0 24 24",
				fill: "none",
				stroke: "currentColor",
				strokeWidth: "2",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("path", { d: "M1 12s4-8 11-8 11 8 11 8-4 8-11 8S1 12 1 12z" }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("circle", {
					cx: "12",
					cy: "12",
					r: "3"
				})]
			})
		})]
	});
}
function SignInForm({ to }) {
	useNavigate();
	const { register, handleSubmit, reset, formState: { errors, isSubmitting } } = useForm({
		resolver: u(signInSchema),
		defaultValues: {
			email: "",
			password: ""
		}
	});
	const onSubmit = async (values) => {
		const { error } = await supabase.auth.signInWithPassword({
			email: values.email,
			password: values.password
		});
		if (error) {
			toast.error(error.message || "Sign-in failed");
			return;
		}
		reset({
			email: "",
			password: ""
		});
		toast.success("Signed in");
	};
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("form", {
		onSubmit: handleSubmit(onSubmit),
		className: "space-y-4",
		noValidate: true,
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h1", {
				className: "text-2xl font-bold text-slate-900 dark:text-white",
				style: { fontFamily: "'Space Grotesk', sans-serif" },
				children: "Welcome back"
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Field, {
				label: "Email",
				htmlFor: "email",
				error: errors.email?.message,
				children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
					id: "email",
					type: "email",
					autoComplete: "email",
					maxLength: 50,
					...register("email"),
					className: inputCls
				})
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Field, {
				label: "Password",
				htmlFor: "password",
				error: errors.password?.message,
				children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(PasswordInput, {
					id: "password",
					autoComplete: "current-password",
					register
				})
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
				type: "submit",
				disabled: isSubmitting,
				className: btnPrimary,
				children: isSubmitting ? "Signing in…" : "Log in"
			})
		]
	});
}
function SignUpForm({ to }) {
	useNavigate();
	const { register, handleSubmit, reset, formState: { errors, isSubmitting } } = useForm({
		resolver: u(signUpSchema),
		defaultValues: {
			email: "",
			password: "",
			display_name: ""
		}
	});
	const onSubmit = async (values) => {
		const { error } = await supabase.auth.signUp({
			email: values.email,
			password: values.password,
			options: {
				emailRedirectTo: `${window.location.origin}/auth`,
				data: { display_name: values.display_name }
			}
		});
		if (error) {
			toast.error(error.message || "Sign-up failed");
			return;
		}
		reset({
			email: "",
			password: "",
			display_name: ""
		});
		toast.success("Account created");
	};
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("form", {
		onSubmit: handleSubmit(onSubmit),
		className: "space-y-4",
		noValidate: true,
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h1", {
				className: "text-2xl font-bold text-slate-900 dark:text-white",
				style: { fontFamily: "'Space Grotesk', sans-serif" },
				children: "Create your account"
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Field, {
				label: "Name",
				htmlFor: "display_name",
				error: errors.display_name?.message,
				children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
					id: "display_name",
					autoComplete: "name",
					maxLength: 50,
					...register("display_name"),
					className: inputCls
				})
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Field, {
				label: "Email",
				htmlFor: "email",
				error: errors.email?.message,
				children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
					id: "email",
					type: "email",
					autoComplete: "email",
					maxLength: 50,
					...register("email"),
					className: inputCls
				})
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Field, {
				label: "Password",
				htmlFor: "password",
				error: errors.password?.message,
				children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(PasswordInput, {
					id: "password",
					autoComplete: "new-password",
					register
				})
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
				className: "text-xs text-slate-500 dark:text-slate-400",
				children: "8–20 chars with uppercase, lowercase, number & special character."
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
				type: "submit",
				disabled: isSubmitting,
				className: btnPrimary,
				children: isSubmitting ? "Creating account…" : "Sign up"
			})
		]
	});
}
function ForgotForm() {
	const [sent, setSent] = (0, import_react.useState)(false);
	const { register, handleSubmit, formState: { errors, isSubmitting } } = useForm({
		resolver: u(forgotSchema),
		defaultValues: { email: "" }
	});
	const onSubmit = async (values) => {
		const { error } = await supabase.auth.resetPasswordForEmail(values.email, { redirectTo: `${window.location.origin}/reset-password` });
		if (error) {
			toast.error(error.message || "Could not send reset email");
			return;
		}
		setSent(true);
		toast.success("Password reset email sent");
	};
	if (sent) return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "space-y-4 text-center",
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h1", {
				className: "text-2xl font-bold text-slate-900 dark:text-white",
				children: "Check your email"
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
				className: "text-sm text-slate-600 dark:text-slate-400",
				children: "We sent a reset link. It expires in 1 hour."
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Link, {
				to: "/auth",
				className: "inline-block text-sm font-semibold text-blue-600",
				children: "Back to sign in"
			})
		]
	});
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("form", {
		onSubmit: handleSubmit(onSubmit),
		className: "space-y-4",
		noValidate: true,
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h1", {
				className: "text-2xl font-bold text-slate-900 dark:text-white",
				children: "Reset password"
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
				className: "text-sm text-slate-600 dark:text-slate-400",
				children: "Enter your account email and we'll send you a link."
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Field, {
				label: "Email",
				htmlFor: "email",
				error: errors.email?.message,
				children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
					id: "email",
					type: "email",
					autoComplete: "email",
					maxLength: 50,
					...register("email"),
					className: inputCls
				})
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
				type: "submit",
				disabled: isSubmitting,
				className: btnPrimary,
				children: isSubmitting ? "Sending…" : "Send reset link"
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
				className: "text-center",
				children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Link, {
					to: "/auth",
					className: "text-xs text-slate-500 hover:text-blue-600",
					children: "Back to sign in"
				})
			})
		]
	});
}
var inputCls = "mt-1 w-full rounded-lg border border-slate-200 bg-white px-3 py-2 text-sm outline-none focus:border-blue-500 focus:ring-2 focus:ring-blue-500/20 dark:border-slate-700 dark:bg-slate-950 dark:text-white";
var btnPrimary = "inline-flex w-full items-center justify-center rounded-lg bg-blue-600 px-4 py-2.5 text-sm font-semibold text-white shadow-sm transition hover:bg-blue-700 disabled:opacity-60";
function Field({ label, htmlFor, error, children }) {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [
		/* @__PURE__ */ (0, import_jsx_runtime.jsx)("label", {
			htmlFor,
			className: "block text-sm font-medium text-slate-700 dark:text-slate-200",
			children: label
		}),
		children,
		error && /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
			className: "mt-1 text-xs text-red-600",
			"aria-live": "polite",
			children: error
		})
	] });
}
//#endregion
export { AuthPage as component };
