//#region node_modules/.nitro/vite/services/ssr/assets/pdf.worker.min-Be_rUMwQ.js
var pdf_worker_min_default = "/assets/pdf.worker.min-DEtVeC4l.mjs";
//#endregion
export { pdf_worker_min_default as default };
