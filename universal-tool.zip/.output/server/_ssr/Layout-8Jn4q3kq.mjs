import { o as __toESM } from "../_runtime.mjs";
import { nt as require_react } from "../_libs/@hookform/resolvers+[...].mjs";
import { t as supabase } from "./client-CxWkeBjE.mjs";
import { g as Link, l as useRouterState, v as useNavigate } from "../_libs/@tanstack/react-router+[...].mjs";
import { r as require_jsx_runtime } from "../_libs/react+tanstack__react-query.mjs";
import { i as useTheme, r as useAuth } from "./auth-context-DS3dl-5u.mjs";
import { n as toast } from "../_libs/sonner.mjs";
import { n as AnimatePresence, t as motion } from "../_libs/framer-motion.mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/Layout-8Jn4q3kq.js
var import_react = /* @__PURE__ */ __toESM(require_react());
var import_jsx_runtime = require_jsx_runtime();
function Logo({ className = "" }) {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Link, {
		to: "/",
		className: `flex items-center gap-2 ${className}`,
		"aria-label": "Universal Tools home",
		children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
			"aria-hidden": "true",
			className: "grid h-9 w-9 place-items-center rounded-xl bg-gradient-to-br from-blue-600 to-blue-400 text-white font-bold shadow-md shadow-blue-500/30",
			style: { fontFamily: "'Space Grotesk', sans-serif" },
			children: "UT"
		}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", {
			className: "hidden sm:inline text-lg font-bold tracking-tight text-slate-900 dark:text-white",
			style: { fontFamily: "'Space Grotesk', sans-serif" },
			children: ["Universal", /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
				className: "text-blue-600 dark:text-blue-400",
				children: "Tools"
			})]
		})]
	});
}
var TOOLS = [
	{
		id: "word-count",
		name: "Word Counter",
		description: "Count words instantly",
		category: "text",
		keywords: ["words", "count"],
		route: "/tools/text#word-count"
	},
	{
		id: "char-count",
		name: "Character Counter",
		description: "Count characters with & without spaces",
		category: "text",
		keywords: ["chars", "letters"],
		route: "/tools/text#word-count"
	},
	{
		id: "read-time",
		name: "Reading Time",
		description: "Estimate reading time",
		category: "text",
		keywords: ["minutes", "read"],
		route: "/tools/text#word-count"
	},
	{
		id: "uppercase",
		name: "UPPERCASE",
		description: "Convert text to upper case",
		category: "text",
		keywords: ["caps"],
		route: "/tools/text#transform"
	},
	{
		id: "lowercase",
		name: "lowercase",
		description: "Convert text to lower case",
		category: "text",
		keywords: [],
		route: "/tools/text#transform"
	},
	{
		id: "title-case",
		name: "Title Case",
		description: "Capitalize Each Word",
		category: "text",
		keywords: [],
		route: "/tools/text#transform"
	},
	{
		id: "sentence-case",
		name: "Sentence case",
		description: "Capitalize sentences",
		category: "text",
		keywords: [],
		route: "/tools/text#transform"
	},
	{
		id: "reverse",
		name: "Reverse Text",
		description: "Reverse the string",
		category: "text",
		keywords: [],
		route: "/tools/text#transform"
	},
	{
		id: "trim-spaces",
		name: "Remove Extra Spaces",
		description: "Collapse multiple spaces",
		category: "text",
		keywords: ["whitespace"],
		route: "/tools/text#clean"
	},
	{
		id: "remove-special",
		name: "Remove Special Characters",
		description: "Strip non-alphanumerics",
		category: "text",
		keywords: ["punctuation"],
		route: "/tools/text#clean"
	},
	{
		id: "remove-numbers",
		name: "Remove Numbers",
		description: "Strip digits",
		category: "text",
		keywords: [],
		route: "/tools/text#clean"
	},
	{
		id: "remove-lines",
		name: "Remove Empty Lines",
		description: "Delete blank lines",
		category: "text",
		keywords: [],
		route: "/tools/text#clean"
	},
	{
		id: "base64-encode",
		name: "Base64 Encode",
		description: "Encode to base64",
		category: "text",
		keywords: ["b64"],
		route: "/tools/text#encode"
	},
	{
		id: "base64-decode",
		name: "Base64 Decode",
		description: "Decode base64",
		category: "text",
		keywords: [],
		route: "/tools/text#encode"
	},
	{
		id: "url-encode",
		name: "URL Encode / Decode",
		description: "Encode and decode URLs",
		category: "text",
		keywords: [],
		route: "/tools/text#encode"
	},
	{
		id: "slugify",
		name: "Slugify",
		description: "Make URL-friendly slug",
		category: "text",
		keywords: ["seo"],
		route: "/tools/text#encode"
	},
	{
		id: "sort-lines",
		name: "Sort Lines",
		description: "Sort alphabetically",
		category: "text",
		keywords: [],
		route: "/tools/text#lines"
	},
	{
		id: "dedupe",
		name: "Remove Duplicate Lines",
		description: "Keep unique lines",
		category: "text",
		keywords: [],
		route: "/tools/text#lines"
	},
	{
		id: "find-replace",
		name: "Find & Replace",
		description: "Find and replace text (regex supported)",
		category: "text",
		keywords: ["substitute", "regex"],
		route: "/tools/text#find-replace"
	},
	{
		id: "text-repeat",
		name: "Repeat Text",
		description: "Repeat your text N times",
		category: "text",
		keywords: ["duplicate"],
		route: "/tools/text#repeat"
	},
	{
		id: "html-strip",
		name: "Strip HTML Tags",
		description: "Remove HTML markup, keep text",
		category: "text",
		keywords: ["clean", "markup"],
		route: "/tools/text#clean"
	},
	{
		id: "word-frequency",
		name: "Word Frequency",
		description: "Count how often each word appears",
		category: "text",
		keywords: ["analyze", "stats"],
		route: "/tools/text#frequency"
	},
	{
		id: "binary-convert",
		name: "Text ↔ Binary",
		description: "Convert text to and from binary",
		category: "text",
		keywords: ["bin", "01"],
		route: "/tools/text#binary"
	},
	{
		id: "rot13",
		name: "ROT13 Cipher",
		description: "Simple ROT13 letter cipher",
		category: "text",
		keywords: ["cipher", "obfuscate"],
		route: "/tools/text#encode"
	},
	{
		id: "text-diff",
		name: "Text Compare",
		description: "See differences between two texts",
		category: "text",
		keywords: ["diff", "compare"],
		route: "/tools/text#diff"
	},
	{
		id: "pdf-merge",
		name: "Merge PDFs",
		description: "Combine multiple PDFs",
		category: "pdf",
		keywords: ["combine"],
		route: "/tools/pdf#merge"
	},
	{
		id: "pdf-split",
		name: "Split PDF",
		description: "Split into pages",
		category: "pdf",
		keywords: [],
		route: "/tools/pdf#split"
	},
	{
		id: "pdf-password",
		name: "Add Password to PDF",
		description: "Protect a PDF",
		category: "pdf",
		keywords: ["encrypt", "secure"],
		route: "/tools/pdf#password"
	},
	{
		id: "pdf-rotate",
		name: "Rotate PDF",
		description: "Rotate all pages",
		category: "pdf",
		keywords: [],
		route: "/tools/pdf#rotate"
	},
	{
		id: "pdf-reorder",
		name: "Reorder Pages",
		description: "Rearrange pages",
		category: "pdf",
		keywords: ["organize"],
		route: "/tools/pdf#reorder"
	},
	{
		id: "pdf-compress",
		name: "Compress PDF",
		description: "Basic size reduction",
		category: "pdf",
		keywords: ["shrink", "optimize"],
		route: "/tools/pdf#compress"
	},
	{
		id: "pdf-remove-pages",
		name: "Remove Pages",
		description: "Delete specific pages from a PDF",
		category: "pdf",
		keywords: ["delete"],
		route: "/tools/pdf#remove-pages"
	},
	{
		id: "pdf-extract-pages",
		name: "Extract Pages",
		description: "Save selected pages as a new PDF",
		category: "pdf",
		keywords: ["pages"],
		route: "/tools/pdf#extract-pages"
	},
	{
		id: "pdf-jpg-to-pdf",
		name: "JPG / PNG to PDF",
		description: "Convert images into a PDF",
		category: "pdf",
		keywords: ["image", "convert"],
		route: "/tools/pdf#jpg-to-pdf"
	},
	{
		id: "pdf-to-jpg",
		name: "PDF to JPG",
		description: "Export each page as a JPG image",
		category: "pdf",
		keywords: ["convert", "image"],
		route: "/tools/pdf#pdf-to-jpg"
	},
	{
		id: "pdf-page-numbers",
		name: "Add Page Numbers",
		description: "Add page numbers to PDF",
		category: "pdf",
		keywords: ["numbering"],
		route: "/tools/pdf#page-numbers"
	},
	{
		id: "pdf-watermark",
		name: "Add Watermark",
		description: "Add a text watermark to PDF",
		category: "pdf",
		keywords: ["stamp"],
		route: "/tools/pdf#watermark"
	},
	{
		id: "pdf-crop",
		name: "Crop PDF",
		description: "Crop margins from PDF pages",
		category: "pdf",
		keywords: ["trim"],
		route: "/tools/pdf#crop"
	},
	{
		id: "pdf-unlock",
		name: "Unlock PDF",
		description: "Remove password from a PDF you own",
		category: "pdf",
		keywords: ["decrypt", "remove password"],
		route: "/tools/pdf#unlock"
	},
	{
		id: "img-resize",
		name: "Resize Image",
		description: "Change dimensions",
		category: "image",
		keywords: ["scale"],
		route: "/tools/image#resize"
	},
	{
		id: "img-crop",
		name: "Crop Image",
		description: "Crop to area",
		category: "image",
		keywords: [],
		route: "/tools/image#crop"
	},
	{
		id: "img-filter",
		name: "Image Filters",
		description: "Apply grayscale, sepia, blur",
		category: "image",
		keywords: ["effects"],
		route: "/tools/image#filter"
	},
	{
		id: "img-rotate",
		name: "Rotate Image",
		description: "Rotate 90/180/270",
		category: "image",
		keywords: [],
		route: "/tools/image#rotate"
	},
	{
		id: "img-format",
		name: "Convert Format",
		description: "JPG / PNG / WebP",
		category: "image",
		keywords: ["convert"],
		route: "/tools/image#format"
	},
	{
		id: "img-metadata",
		name: "Image Metadata",
		description: "View dimensions and type",
		category: "image",
		keywords: ["exif", "info"],
		route: "/tools/image#metadata"
	},
	{
		id: "img-compress",
		name: "Compress Image",
		description: "Reduce file size with quality slider",
		category: "image",
		keywords: ["optimize", "shrink"],
		route: "/tools/image#compress"
	},
	{
		id: "img-flip",
		name: "Flip Image",
		description: "Flip horizontally or vertically",
		category: "image",
		keywords: ["mirror"],
		route: "/tools/image#flip"
	},
	{
		id: "img-watermark",
		name: "Watermark Image",
		description: "Add a text watermark to your image",
		category: "image",
		keywords: ["stamp", "brand"],
		route: "/tools/image#watermark"
	},
	{
		id: "img-to-base64",
		name: "Image to Base64",
		description: "Encode image as data URL",
		category: "image",
		keywords: ["data url", "encode"],
		route: "/tools/image#base64"
	},
	{
		id: "img-adjust",
		name: "Brightness & Contrast",
		description: "Tune brightness, contrast, saturation",
		category: "image",
		keywords: ["adjust", "tune"],
		route: "/tools/image#adjust"
	},
	{
		id: "json-format",
		name: "JSON Formatter",
		description: "Beautify JSON with indentation",
		category: "code",
		keywords: ["pretty", "beautify"],
		route: "/tools/code#json-format"
	},
	{
		id: "json-minify",
		name: "JSON Minifier",
		description: "Compact JSON output",
		category: "code",
		keywords: ["compress"],
		route: "/tools/code#json-minify"
	},
	{
		id: "xml-format",
		name: "XML Formatter",
		description: "Beautify XML / RSS",
		category: "code",
		keywords: ["pretty"],
		route: "/tools/code#xml-format"
	},
	{
		id: "html-minify",
		name: "HTML Minifier",
		description: "Strip whitespace from HTML",
		category: "code",
		keywords: ["compress"],
		route: "/tools/code#html-minify"
	},
	{
		id: "css-minify",
		name: "CSS Minifier",
		description: "Strip whitespace and comments from CSS",
		category: "code",
		keywords: [],
		route: "/tools/code#css-minify"
	},
	{
		id: "js-minify",
		name: "JS Minifier",
		description: "Basic JavaScript minification",
		category: "code",
		keywords: [],
		route: "/tools/code#js-minify"
	},
	{
		id: "sql-format",
		name: "SQL Formatter",
		description: "Format SQL queries",
		category: "code",
		keywords: ["pretty"],
		route: "/tools/code#sql-format"
	},
	{
		id: "jwt-decode",
		name: "JWT Decoder",
		description: "Decode JSON Web Token",
		category: "code",
		keywords: ["token", "auth"],
		route: "/tools/code#jwt-decode"
	},
	{
		id: "regex-test",
		name: "Regex Tester",
		description: "Test regular expressions",
		category: "code",
		keywords: ["match"],
		route: "/tools/code#regex-test"
	},
	{
		id: "uuid-gen",
		name: "UUID Generator",
		description: "Generate UUID v4s",
		category: "code",
		keywords: ["guid", "id"],
		route: "/tools/code#uuid-gen"
	},
	{
		id: "hash-gen",
		name: "Hash Generator (MD5, SHA-1, SHA-256, SHA-512)",
		description: "MD5, SHA-1, SHA-256, SHA-512 digests",
		category: "code",
		keywords: [
			"md5",
			"sha",
			"sha256",
			"sha1",
			"sha512",
			"crypto",
			"digest"
		],
		route: "/tools/code#hash-gen"
	},
	{
		id: "timestamp",
		name: "Timestamp Converter",
		description: "Unix epoch ↔ date",
		category: "code",
		keywords: ["unix", "epoch"],
		route: "/tools/code#timestamp"
	},
	{
		id: "color-convert",
		name: "HEX ↔ RGB",
		description: "Convert colors between formats",
		category: "code",
		keywords: [
			"color",
			"hex",
			"rgb"
		],
		route: "/tools/code#color-convert"
	},
	{
		id: "lorem-ipsum",
		name: "Lorem Ipsum",
		description: "Generate placeholder text",
		category: "code",
		keywords: ["placeholder"],
		route: "/tools/code#lorem-ipsum"
	},
	{
		id: "html-editor",
		name: "HTML Live Editor",
		description: "Live HTML / CSS / JS editor with preview",
		category: "code",
		keywords: [
			"playground",
			"html",
			"css",
			"js",
			"sandbox"
		],
		route: "/tools/code#html-editor"
	},
	{
		id: "markdown-html",
		name: "Markdown to HTML",
		description: "Convert Markdown to HTML on the fly",
		category: "code",
		keywords: [
			"md",
			"markdown",
			"html",
			"convert"
		],
		route: "/tools/code#markdown"
	},
	{
		id: "number-base",
		name: "Number Base Converter",
		description: "Binary, octal, decimal, hexadecimal",
		category: "code",
		keywords: [
			"binary",
			"hex",
			"octal",
			"decimal",
			"base"
		],
		route: "/tools/code#number-base"
	},
	{
		id: "php-format",
		name: "PHP Formatter",
		description: "Basic PHP source formatter",
		category: "code",
		keywords: ["php", "beautify"],
		route: "/tools/code#php-format"
	},
	{
		id: "html-format",
		name: "HTML Formatter",
		description: "Pretty-print HTML markup",
		category: "code",
		keywords: [
			"html",
			"beautify",
			"indent"
		],
		route: "/tools/code#html-format"
	},
	{
		id: "phrase-crypt",
		name: "Phrase Encrypt / Decrypt",
		description: "AES-GCM symmetric encryption with a passphrase",
		category: "code",
		keywords: [
			"aes",
			"encrypt",
			"decrypt",
			"cipher",
			"password"
		],
		route: "/tools/code#phrase-crypt"
	},
	{
		id: "browser-features",
		name: "Browser Feature Detection",
		description: "Check what APIs your browser supports",
		category: "code",
		keywords: [
			"browser",
			"feature",
			"support",
			"detect"
		],
		route: "/tools/code#browser-features"
	},
	{
		id: "js-keycodes",
		name: "JavaScript Keycode Table",
		description: "Live keycodes, key names and event codes reference",
		category: "code",
		keywords: [
			"keycode",
			"key code",
			"javascript",
			"event.key",
			"event.code",
			"keyboard"
		],
		route: "/tools/code#js-keycodes"
	},
	{
		id: "html-to-jsx",
		name: "HTML to JSX Converter",
		description: "Convert HTML markup into React JSX",
		category: "code",
		keywords: [
			"html",
			"jsx",
			"react",
			"convert",
			"className"
		],
		route: "/tools/code#html-to-jsx"
	},
	{
		id: "html-to-tsx",
		name: "HTML to TSX Converter",
		description: "Convert HTML into a typed React TSX component",
		category: "code",
		keywords: [
			"html",
			"tsx",
			"typescript",
			"react",
			"convert"
		],
		route: "/tools/code#html-to-tsx"
	},
	{
		id: "jsx-to-tsx",
		name: "JSX to TSX Converter",
		description: "Wrap JSX in a typed TSX component scaffold",
		category: "code",
		keywords: [
			"jsx",
			"tsx",
			"typescript",
			"convert",
			"react"
		],
		route: "/tools/code#jsx-to-tsx"
	},
	{
		id: "tsx-to-jsx",
		name: "TSX to JSX Converter",
		description: "Strip TypeScript annotations from TSX to plain JSX",
		category: "code",
		keywords: [
			"tsx",
			"jsx",
			"strip types",
			"convert"
		],
		route: "/tools/code#tsx-to-jsx"
	},
	{
		id: "css-to-tailwind",
		name: "CSS to Tailwind Converter",
		description: "Map plain CSS declarations to Tailwind utility classes",
		category: "code",
		keywords: [
			"css",
			"tailwind",
			"utility",
			"convert"
		],
		route: "/tools/code#css-to-tailwind"
	},
	{
		id: "tailwind-to-css",
		name: "Tailwind to CSS Converter",
		description: "Expand Tailwind utility classes back into CSS",
		category: "code",
		keywords: [
			"tailwind",
			"css",
			"convert",
			"expand"
		],
		route: "/tools/code#tailwind-to-css"
	},
	{
		id: "pw-generate",
		name: "Password Generator",
		description: "Strong passwords with custom rules",
		category: "password",
		keywords: [
			"create",
			"secure",
			"random"
		],
		route: "/tools/password#generate"
	},
	{
		id: "pw-strength",
		name: "Password Strength Meter",
		description: "Check password strength",
		category: "password",
		keywords: [
			"meter",
			"score",
			"audit"
		],
		route: "/tools/password#strength"
	},
	{
		id: "pw-passphrase",
		name: "Passphrase Generator",
		description: "Memorable word-based passwords",
		category: "password",
		keywords: ["words", "diceware"],
		route: "/tools/password#passphrase"
	},
	{
		id: "pw-pin",
		name: "PIN Generator",
		description: "Generate numeric PINs",
		category: "password",
		keywords: ["numeric"],
		route: "/tools/password#pin"
	},
	{
		id: "color-picker",
		name: "Color Picker",
		description: "Pick colors and grab any format",
		category: "color",
		keywords: [
			"picker",
			"eyedropper",
			"hex",
			"rgb"
		],
		route: "/tools/color#picker"
	},
	{
		id: "color-converter",
		name: "Color Converter",
		description: "HEX ↔ RGB ↔ HSL ↔ HWB ↔ CMYK",
		category: "color",
		keywords: [
			"hex",
			"rgb",
			"hsl",
			"hwb",
			"cmyk",
			"convert"
		],
		route: "/tools/color#converter"
	},
	{
		id: "color-mixer",
		name: "Color Mixer",
		description: "Blend two colors to find the in-between",
		category: "color",
		keywords: [
			"blend",
			"mix",
			"interpolate"
		],
		route: "/tools/color#mixer"
	},
	{
		id: "color-hex",
		name: "Color HEX Explorer",
		description: "Hex codes with RGB breakdown, shades and tints",
		category: "color",
		keywords: [
			"hex",
			"shades",
			"tints"
		],
		route: "/tools/color#hex"
	},
	{
		id: "color-hsl",
		name: "Colors HSL",
		description: "Explore colors by hue, saturation, lightness",
		category: "color",
		keywords: [
			"hsl",
			"hue",
			"saturation",
			"lightness"
		],
		route: "/tools/color#hsl"
	},
	{
		id: "color-hwb",
		name: "Colors HWB",
		description: "Hue, whiteness, blackness (CSS4)",
		category: "color",
		keywords: ["hwb", "css4"],
		route: "/tools/color#hwb"
	},
	{
		id: "color-cmyk",
		name: "Colors CMYK",
		description: "Print-ready CMYK values for any color",
		category: "color",
		keywords: ["cmyk", "print"],
		route: "/tools/color#cmyk"
	},
	{
		id: "color-rgb",
		name: "Colors RGB",
		description: "RGB channels, previews and conversions",
		category: "color",
		keywords: ["rgb", "channels"],
		route: "/tools/color#rgb"
	},
	{
		id: "color-contrast",
		name: "Color Contrast Analyzer",
		description: "WCAG contrast checker for text and UI pairs",
		category: "color",
		keywords: [
			"contrast",
			"wcag",
			"accessibility",
			"a11y"
		],
		route: "/tools/color#contrast"
	},
	{
		id: "color-gradient",
		name: "Color Gradient Builder",
		description: "Compose multi-stop gradients with copyable CSS",
		category: "color",
		keywords: [
			"gradient",
			"css",
			"linear",
			"radial"
		],
		route: "/tools/color#gradient"
	},
	{
		id: "color-tailwind",
		name: "Tailwind Color Finder",
		description: "Find the nearest Tailwind class for any color",
		category: "color",
		keywords: [
			"tailwind",
			"class",
			"nearest"
		],
		route: "/tools/color#tailwind"
	},
	{
		id: "timer",
		name: "Timer",
		description: "Countdown timer with alarm",
		category: "productivity",
		keywords: [
			"countdown",
			"stopwatch",
			"clock"
		],
		route: "/tools/productivity#timer"
	},
	{
		id: "todo",
		name: "To-Do List",
		description: "Simple task list saved locally",
		category: "productivity",
		keywords: [
			"tasks",
			"checklist",
			"notes"
		],
		route: "/tools/productivity#todo"
	},
	{
		id: "calculator",
		name: "Calculator",
		description: "Basic arithmetic calculator",
		category: "productivity",
		keywords: ["math", "arithmetic"],
		route: "/tools/productivity#calculator"
	},
	{
		id: "currency",
		name: "Currency Converter",
		description: "Convert between major currencies",
		category: "productivity",
		keywords: [
			"forex",
			"money",
			"exchange",
			"usd",
			"eur",
			"inr"
		],
		route: "/tools/productivity#currency"
	},
	{
		id: "timezone",
		name: "Timezone Converter",
		description: "Convert times across timezones",
		category: "productivity",
		keywords: [
			"tz",
			"utc",
			"gmt",
			"time"
		],
		route: "/tools/productivity#timezone"
	},
	{
		id: "unit",
		name: "Unit Converter",
		description: "Quick unit conversion",
		category: "productivity",
		keywords: ["units", "convert"],
		route: "/tools/productivity#unit"
	},
	{
		id: "length",
		name: "Length Converter",
		description: "Meter, cm, mm, µm, nm, pm, mile, foot, inch",
		category: "productivity",
		keywords: [
			"distance",
			"meter",
			"kilometer",
			"mile",
			"inch"
		],
		route: "/tools/productivity#length"
	},
	{
		id: "mass",
		name: "Mass / Weight Converter",
		description: "Tonne, kg, g, mg, µg, lb, oz, carat",
		category: "productivity",
		keywords: [
			"weight",
			"kilogram",
			"pound",
			"gram"
		],
		route: "/tools/productivity#mass"
	},
	{
		id: "area",
		name: "Area Converter",
		description: "Square meter, ft², acre, hectare",
		category: "productivity",
		keywords: [
			"square",
			"acre",
			"hectare"
		],
		route: "/tools/productivity#area"
	},
	{
		id: "time-convert",
		name: "Time Converter",
		description: "Year, day, hour, minute, ms, µs, ns",
		category: "productivity",
		keywords: [
			"seconds",
			"minutes",
			"millisecond",
			"microsecond"
		],
		route: "/tools/productivity#time"
	},
	{
		id: "data",
		name: "Data Size Converter",
		description: "Bit, byte, KB, MB, GB, TB, PB",
		category: "productivity",
		keywords: [
			"storage",
			"bytes",
			"kilobyte",
			"megabyte",
			"gigabyte"
		],
		route: "/tools/productivity#data"
	},
	{
		id: "temperature",
		name: "Temperature Converter",
		description: "Celsius, Fahrenheit, Kelvin",
		category: "productivity",
		keywords: [
			"celsius",
			"fahrenheit",
			"kelvin"
		],
		route: "/tools/productivity#temperature"
	},
	{
		id: "finance",
		name: "Finance Calculator",
		description: "Loan EMI and investment growth",
		category: "productivity",
		keywords: [
			"loan",
			"emi",
			"sip",
			"investment",
			"interest"
		],
		route: "/tools/productivity#finance"
	},
	{
		id: "date-diff",
		name: "Date Difference",
		description: "Years, months, days between two dates",
		category: "productivity",
		keywords: [
			"age",
			"days between",
			"duration"
		],
		route: "/tools/productivity#date-diff"
	},
	{
		id: "discount",
		name: "Discount Calculator",
		description: "Final price after percentage discount",
		category: "productivity",
		keywords: [
			"sale",
			"off",
			"price"
		],
		route: "/tools/productivity#discount"
	},
	{
		id: "bmi",
		name: "BMI Calculator",
		description: "Body Mass Index from height and weight",
		category: "productivity",
		keywords: [
			"health",
			"body mass index",
			"weight"
		],
		route: "/tools/productivity#bmi"
	},
	{
		id: "gst",
		name: "GST Calculator",
		description: "Add or extract GST from an amount",
		category: "productivity",
		keywords: [
			"tax",
			"vat",
			"gst",
			"sales tax"
		],
		route: "/tools/productivity#gst"
	}
];
function GlobalSearch() {
	const [q, setQ] = (0, import_react.useState)("");
	const [open, setOpen] = (0, import_react.useState)(false);
	const [active, setActive] = (0, import_react.useState)(0);
	const [announcement, setAnnouncement] = (0, import_react.useState)("");
	const ref = (0, import_react.useRef)(null);
	const listRef = (0, import_react.useRef)(null);
	const inputRef = (0, import_react.useRef)(null);
	const navigate = useNavigate();
	(0, import_react.useEffect)(() => {
		const onClick = (e) => {
			if (ref.current && !ref.current.contains(e.target)) setOpen(false);
		};
		const onKey = (e) => {
			if ((e.ctrlKey || e.metaKey) && e.key.toLowerCase() === "k") {
				e.preventDefault();
				inputRef.current?.focus();
				inputRef.current?.select();
				setOpen(true);
				setAnnouncement("Search focused. Use arrow keys to navigate results.");
			}
		};
		document.addEventListener("mousedown", onClick);
		window.addEventListener("keydown", onKey);
		return () => {
			document.removeEventListener("mousedown", onClick);
			window.removeEventListener("keydown", onKey);
		};
	}, []);
	const DEFAULT_SUGGESTION_IDS = [
		"word-count",
		"pdf-merge",
		"img-compress",
		"json-format",
		"pw-generate",
		"color-picker",
		"calculator"
	];
	const results = (0, import_react.useMemo)(() => {
		const needle = q.trim().toLowerCase();
		if (!needle) return DEFAULT_SUGGESTION_IDS.map((id) => TOOLS.find((t) => t.id === id)).filter((t) => Boolean(t));
		return TOOLS.filter((t) => t.name.toLowerCase().includes(needle) || t.description.toLowerCase().includes(needle) || t.keywords.some((k) => k.includes(needle)) || t.category.includes(needle)).slice(0, 8);
	}, [q]);
	(0, import_react.useEffect)(() => {
		setActive(0);
	}, [q]);
	(0, import_react.useEffect)(() => {
		if (!open || !q) {
			setAnnouncement("");
			return;
		}
		setAnnouncement(`${results.length} result${results.length === 1 ? "" : "s"} for ${q}`);
	}, [
		results.length,
		q,
		open
	]);
	(0, import_react.useEffect)(() => {
		(listRef.current?.querySelector(`[data-idx="${active}"]`))?.scrollIntoView({ block: "nearest" });
	}, [active]);
	const onKey = (e) => {
		if (!open && (e.key === "ArrowDown" || e.key === "Enter")) setOpen(true);
		if (e.key === "ArrowDown") {
			e.preventDefault();
			setActive((i) => Math.min(i + 1, results.length - 1));
		}
		if (e.key === "ArrowUp") {
			e.preventDefault();
			setActive((i) => Math.max(i - 1, 0));
		}
		if (e.key === "Enter") {
			const t = results[active];
			if (t) {
				e.preventDefault();
				const name = t.name;
				const route = t.route;
				setOpen(false);
				setQ("");
				setAnnouncement(`Opening ${name}`);
				navigate({ to: route }).then(() => {
					setAnnouncement(`${name} opened`);
					inputRef.current?.focus();
				});
			}
		}
		if (e.key === "Escape") {
			setOpen(false);
			inputRef.current?.blur();
		}
	};
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		ref,
		className: "relative w-full max-w-md",
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("label", {
				htmlFor: "global-search",
				className: "sr-only",
				children: "Search tools"
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "relative",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("svg", {
					className: "absolute left-3 top-1/2 h-4 w-4 -translate-y-1/2 text-slate-400",
					viewBox: "0 0 24 24",
					fill: "none",
					stroke: "currentColor",
					strokeWidth: "2",
					"aria-hidden": "true",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("circle", {
						cx: "11",
						cy: "11",
						r: "7"
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("path", { d: "m20 20-3.5-3.5" })]
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
					id: "global-search",
					ref: inputRef,
					type: "search",
					value: q,
					onChange: (e) => {
						setQ(e.target.value);
						setOpen(true);
					},
					onFocus: () => setOpen(true),
					onKeyDown: onKey,
					role: "combobox",
					"aria-expanded": open,
					"aria-controls": "global-search-listbox",
					"aria-activedescendant": open && results[active] ? `gs-opt-${results[active].id}` : void 0,
					"aria-autocomplete": "list",
					placeholder: "Search 50+ tools… (Ctrl/⌘K)",
					"aria-label": "Search all tools. Press Control or Command K to focus.",
					"aria-keyshortcuts": "Control+K Meta+K",
					className: "w-full rounded-full border border-slate-200 bg-white py-2 pl-9 pr-4 text-sm text-slate-900 placeholder-slate-400 outline-none transition focus:border-blue-500 focus:ring-2 focus:ring-blue-500/20 dark:border-slate-700 dark:bg-slate-900 dark:text-white dark:placeholder-slate-500"
				})]
			}),
			open && results.length > 0 && /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				ref: listRef,
				id: "global-search-listbox",
				role: "listbox",
				"aria-label": "Tool suggestions",
				className: "absolute left-0 right-0 top-full z-50 mt-2 max-h-96 overflow-auto rounded-2xl border border-slate-200 bg-white p-2 shadow-2xl shadow-blue-900/10 dark:border-slate-700 dark:bg-slate-900",
				children: [!q && /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
					className: "px-3 pb-1 pt-2 text-xs font-semibold uppercase tracking-wider text-slate-400",
					children: "Suggestions"
				}), results.map((t, i) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Link, {
					id: `gs-opt-${t.id}`,
					role: "option",
					"aria-selected": i === active,
					"data-idx": i,
					to: t.route,
					onMouseEnter: () => setActive(i),
					onClick: () => {
						setOpen(false);
						setQ("");
					},
					className: `flex items-start gap-3 rounded-xl px-3 py-2 ${i === active ? "bg-blue-50 dark:bg-slate-800" : ""} hover:bg-blue-50 dark:hover:bg-slate-800`,
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
						className: "mt-0.5 grid h-8 w-8 shrink-0 place-items-center rounded-lg bg-blue-100 text-xs font-bold uppercase text-blue-700 dark:bg-blue-950 dark:text-blue-300",
						children: t.category[0]
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", {
						className: "min-w-0",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
							className: "block truncate text-sm font-medium text-slate-900 dark:text-white",
							children: t.name
						}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
							className: "block truncate text-xs text-slate-500 dark:text-slate-400",
							children: t.description
						})]
					})]
				}, t.id))]
			}),
			open && q && results.length === 0 && /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "absolute left-0 right-0 top-full z-50 mt-2 rounded-2xl border border-slate-200 bg-white p-6 text-center text-sm text-slate-500 shadow-2xl dark:border-slate-700 dark:bg-slate-900",
				children: [
					"No tools found for \"",
					q,
					"\""
				]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
				role: "status",
				"aria-live": "polite",
				className: "sr-only",
				children: announcement
			})
		]
	});
}
async function getProfile() {
	const { data: userData } = await supabase.auth.getUser();
	if (!userData.user) throw new Error("Not authenticated");
	const { data, error } = await supabase.from("profiles").select("*").eq("id", userData.user.id).single();
	if (error) throw error;
	return data;
}
async function updateProfile(displayName) {
	const { data: userData } = await supabase.auth.getUser();
	if (!userData.user) throw new Error("Not authenticated");
	const { error: profileError } = await supabase.from("profiles").update({
		display_name: displayName.trim(),
		updated_at: (/* @__PURE__ */ new Date()).toISOString()
	}).eq("id", userData.user.id);
	if (profileError) throw profileError;
	const { error: authError } = await supabase.auth.updateUser({ data: { display_name: displayName.trim() } });
	if (authError) throw authError;
	return await getProfile();
}
async function uploadAvatar(file) {
	console.log("1");
	const { data: userData } = await supabase.auth.getUser();
	console.log("2");
	if (!userData.user) throw new Error("Not authenticated");
	if (!file.type.startsWith("image/")) throw new Error("Please select a valid image.");
	if (file.size > 5 * 1024 * 1024) throw new Error("Avatar must be smaller than 5 MB.");
	console.log("3");
	const extension = file.name.split(".").pop()?.toLowerCase() || "jpg";
	const fileName = `${userData.user.id}/${Date.now()}.${extension}`;
	console.log("4");
	const { error: uploadError } = await supabase.storage.from("avatars").upload(fileName, file, {
		upsert: true,
		cacheControl: "3600"
	});
	console.log("5");
	if (uploadError) {
		console.error(uploadError);
		throw uploadError;
	}
	const { data: { publicUrl } } = supabase.storage.from("avatars").getPublicUrl(fileName);
	const avatarUrl = publicUrl;
	console.log("6");
	const { error: profileError } = await supabase.from("profiles").update({
		avatar_url: avatarUrl,
		updated_at: (/* @__PURE__ */ new Date()).toISOString()
	}).eq("id", userData.user.id);
	console.log("7");
	if (profileError) throw profileError;
	const { error: authError } = await supabase.auth.updateUser({ data: { avatar_url: avatarUrl } });
	console.log("8");
	if (authError) throw authError;
	console.log("9");
	return avatarUrl;
}
async function changePassword(password) {
	const { error } = await supabase.auth.updateUser({ password });
	if (error) throw error;
}
async function deleteAccount() {
	const { error } = await supabase.functions.invoke("delete-account");
	if (error) throw error;
}
async function getUsageStats() {
	const { data: userData } = await supabase.auth.getUser();
	if (!userData.user) throw new Error("Not authenticated");
	const userId = userData.user.id;
	const today = (/* @__PURE__ */ new Date()).toISOString().split("T")[0];
	const [{ count: totalToolsUsed, error: totalError }, { count: todayUsage, error: todayError }, { data: lastTool, error: lastError }] = await Promise.all([
		supabase.from("tool_usage").select("*", {
			count: "exact",
			head: true
		}).eq("user_id", userId),
		supabase.from("tool_usage").select("*", {
			count: "exact",
			head: true
		}).eq("user_id", userId).gte("used_on", today),
		supabase.from("tool_usage").select("tool_slug").eq("user_id", userId).order("created_at", { ascending: false }).limit(1).maybeSingle()
	]);
	if (totalError) throw totalError;
	if (todayError) throw todayError;
	if (lastError) throw lastError;
	return {
		totalToolsUsed: totalToolsUsed ?? 0,
		todayUsage: todayUsage ?? 0,
		lastToolUsed: lastTool?.tool_slug ?? null
	};
}
function AccountMenu({ compact = false }) {
	const { isAuthenticated, user, isAdmin, plan, signOut, loading } = useAuth();
	const [open, setOpen] = (0, import_react.useState)(false);
	const [profileAvatar, setProfileAvatar] = (0, import_react.useState)("");
	const ref = (0, import_react.useRef)(null);
	(0, import_react.useEffect)(() => {
		if (!open) return;
		const onDoc = (e) => {
			if (ref.current && !ref.current.contains(e.target)) setOpen(false);
		};
		document.addEventListener("mousedown", onDoc);
		return () => document.removeEventListener("mousedown", onDoc);
	}, [open]);
	(0, import_react.useEffect)(() => {
		if (!isAuthenticated) return;
		async function loadProfile() {
			try {
				const profile = await getProfile();
				setProfileAvatar(profile.avatar_url ?? "");
			} catch (err) {
				console.error(err);
			}
		}
		loadProfile();
	}, [isAuthenticated]);
	if (loading) return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
		className: "h-9 w-20 animate-pulse rounded-lg bg-slate-100 dark:bg-slate-800",
		"aria-hidden": "true"
	});
	if (!isAuthenticated) return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(import_jsx_runtime.Fragment, { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Link, {
		to: "/auth",
		search: { mode: "signin" },
		className: "hidden sm:inline-flex items-center rounded-lg px-3 py-2 text-sm font-medium text-slate-700 hover:text-blue-600 dark:text-slate-200 dark:hover:text-blue-400",
		title: "Log in",
		children: "Log in"
	}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Link, {
		to: "/auth",
		search: { mode: "signup" },
		className: "hidden sm:inline-flex items-center rounded-lg bg-blue-600 px-3.5 py-2 text-sm font-semibold text-white shadow-sm shadow-blue-600/30 transition hover:bg-blue-700",
		title: "Sign up",
		children: "Sign up"
	})] });
	const name = user?.user_metadata?.display_name || user?.email || "Account";
	console.log("Auth avatar:", user?.user_metadata?.avatar_url);
	console.log("Provider:", user?.app_metadata?.provider);
	console.log("Identities:", user?.identities);
	const googleAvatar = (user?.identities?.find((identity) => identity.provider === "google")?.identity_data)?.avatar_url ?? "";
	const avatar = profileAvatar || googleAvatar;
	console.log("Full metadata:", user?.user_metadata);
	const initial = (name[0] || "?").toUpperCase();
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		ref,
		className: `relative ${compact ? "" : "hidden sm:block"}`,
		children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("button", {
			type: "button",
			onClick: () => setOpen((prev) => !prev),
			"aria-haspopup": "menu",
			"aria-expanded": open,
			"aria-label": "Account Menu",
			className: "flex items-center gap-1 rounded-xl border border-slate-200 bg-white p-1 transition-all hover:border-blue-500 hover:bg-slate-50 dark:border-slate-700 dark:bg-slate-900 dark:hover:border-blue-500 dark:hover:bg-slate-800",
			children: [
				avatar ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("img", {
					src: avatar,
					alt: name,
					referrerPolicy: "no-referrer",
					className: "h-8 w-8 rounded-full border border-slate-200 object-cover dark:border-slate-700"
				}) : /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
					className: "grid h-8 w-8 place-items-center rounded-full bg-blue-600 text-sm font-bold text-white",
					children: initial
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
					className: "flex flex-col items-start leading-tight",
					children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
						className: "max-w-58 truncate text-sm font-semibold",
						children: name
					})
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("svg", {
					viewBox: "0 0 24 24",
					className: `h-6 w-6 transition-transform ${open ? "rotate-180" : ""}`,
					fill: "none",
					stroke: "currentColor",
					strokeWidth: "2",
					children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("path", { d: "m6 9 6 6 6-6" })
				})
			]
		}), open && /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
			role: "menu",
			className: "absolute right-0 top-full z-40 mt-2 w-72 rounded-xl border border-slate-200 bg-white p-1 shadow-2xl dark:border-slate-800 dark:bg-slate-950",
			children: [
				/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "flex items-center gap-3 border-b border-slate-100 px-3 py-3 dark:border-slate-800",
					children: [avatar ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("img", {
						src: avatar,
						alt: name,
						className: "h-12 w-12 rounded-full border border-slate-200 object-cover dark:border-slate-700"
					}) : /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
						className: "flex h-12 w-12 items-center justify-center rounded-full bg-blue-600 text-lg font-bold text-white",
						children: initial
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "min-w-0 flex-1",
						children: [
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
								className: "truncate font-semibold text-slate-900 dark:text-white",
								children: name
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
								className: "truncate text-xs text-slate-500 dark:text-slate-400",
								children: user?.email
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
								className: "mt-2 flex flex-wrap gap-1",
								children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
									className: `rounded-full px-2 py-0.5 text-[10px] font-semibold ${plan === "premium" ? "bg-amber-100 text-amber-700 dark:bg-amber-900/40 dark:text-amber-300" : "bg-slate-100 text-slate-700 dark:bg-slate-800 dark:text-slate-300"}`,
									children: plan.toUpperCase()
								}), isAdmin && /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
									className: "rounded-full bg-blue-100 px-2 py-0.5 text-[10px] font-semibold text-blue-700 dark:bg-blue-950/60 dark:text-blue-300",
									children: "ADMIN"
								})]
							})
						]
					})]
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Link, {
					to: "/dashboard",
					onClick: () => setOpen(false),
					role: "menuitem",
					className: "block rounded-md px-3 py-2 text-sm text-slate-700 hover:bg-slate-100 dark:text-slate-200 dark:hover:bg-slate-900",
					children: "📊 Dashboard"
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Link, {
					to: "/profile",
					onClick: () => setOpen(false),
					role: "menuitem",
					className: "block rounded-md px-3 py-2 text-sm text-slate-700 hover:bg-slate-100 dark:text-slate-200 dark:hover:bg-slate-900",
					children: "👤 My Profile"
				}),
				isAdmin && /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Link, {
					to: "/admin",
					onClick: () => setOpen(false),
					role: "menuitem",
					className: "block rounded-md px-3 py-2 text-sm text-slate-700 hover:bg-slate-100 dark:text-slate-200 dark:hover:bg-slate-900",
					children: "🛠 Admin Panel"
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Link, {
					to: "/pricing",
					onClick: () => setOpen(false),
					role: "menuitem",
					className: "block rounded-md px-3 py-2 text-sm text-slate-700 hover:bg-slate-100 dark:text-slate-200 dark:hover:bg-slate-900",
					children: "💎 Pricing"
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
					type: "button",
					onClick: () => {
						setOpen(false);
						signOut();
					},
					role: "menuitem",
					className: "w-full rounded-md px-3 py-2 text-left text-sm text-red-400 hover:bg-red-50 dark:hover:bg-red-950/40",
					children: "🚪 Sign Out"
				})
			]
		})]
	});
}
var PRIMARY = [
	{
		to: "/",
		label: "Home"
	},
	{
		to: "/about",
		label: "About"
	},
	{
		to: "/why-choose-us",
		label: "Why Choose Us"
	},
	{
		to: "/pricing",
		label: "Pricing"
	},
	{
		to: "/contact",
		label: "Contact"
	}
];
var PRODUCTS = [
	{
		to: "/tools/text",
		label: "Text Tools",
		desc: "Words, strings & encoders",
		emoji: "Aa",
		cat: "text",
		mega: false
	},
	{
		to: "/tools/pdf",
		label: "PDF Tools",
		desc: "Merge, split, protect, rotate",
		emoji: "PDF",
		cat: "pdf",
		mega: true
	},
	{
		to: "/tools/image",
		label: "Image Tools",
		desc: "Resize, crop, filter, convert",
		emoji: "IMG",
		cat: "image",
		mega: true
	},
	{
		to: "/tools/code",
		label: "Code Tools",
		desc: "JSON, JWT, regex, hashes, editor",
		emoji: "{}",
		cat: "code",
		mega: true
	},
	{
		to: "/tools/color",
		label: "Color Tools",
		desc: "Picker, converter, contrast, gradient",
		emoji: "#",
		cat: "color",
		mega: true
	},
	{
		to: "/tools/password",
		label: "Password Tools",
		desc: "Generator & strength meter",
		emoji: "**",
		cat: "password",
		mega: true
	},
	{
		to: "/tools/productivity",
		label: "Productivity Tools",
		desc: "Timer, calculators, converters",
		emoji: "⚡",
		cat: "productivity",
		mega: true
	}
];
function Header() {
	const pathname = useRouterState({ select: (s) => s.location.pathname });
	const { theme, toggle } = useTheme();
	const [mobileOpen, setMobileOpen] = (0, import_react.useState)(false);
	const [openCat, setOpenCat] = (0, import_react.useState)(null);
	const isActive = (to) => to === "/" ? pathname === "/" : pathname.startsWith(to);
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("header", {
		className: "sticky top-0 z-40 border-b border-slate-200/70 bg-white/90 backdrop-blur-md dark:border-slate-800/70 dark:bg-slate-950/90",
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "mx-auto flex max-w-7xl items-center gap-4 px-4 py-3 sm:px-6",
				children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Logo, {}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("nav", {
						"aria-label": "Primary",
						className: "ml-auto hidden lg:flex items-center gap-1",
						children: PRIMARY.map((l) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Link, {
							to: l.to,
							className: `relative rounded-lg px-3 py-2 text-sm font-medium transition ${isActive(l.to) ? "text-blue-700 dark:text-blue-300" : "text-slate-600 hover:text-slate-900 dark:text-slate-300 dark:hover:text-white"}`,
							children: [l.label, isActive(l.to) && /* @__PURE__ */ (0, import_jsx_runtime.jsx)(motion.span, {
								layoutId: "nav-active",
								className: "absolute inset-x-2 -bottom-0.5 h-0.5 rounded-full bg-blue-600 dark:bg-blue-400"
							})]
						}, l.to))
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
						className: "ml-auto hidden md:block lg:ml-6 lg:w-80",
						children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(GlobalSearch, {})
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "ml-auto flex items-center gap-2 lg:ml-2",
						children: [
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
								type: "button",
								onClick: toggle,
								"aria-label": `Switch to ${theme === "dark" ? "light" : "dark"} mode`,
								className: "grid h-9 w-9 place-items-center rounded-lg border border-slate-200 text-slate-600 transition hover:border-blue-500 hover:text-blue-600 dark:border-slate-700 dark:text-slate-300 dark:hover:border-blue-400 dark:hover:text-blue-400",
								children: theme === "dark" ? /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("svg", {
									viewBox: "0 0 24 24",
									className: "h-5 w-5",
									fill: "none",
									stroke: "currentColor",
									strokeWidth: "2",
									"aria-hidden": "true",
									children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("circle", {
										cx: "12",
										cy: "12",
										r: "4"
									}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("path", { d: "M12 2v2M12 20v2M4.93 4.93l1.41 1.41M17.66 17.66l1.41 1.41M2 12h2M20 12h2M4.93 19.07l1.41-1.41M17.66 6.34l1.41-1.41" })]
								}) : /* @__PURE__ */ (0, import_jsx_runtime.jsx)("svg", {
									viewBox: "0 0 24 24",
									className: "h-5 w-5",
									fill: "none",
									stroke: "currentColor",
									strokeWidth: "2",
									"aria-hidden": "true",
									children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("path", { d: "M21 12.79A9 9 0 1 1 11.21 3 7 7 0 0 0 21 12.79Z" })
								})
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)(AccountMenu, {}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
								type: "button",
								onClick: () => setMobileOpen((o) => !o),
								"aria-label": "Toggle menu",
								"aria-expanded": mobileOpen,
								className: "grid h-9 w-9 place-items-center rounded-lg border border-slate-200 lg:hidden dark:border-slate-700",
								children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("svg", {
									viewBox: "0 0 24 24",
									className: "h-5 w-5",
									fill: "none",
									stroke: "currentColor",
									strokeWidth: "2",
									"aria-hidden": "true",
									children: mobileOpen ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("path", { d: "M18 6 6 18M6 6l12 12" }) : /* @__PURE__ */ (0, import_jsx_runtime.jsx)("path", { d: "M3 6h18M3 12h18M3 18h18" })
								})
							})
						]
					})
				]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
				className: "hidden border-t border-slate-200/70 lg:block dark:border-slate-800/70",
				children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
					className: "mx-auto max-w-7xl px-4 sm:px-6",
					onMouseLeave: () => setOpenCat(null),
					children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
						className: "flex items-center gap-1 py-2",
						children: PRODUCTS.map((p) => {
							const tools = TOOLS.filter((t) => t.category === p.cat);
							const open = openCat === p.cat;
							if (!p.mega) return /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Link, {
								to: p.to,
								className: `inline-flex items-center gap-1.5 rounded-lg px-3 py-1.5 text-sm font-semibold transition ${isActive(p.to) ? "bg-blue-50 text-blue-700 dark:bg-blue-950/60 dark:text-blue-300" : "text-slate-600 hover:text-blue-700 dark:text-slate-300 dark:hover:text-blue-300"}`,
								children: p.label
							}, p.to);
							return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
								className: "relative",
								onMouseEnter: () => setOpenCat(p.cat),
								children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Link, {
									to: p.to,
									"aria-haspopup": "true",
									"aria-expanded": open,
									className: `inline-flex items-center gap-1.5 rounded-lg px-3 py-1.5 text-sm font-semibold transition ${isActive(p.to) || open ? "bg-blue-50 text-blue-700 dark:bg-blue-950/60 dark:text-blue-300" : "text-slate-600 hover:text-blue-700 dark:text-slate-300 dark:hover:text-blue-300"}`,
									children: [p.label, /* @__PURE__ */ (0, import_jsx_runtime.jsx)("svg", {
										viewBox: "0 0 24 24",
										className: "h-3.5 w-3.5",
										fill: "none",
										stroke: "currentColor",
										strokeWidth: "2.5",
										"aria-hidden": "true",
										children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("path", { d: "m6 9 6 6 6-6" })
									})]
								}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(AnimatePresence, { children: open && /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(motion.div, {
									initial: {
										opacity: 0,
										y: -6
									},
									animate: {
										opacity: 1,
										y: 0
									},
									exit: {
										opacity: 0,
										y: -6
									},
									transition: { duration: .12 },
									className: "absolute left-0 top-full z-30 mt-1 w-[min(720px,calc(100vw-2rem))] rounded-2xl border border-slate-200 bg-white p-4 shadow-2xl shadow-blue-900/10 dark:border-slate-800 dark:bg-slate-950",
									children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
										className: "mb-3 flex items-center justify-between gap-3 border-b border-slate-100 pb-3 dark:border-slate-800",
										children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
											className: "flex items-center gap-3",
											children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
												className: "grid h-9 w-9 place-items-center rounded-lg bg-blue-600 text-xs font-bold text-white",
												children: p.emoji
											}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
												className: "font-semibold text-slate-900 dark:text-white",
												children: p.label
											}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
												className: "text-xs text-slate-500 dark:text-slate-400",
												children: p.desc
											})] })]
										}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Link, {
											to: p.to,
											onClick: () => setOpenCat(null),
											className: "text-xs font-semibold text-blue-600 hover:text-blue-700 dark:text-blue-400",
											children: "View all →"
										})]
									}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("ul", {
										className: "grid grid-cols-2 gap-1 md:grid-cols-3",
										children: tools.map((t) => {
											const [path, hash] = t.route.split("#");
											return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("li", { children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Link, {
												to: path,
												hash,
												onClick: () => setOpenCat(null),
												title: t.description,
												className: "block truncate rounded-lg px-3 py-1.5 text-sm text-slate-700 transition hover:bg-blue-50 hover:text-blue-700 dark:text-slate-200 dark:hover:bg-slate-900 dark:hover:text-blue-300",
												children: t.name
											}) }, t.id);
										})
									})]
								}) })]
							}, p.to);
						})
					})
				})
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)(AnimatePresence, { children: mobileOpen && /* @__PURE__ */ (0, import_jsx_runtime.jsx)(motion.div, {
				initial: {
					height: 0,
					opacity: 0
				},
				animate: {
					height: "auto",
					opacity: 1
				},
				exit: {
					height: 0,
					opacity: 0
				},
				className: "overflow-hidden border-t border-slate-200 lg:hidden dark:border-slate-800",
				children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "space-y-3 px-4 py-4",
					children: [
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)(GlobalSearch, {}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("nav", {
							"aria-label": "Mobile",
							className: "grid gap-1",
							children: [...PRIMARY, ...PRODUCTS].map((l) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Link, {
								to: l.to,
								onClick: () => setMobileOpen(false),
								className: `rounded-lg px-3 py-2 text-sm font-medium ${isActive(l.to) ? "bg-blue-50 text-blue-700 dark:bg-blue-950/60 dark:text-blue-300" : "text-slate-700 hover:bg-slate-50 dark:text-slate-200 dark:hover:bg-slate-900"}`,
								children: l.label
							}, l.to))
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)(MobileAuthButtons, { onClick: () => setMobileOpen(false) })
					]
				})
			}) })
		]
	});
}
function MobileAuthButtons({ onClick }) {
	const { isAuthenticated, isAdmin, signOut } = useAuth();
	if (!isAuthenticated) return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "grid grid-cols-2 gap-2 pt-2",
		children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Link, {
			to: "/auth",
			search: { mode: "signin" },
			onClick,
			className: "rounded-lg border border-slate-200 px-3 py-2 text-center text-sm font-medium dark:border-slate-700 dark:text-white",
			children: "Log in"
		}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Link, {
			to: "/auth",
			search: { mode: "signup" },
			onClick,
			className: "rounded-lg bg-blue-600 px-3 py-2 text-center text-sm font-semibold text-white",
			children: "Sign up"
		})]
	});
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "grid gap-2 pt-2",
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Link, {
				to: "/dashboard",
				onClick,
				className: "rounded-lg border border-slate-200 px-3 py-2 text-center text-sm font-medium dark:border-slate-700 dark:text-white",
				children: "Dashboard"
			}),
			isAdmin && /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Link, {
				to: "/admin",
				onClick,
				className: "rounded-lg border border-blue-200 bg-blue-50 px-3 py-2 text-center text-sm font-medium text-blue-700 dark:border-blue-900 dark:bg-blue-950/40 dark:text-blue-300",
				children: "Admin panel"
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
				type: "button",
				onClick: () => {
					onClick();
					signOut();
				},
				className: "rounded-lg bg-red-600 px-3 py-2 text-center text-sm font-semibold text-white",
				children: "Sign out"
			})
		]
	});
}
function CopyInline({ value, label, className = "" }) {
	const [copied, setCopied] = (0, import_react.useState)(false);
	const [msg, setMsg] = (0, import_react.useState)("");
	const t = (0, import_react.useRef)(null);
	const announce = (m) => {
		setMsg("");
		if (t.current) window.clearTimeout(t.current);
		t.current = window.setTimeout(() => setMsg(m), 30);
	};
	const onClick = async () => {
		try {
			await navigator.clipboard.writeText(value);
			setCopied(true);
			announce(`Copied ${label || "value"} to clipboard`);
			toast.success(`Copied ${label || value}`);
			window.setTimeout(() => setCopied(false), 1600);
		} catch (err) {
			const reason = err?.message || "clipboard unavailable";
			announce(`Copy failed: ${reason}`);
			toast.error(`Copy failed: ${reason}`);
		}
	};
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(import_jsx_runtime.Fragment, { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
		type: "button",
		onClick,
		"aria-label": copied ? `Copied ${label || value}` : `Copy ${label || value} to clipboard`,
		title: copied ? "Copied" : "Copy",
		className: `inline-flex items-center justify-center rounded-md border border-slate-200 bg-white p-1.5 text-slate-700 transition hover:border-blue-500 hover:text-blue-700 dark:border-slate-700 dark:bg-slate-900 dark:text-slate-200 ${className}`,
		children: copied ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("svg", {
			viewBox: "0 0 24 24",
			className: "h-4 w-4 text-green-600",
			fill: "none",
			stroke: "currentColor",
			strokeWidth: "2.5",
			"aria-hidden": "true",
			children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("path", { d: "M20 6L9 17l-5-5" })
		}) : /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("svg", {
			viewBox: "0 0 24 24",
			className: "h-4 w-4",
			fill: "none",
			stroke: "currentColor",
			strokeWidth: "2",
			"aria-hidden": "true",
			children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("rect", {
				x: "9",
				y: "9",
				width: "13",
				height: "13",
				rx: "2"
			}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("path", { d: "M5 15H4a2 2 0 0 1-2-2V4a2 2 0 0 1 2-2h9a2 2 0 0 1 2 2v1" })]
		})
	}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
		role: "status",
		"aria-live": "polite",
		"aria-atomic": "true",
		className: "sr-only",
		children: msg
	})] });
}
function Footer() {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("footer", {
		className: "border-t border-slate-200 bg-slate-50 dark:border-slate-800 dark:bg-slate-950",
		children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
			className: "mx-auto grid max-w-7xl gap-8 px-4 py-12 sm:px-6 md:grid-cols-4",
			children: [
				/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "md:col-span-2",
					children: [
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Logo, {}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
							className: "mt-3 max-w-sm text-sm text-slate-600 dark:text-slate-400",
							children: "One toolkit for text, PDF, image, code and password work. Fast, free, and runs entirely in your browser — no uploads."
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
							className: "mt-4 space-y-2 text-sm text-slate-600 dark:text-slate-400",
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
								className: "flex flex-wrap items-center gap-2",
								children: [
									/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
										className: "font-medium",
										children: "Email:"
									}),
									/* @__PURE__ */ (0, import_jsx_runtime.jsx)("a", {
										href: "mailto:prashantnadar2223@gmail.com",
										className: "hover:text-blue-600",
										children: "prashantnadar2223@gmail.com"
									}),
									/* @__PURE__ */ (0, import_jsx_runtime.jsx)(CopyInline, {
										value: "prashantnadar2223@gmail.com",
										label: "email"
									})
								]
							}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
								className: "flex flex-wrap items-center gap-2",
								children: [
									/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
										className: "font-medium",
										children: "Phone:"
									}),
									/* @__PURE__ */ (0, import_jsx_runtime.jsx)("a", {
										href: "tel:+919653386506",
										className: "hover:text-blue-600",
										children: "+91 96533 86506"
									}),
									/* @__PURE__ */ (0, import_jsx_runtime.jsx)(CopyInline, {
										value: "+91 96533 86506",
										label: "phone number"
									})
								]
							})]
						})
					]
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h2", {
					className: "text-sm font-semibold text-slate-900 dark:text-white",
					children: "Products"
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("ul", {
					className: "mt-3 space-y-2 text-sm",
					children: [
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("li", { children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Link, {
							to: "/tools/text",
							className: "text-slate-600 hover:text-blue-600 dark:text-slate-400",
							children: "Text Tools"
						}) }),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("li", { children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Link, {
							to: "/tools/pdf",
							className: "text-slate-600 hover:text-blue-600 dark:text-slate-400",
							children: "PDF Tools"
						}) }),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("li", { children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Link, {
							to: "/tools/image",
							className: "text-slate-600 hover:text-blue-600 dark:text-slate-400",
							children: "Image Tools"
						}) }),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("li", { children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Link, {
							to: "/tools/code",
							className: "text-slate-600 hover:text-blue-600 dark:text-slate-400",
							children: "Code Tools"
						}) }),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("li", { children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Link, {
							to: "/tools/color",
							className: "text-slate-600 hover:text-blue-600 dark:text-slate-400",
							children: "Color Tools"
						}) }),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("li", { children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Link, {
							to: "/tools/password",
							className: "text-slate-600 hover:text-blue-600 dark:text-slate-400",
							children: "Password Tools"
						}) })
					]
				})] }),
				/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h2", {
					className: "text-sm font-semibold text-slate-900 dark:text-white",
					children: "Company"
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("ul", {
					className: "mt-3 space-y-2 text-sm",
					children: [
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("li", { children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Link, {
							to: "/about",
							className: "text-slate-600 hover:text-blue-600 dark:text-slate-400",
							children: "About"
						}) }),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("li", { children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Link, {
							to: "/pricing",
							className: "text-slate-600 hover:text-blue-600 dark:text-slate-400",
							children: "Pricing"
						}) }),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("li", { children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Link, {
							to: "/why-choose-us",
							className: "text-slate-600 hover:text-blue-600 dark:text-slate-400",
							children: "Why choose us"
						}) }),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("li", { children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Link, {
							to: "/contact",
							className: "text-slate-600 hover:text-blue-600 dark:text-slate-400",
							children: "Contact"
						}) }),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("li", { children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Link, {
							to: "/privacy",
							className: "text-slate-600 hover:text-blue-600 dark:text-slate-400",
							children: "Privacy Policy"
						}) }),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("li", { children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Link, {
							to: "/terms",
							className: "text-slate-600 hover:text-blue-600 dark:text-slate-400",
							children: "Terms & Conditions"
						}) })
					]
				})] })
			]
		}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
			className: "border-t border-slate-200 px-4 py-4 text-center text-xs text-slate-500 dark:border-slate-800",
			children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", { children: [
				"© ",
				(/* @__PURE__ */ new Date()).getFullYear(),
				" UniversalTools. All rights reserved. · ",
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Link, {
					to: "/privacy",
					className: "hover:text-blue-600",
					children: "Privacy"
				}),
				" · ",
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Link, {
					to: "/terms",
					className: "hover:text-blue-600",
					children: "Terms"
				})
			] }), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
				className: "mt-1",
				children: ["Made with ❤️ by ", /* @__PURE__ */ (0, import_jsx_runtime.jsx)("a", {
					href: "https://www.instagram.com/prashant_Dev_22/",
					target: "_blank",
					rel: "noopener noreferrer",
					className: "hover:text-blue-600",
					children: "Prashant Nadar"
				})]
			})]
		})]
	});
}
function BackToTopButton() {
	const [visible, setVisible] = (0, import_react.useState)(false);
	(0, import_react.useEffect)(() => {
		const onScroll = () => setVisible(window.scrollY > 520);
		onScroll();
		window.addEventListener("scroll", onScroll, { passive: true });
		return () => window.removeEventListener("scroll", onScroll);
	}, []);
	if (!visible) return null;
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
		type: "button",
		onClick: () => window.scrollTo({
			top: 0,
			behavior: "smooth"
		}),
		"aria-label": "Back to top",
		title: "Back to top",
		className: "fixed bottom-5 right-5 z-50 inline-flex h-11 w-11 items-center justify-center rounded-full bg-blue-600 text-white shadow-lg shadow-blue-600/25 transition hover:animate-none hover:bg-blue-700 focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-blue-500 focus-visible:ring-offset-2 animate-bounce",
		children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("svg", {
			viewBox: "0 0 24 24",
			className: "h-5 w-5",
			fill: "none",
			stroke: "currentColor",
			strokeWidth: "2.5",
			strokeLinecap: "round",
			strokeLinejoin: "round",
			"aria-hidden": "true",
			children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("path", { d: "m18 15-6-6-6 6" })
		})
	});
}
function Layout({ children }) {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "flex min-h-screen flex-col bg-white text-slate-900 antialiased dark:bg-slate-950 dark:text-slate-100",
		style: { fontFamily: "'Inter Variable', 'Inter', system-ui, sans-serif" },
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("a", {
				href: "#main",
				className: "sr-only focus:not-sr-only focus:absolute focus:left-2 focus:top-2 focus:rounded focus:bg-blue-600 focus:px-3 focus:py-2 focus:text-white",
				children: "Skip to content"
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Header, {}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("main", {
				id: "main",
				tabIndex: -1,
				className: "flex-1 focus:outline-none",
				children
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Footer, {}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)(BackToTopButton, {})
		]
	});
}
//#endregion
export { deleteAccount as a, updateProfile as c, changePassword as i, uploadAvatar as l, Layout as n, getProfile as o, TOOLS as r, getUsageStats as s, CopyInline as t };
