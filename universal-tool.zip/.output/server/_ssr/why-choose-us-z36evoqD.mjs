import { r as require_jsx_runtime } from "../_libs/react+tanstack__react-query.mjs";
import { n as Layout } from "./Layout-8Jn4q3kq.mjs";
import { t as Reveal } from "./Reveal-CydLpVW7.mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/why-choose-us-z36evoqD.js
var import_jsx_runtime = require_jsx_runtime();
var POINTS = [
	{
		t: "Private by default",
		d: "All processing happens in your browser. Files never get uploaded."
	},
	{
		t: "Ready when you are",
		d: "Every free tool works instantly in your browser."
	},
	{
		t: "Blazing fast",
		d: "No round trips, no waiting in queues, no spinners."
	},
	{
		t: "Works offline-ish",
		d: "Once loaded, most tools keep working without internet."
	},
	{
		t: "One home for everything",
		d: "Stop bookmarking ten different sites."
	},
	{
		t: "Built for mobile too",
		d: "Every tool is fully responsive on phones and tablets."
	}
];
function Why() {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Layout, { children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("section", {
		className: "mx-auto max-w-5xl px-4 py-20 sm:px-6",
		children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Reveal, { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h1", {
			className: "text-4xl font-bold text-slate-900 sm:text-5xl dark:text-white",
			style: { fontFamily: "'Space Grotesk', sans-serif" },
			children: "Why teams pick UniversalTools"
		}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
			className: "mt-4 max-w-2xl text-lg text-slate-600 dark:text-slate-300",
			children: "Six reasons people make us their default toolbox."
		})] }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
			className: "mt-12 grid gap-5 sm:grid-cols-2 lg:grid-cols-3",
			children: POINTS.map((p, i) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Reveal, {
				delay: i * .06,
				children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("article", {
					className: "h-full rounded-2xl border border-slate-200 bg-white p-6 dark:border-slate-800 dark:bg-slate-900",
					children: [
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
							className: "grid h-10 w-10 place-items-center rounded-lg bg-blue-600 text-white font-bold",
							children: i + 1
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h2", {
							className: "mt-4 font-bold text-slate-900 dark:text-white",
							children: p.t
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
							className: "mt-1 text-sm text-slate-600 dark:text-slate-400",
							children: p.d
						})
					]
				})
			}, p.t))
		})]
	}) });
}
//#endregion
export { Why as component };
