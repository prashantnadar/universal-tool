import { r as require_jsx_runtime } from "../_libs/react+tanstack__react-query.mjs";
import { n as Layout } from "./Layout-8Jn4q3kq.mjs";
import { t as Reveal } from "./Reveal-CydLpVW7.mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/terms-1KngXBKB.js
var import_jsx_runtime = require_jsx_runtime();
function Terms() {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Layout, { children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("section", {
		className: "mx-auto max-w-3xl px-4 py-12 sm:px-6",
		children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Reveal, { children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
				className: "text-sm font-semibold uppercase tracking-wider text-blue-600",
				children: "Legal"
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h1", {
				className: "mt-1 text-3xl font-bold text-slate-900 sm:text-4xl dark:text-white",
				style: { fontFamily: "'Space Grotesk', sans-serif" },
				children: "Terms & Conditions"
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
				className: "mt-2 text-sm text-slate-500 dark:text-slate-400",
				children: ["Last updated: ", "July 1, 2026"]
			})
		] }), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
			className: "prose prose-slate mt-8 max-w-none space-y-6 text-slate-700 dark:prose-invert dark:text-slate-300",
			children: [
				/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("section", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h2", {
					className: "text-xl font-bold text-slate-900 dark:text-white",
					children: "1. Acceptance"
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", { children: "By using UniversalTools you agree to these Terms & Conditions. If you don't agree, please don't use the service." })] }),
				/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("section", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h2", {
					className: "text-xl font-bold text-slate-900 dark:text-white",
					children: "2. Service description"
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", { children: "UniversalTools provides free browser-based utilities for text, PDF, image, code and password work. All tools run on your device." })] }),
				/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("section", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h2", {
					className: "text-xl font-bold text-slate-900 dark:text-white",
					children: "3. Acceptable use"
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("ul", {
					className: "list-disc space-y-1 pl-6",
					children: [
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("li", { children: "Do not use the tools for illegal activity or to infringe others' rights." }),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("li", { children: "You are responsible for the content you process." }),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("li", { children: "Do not attempt to reverse engineer, disrupt, or overload the service." })
					]
				})] }),
				/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("section", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h2", {
					className: "text-xl font-bold text-slate-900 dark:text-white",
					children: "4. Intellectual property"
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", { children: "The site design, code and branding are © UniversalTools. Your content stays yours — we don't claim rights over anything you process on our tools." })] }),
				/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("section", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h2", {
					className: "text-xl font-bold text-slate-900 dark:text-white",
					children: "5. Disclaimer"
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", { children: "The service is provided \"as is\" without warranty of any kind. We don't guarantee results will be perfect and are not liable for any loss of data. Always keep original copies of important files." })] }),
				/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("section", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h2", {
					className: "text-xl font-bold text-slate-900 dark:text-white",
					children: "6. Limitation of liability"
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", { children: "To the fullest extent permitted by law, UniversalTools shall not be liable for any indirect, incidental or consequential damages arising from your use of the service." })] }),
				/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("section", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h2", {
					className: "text-xl font-bold text-slate-900 dark:text-white",
					children: "7. Changes"
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", { children: "We may update these Terms from time to time. Continued use of the service after changes constitutes acceptance of the new Terms." })] }),
				/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("section", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h2", {
					className: "text-xl font-bold text-slate-900 dark:text-white",
					children: "8. Contact"
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", { children: [
					"Questions? Reach us via the ",
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("a", {
						href: "/contact",
						className: "text-blue-600 hover:underline",
						children: "Contact page"
					}),
					"."
				] })] })
			]
		})]
	}) });
}
//#endregion
export { Terms as component };
