import { t as supabase } from "./client-CxWkeBjE.mjs";
import { t as logUsage } from "./usage-log-DqdX7H0u.mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/usage-limits-DDl6NoXq.js
var KEY = "ut-recent-tools";
var MAX = 10;
function getRecent() {
	if (typeof window === "undefined") return [];
	try {
		return JSON.parse(localStorage.getItem(KEY) || "[]");
	} catch {
		return [];
	}
}
function pushRecent(id) {
	if (typeof window === "undefined") return;
	const cur = getRecent().filter((x) => x !== id);
	cur.unshift(id);
	localStorage.setItem(KEY, JSON.stringify(cur.slice(0, MAX)));
}
var GUEST_KEY = "ut-guest-fp";
/** Persistent client fingerprint (server combines with caller IP before hashing). */
async function getGuestHash() {
	if (typeof window === "undefined") return "ssr-guest";
	let id = localStorage.getItem(GUEST_KEY);
	if (!id) {
		id = crypto.randomUUID();
		localStorage.setItem(GUEST_KEY, id);
	}
	const raw = [
		id,
		navigator.userAgent,
		navigator.language,
		Intl.DateTimeFormat().resolvedOptions().timeZone,
		`${screen.width}x${screen.height}`
	].join("|");
	const buf = await crypto.subtle.digest("SHA-256", new TextEncoder().encode(raw));
	return Array.from(new Uint8Array(buf)).map((b) => b.toString(16).padStart(2, "0")).join("");
}
/** Generate a fresh idempotency key. One key = one logical execution. */
function newIdempotencyKey() {
	return crypto.randomUUID();
}
/**
* Retry a promise-returning fn with exponential backoff on transient failures.
* Server dedupes by idempotency_key, so retries never double-charge.
*/
async function withRetry(fn, isTransient, opts = {}) {
	const attempts = opts.attempts ?? 4;
	const baseMs = opts.baseMs ?? 200;
	let last;
	for (let i = 0; i < attempts; i++) {
		try {
			const r = await fn(i);
			if (!isTransient(r)) return r;
			last = r;
		} catch (e) {
			if (i === attempts - 1) throw e;
		}
		const delay = baseMs * Math.pow(2, i) + Math.random() * baseMs;
		if (opts.label) logUsage("retry", {
			tool: opts.label,
			key: opts.key,
			attempt: i + 1,
			delayMs: Math.round(delay)
		});
		await new Promise((res) => setTimeout(res, delay));
	}
	return last;
}
var isTransientRpcError = (msg) => {
	if (!msg) return false;
	const m = msg.toLowerCase();
	return m.includes("fetch") || m.includes("network") || m.includes("timeout") || m.includes("temporarily") || m.includes("503") || m.includes("502") || m.includes("504") || m.includes("econn");
};
/**
* Atomically check the daily limit and record a use (idempotent by key).
* Retries transient network/5xx errors with exponential backoff.
*/
async function checkAndRecord(toolSlug, idempotencyKey) {
	const hash = await getGuestHash();
	const { getCountryCode } = await import("./guestCountry-DEPfpu3r.mjs");
	const cc = await getCountryCode().catch(() => null);
	logUsage("attempt", {
		tool: toolSlug,
		key: idempotencyKey
	});
	const result = await withRetry(async () => {
		const { data, error } = await supabase.rpc("check_and_record_usage", {
			_tool_slug: toolSlug,
			_idempotency_key: idempotencyKey,
			_guest_hash: hash,
			_country_code: cc
		});
		if (error) return {
			allowed: false,
			used: 0,
			limit: 0,
			plan: "guest",
			remaining: 0,
			error: error.message
		};
		return data;
	}, (r) => Boolean(r.error) && isTransientRpcError(r.error), {
		label: toolSlug,
		key: idempotencyKey
	});
	if (result.allowed) pushRecent(toolSlug);
	return result;
}
/** Read-only usage status for UI (no record). Retries transient failures. */
async function getUsageStatus() {
	const hash = await getGuestHash();
	return withRetry(async () => {
		const { data, error } = await supabase.rpc("get_usage_status", { _guest_hash: hash });
		if (error) return {
			allowed: true,
			used: 0,
			limit: 0,
			plan: "guest",
			remaining: 0,
			error: error.message
		};
		return data;
	}, (r) => Boolean(r.error) && isTransientRpcError(r.error), { label: "usage_status" });
}
//#endregion
export { pushRecent as a, newIdempotencyKey as i, getRecent as n, getUsageStatus as r, checkAndRecord as t };
