import { r as require_jsx_runtime } from "../_libs/react+tanstack__react-query.mjs";
import { n as Layout } from "./Layout-8Jn4q3kq.mjs";
import { t as Reveal } from "./Reveal-CydLpVW7.mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/about-CEaMtYYa.js
var import_jsx_runtime = require_jsx_runtime();
function About() {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Layout, { children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("section", {
		className: "mx-auto max-w-3xl px-4 py-20 sm:px-6",
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Reveal, { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h1", {
				className: "text-4xl font-bold text-slate-900 sm:text-5xl dark:text-white",
				style: { fontFamily: "'Space Grotesk', sans-serif" },
				children: "About UniversalTools"
			}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
				className: "mt-4 text-lg text-slate-600 dark:text-slate-300",
				children: "We were tired of opening five different websites just to count words, merge a PDF and crop an image. So we built one home for everything."
			})] }),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Reveal, {
				delay: .1,
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h2", {
					className: "mt-12 text-2xl font-bold text-slate-900 dark:text-white",
					children: "Our mission"
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
					className: "mt-3 text-slate-600 dark:text-slate-400",
					children: "Make everyday digital chores fast, free and private. No uploads, no ads, no learning curve."
				})]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Reveal, {
				delay: .2,
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h2", {
					className: "mt-12 text-2xl font-bold text-slate-900 dark:text-white",
					children: "How it works"
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
					className: "mt-3 text-slate-600 dark:text-slate-400",
					children: "Every tool runs inside your browser using modern web APIs. That means instant results and zero file uploads."
				})]
			})
		]
	}) });
}
//#endregion
export { About as component };
