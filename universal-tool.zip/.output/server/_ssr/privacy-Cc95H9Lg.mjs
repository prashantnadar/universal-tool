import { r as require_jsx_runtime } from "../_libs/react+tanstack__react-query.mjs";
import { n as Layout } from "./Layout-8Jn4q3kq.mjs";
import { t as Reveal } from "./Reveal-CydLpVW7.mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/privacy-Cc95H9Lg.js
var import_jsx_runtime = require_jsx_runtime();
function Privacy() {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Layout, { children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("section", {
		className: "mx-auto max-w-3xl px-4 py-12 sm:px-6",
		children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Reveal, { children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
				className: "text-sm font-semibold uppercase tracking-wider text-blue-600",
				children: "Legal"
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h1", {
				className: "mt-1 text-3xl font-bold text-slate-900 sm:text-4xl dark:text-white",
				style: { fontFamily: "'Space Grotesk', sans-serif" },
				children: "Privacy Policy"
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
				className: "mt-2 text-sm text-slate-500 dark:text-slate-400",
				children: ["Last updated: ", "July 1, 2026"]
			})
		] }), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
			className: "prose prose-slate mt-8 max-w-none space-y-6 text-slate-700 dark:prose-invert dark:text-slate-300",
			children: [
				/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("section", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h2", {
					className: "text-xl font-bold text-slate-900 dark:text-white",
					children: "1. Overview"
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", { children: "UniversalTools (\"we\", \"our\", \"us\") is a free web app that provides text, PDF, image, code and password utilities. We are committed to protecting your privacy. This page explains what we collect, why, and your rights." })] }),
				/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("section", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h2", {
					className: "text-xl font-bold text-slate-900 dark:text-white",
					children: "2. Files never leave your device"
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", { children: [
					"All tools run entirely inside your browser using JavaScript. Your PDFs, images, and text are ",
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("strong", { children: "never uploaded to our servers" }),
					". Processing happens locally on your device."
				] })] }),
				/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("section", { children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h2", {
						className: "text-xl font-bold text-slate-900 dark:text-white",
						children: "3. Data we store locally"
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", { children: [
						"We use your browser's ",
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("code", { children: "localStorage" }),
						" to remember:"
					] }),
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("ul", {
						className: "list-disc space-y-1 pl-6",
						children: [
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("li", { children: "Your theme preference (light or dark)." }),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("li", { children: "Anonymous tool-usage counts, used only to rank \"trending\" tools for you." }),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("li", { children: "Recently opened tools for quick access." })
						]
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", { children: "You can clear this at any time by clearing site data in your browser." })
				] }),
				/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("section", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h2", {
					className: "text-xl font-bold text-slate-900 dark:text-white",
					children: "4. Account data"
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", { children: "If you create an account (coming soon), we collect your email address and an encrypted password hash to authenticate you. We never sell your data." })] }),
				/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("section", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h2", {
					className: "text-xl font-bold text-slate-900 dark:text-white",
					children: "5. Cookies & analytics"
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", { children: "We use privacy-friendly analytics to understand aggregate traffic patterns. No personally identifying information is stored in cookies for advertising." })] }),
				/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("section", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h2", {
					className: "text-xl font-bold text-slate-900 dark:text-white",
					children: "6. Your rights"
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", { children: [
					"You have the right to access, correct, or delete any personal data we hold. Contact us via the ",
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("a", {
						href: "/contact",
						className: "text-blue-600 hover:underline",
						children: "Contact page"
					}),
					"."
				] })] }),
				/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("section", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h2", {
					className: "text-xl font-bold text-slate-900 dark:text-white",
					children: "7. Changes"
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", { children: "We may update this policy. Material changes will be highlighted on this page." })] })
			]
		})]
	}) });
}
//#endregion
export { Privacy as component };
