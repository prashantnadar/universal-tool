//#region node_modules/.nitro/vite/services/ssr/assets/usage-log-DqdX7H0u.js
function logUsage(event, payload = {}) {
	const line = `${`[usage:${event}]`} ${payload.tool ?? payload.status ?? ""}`.trim();
	(event === "error" || event === "blocked" ? console.warn : event === "retry" ? console.debug : console.info)(line, payload);
}
//#endregion
export { logUsage as t };
