import { r as require_jsx_runtime } from "../_libs/react+tanstack__react-query.mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/Skeleton-C9Gtenx-.js
var import_jsx_runtime = require_jsx_runtime();
function Skeleton({ className = "" }) {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
		role: "status",
		"aria-label": "Loading",
		className: `animate-pulse rounded-md bg-slate-200/70 dark:bg-slate-700/50 ${className}`
	});
}
function SkeletonLines({ count = 3 }) {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
		className: "space-y-2",
		role: "status",
		"aria-label": "Loading results",
		children: Array.from({ length: count }).map((_, i) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Skeleton, { className: `h-3 ${i === count - 1 ? "w-2/3" : "w-full"}` }, i))
	});
}
function InlineSpinner({ className = "" }) {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("svg", {
		className: `h-4 w-4 animate-spin ${className}`,
		viewBox: "0 0 24 24",
		fill: "none",
		"aria-hidden": "true",
		children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("circle", {
			cx: "12",
			cy: "12",
			r: "10",
			stroke: "currentColor",
			strokeOpacity: "0.25",
			strokeWidth: "4"
		}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("path", {
			d: "M22 12a10 10 0 0 1-10 10",
			stroke: "currentColor",
			strokeWidth: "4",
			strokeLinecap: "round"
		})]
	});
}
//#endregion
export { Skeleton as n, SkeletonLines as r, InlineSpinner as t };
