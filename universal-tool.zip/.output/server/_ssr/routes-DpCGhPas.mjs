import { o as __toESM } from "../_runtime.mjs";
import { nt as require_react } from "../_libs/@hookform/resolvers+[...].mjs";
import { g as Link } from "../_libs/@tanstack/react-router+[...].mjs";
import { r as require_jsx_runtime } from "../_libs/react+tanstack__react-query.mjs";
import { a as Search, c as Image, d as CodeXml, n as Type, r as Timer, s as KeyRound, t as X, u as FileText } from "../_libs/lucide-react.mjs";
import { n as AnimatePresence, t as motion } from "../_libs/framer-motion.mjs";
import { n as Layout, r as TOOLS } from "./Layout-8Jn4q3kq.mjs";
import { t as Reveal } from "./Reveal-CydLpVW7.mjs";
import { n as getRecent } from "./usage-limits-DDl6NoXq.mjs";
import { a as subscribeUsage, r as getTopUsed } from "./usage-tracking-C1qv9W3k.mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/routes-DpCGhPas.js
var import_react = /* @__PURE__ */ __toESM(require_react());
var import_jsx_runtime = require_jsx_runtime();
var CATS$1 = [
	{
		id: "all",
		label: "All"
	},
	{
		id: "text",
		label: "Text"
	},
	{
		id: "pdf",
		label: "PDF"
	},
	{
		id: "image",
		label: "Image"
	},
	{
		id: "code",
		label: "Code"
	},
	{
		id: "password",
		label: "Password"
	},
	{
		id: "color",
		label: "Color"
	},
	{
		id: "productivity",
		label: "Productivity"
	}
];
var PAGE = 12;
function CategoryToolFinder() {
	const [cat, setCat] = (0, import_react.useState)("all");
	const [q, setQ] = (0, import_react.useState)("");
	const [visible, setVisible] = (0, import_react.useState)(PAGE);
	const filtered = (0, import_react.useMemo)(() => {
		const needle = q.trim().toLowerCase();
		return TOOLS.filter((t) => {
			if (cat !== "all" && t.category !== cat) return false;
			if (!needle) return true;
			return t.name.toLowerCase().includes(needle) || t.description.toLowerCase().includes(needle) || t.keywords.some((k) => k.toLowerCase().includes(needle));
		});
	}, [cat, q]);
	const shown = filtered.slice(0, visible);
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Reveal, { children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "rounded-2xl border border-slate-200 bg-white p-4 shadow-sm dark:border-slate-800 dark:bg-slate-900 sm:p-6",
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
				className: "flex flex-col gap-3 sm:flex-row sm:items-center sm:justify-between",
				children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "relative flex-1",
					children: [
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Search, {
							size: 16,
							className: "pointer-events-none absolute left-3 top-1/2 -translate-y-1/2 text-slate-400",
							"aria-hidden": true
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
							type: "search",
							value: q,
							onChange: (e) => {
								setQ(e.target.value);
								setVisible(PAGE);
							},
							placeholder: "Search tools by name, keyword, or description…",
							"aria-label": "Search tools",
							title: "Search tools",
							className: "w-full rounded-xl border border-slate-200 bg-white py-2.5 pl-9 pr-9 text-sm text-slate-900 outline-none transition placeholder:text-slate-400 focus:border-blue-500 focus:ring-2 focus:ring-blue-500/20 dark:border-slate-700 dark:bg-slate-950 dark:text-white"
						}),
						q && /* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
							type: "button",
							onClick: () => setQ(""),
							"aria-label": "Clear search",
							title: "Clear search",
							className: "absolute right-2 top-1/2 -translate-y-1/2 rounded-lg p-1 text-slate-500 hover:bg-slate-100 hover:text-slate-900 dark:hover:bg-slate-800 dark:hover:text-white",
							children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(X, { size: 14 })
						})
					]
				})
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
				className: "mt-4 flex flex-wrap gap-2",
				role: "tablist",
				"aria-label": "Filter by category",
				children: CATS$1.map((c) => {
					const active = cat === c.id;
					return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
						role: "tab",
						"aria-selected": active,
						title: `Show ${c.label} tools`,
						"aria-label": `Show ${c.label} tools`,
						onClick: () => {
							setCat(c.id);
							setVisible(PAGE);
						},
						className: `rounded-full border px-3 py-1.5 text-xs font-semibold transition ${active ? "border-blue-600 bg-blue-600 text-white shadow-sm shadow-blue-600/30" : "border-slate-200 bg-white text-slate-700 hover:border-blue-300 hover:text-blue-700 dark:border-slate-700 dark:bg-slate-950 dark:text-slate-300"}`,
						children: c.label
					}, c.id);
				})
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
				className: "mt-5 min-h-[80px]",
				children: filtered.length === 0 ? /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
					className: "py-6 text-center text-sm text-slate-500 dark:text-slate-400",
					children: [
						"No tools match “",
						q,
						"”. Try a different keyword."
					]
				}) : /* @__PURE__ */ (0, import_jsx_runtime.jsx)(motion.div, {
					layout: true,
					className: "grid gap-3 sm:grid-cols-2 lg:grid-cols-3",
					children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(AnimatePresence, {
						mode: "popLayout",
						children: shown.map((t, i) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)(motion.div, {
							layout: true,
							initial: {
								opacity: 0,
								y: 12
							},
							animate: {
								opacity: 1,
								y: 0
							},
							exit: {
								opacity: 0,
								y: -8
							},
							transition: {
								duration: .25,
								delay: Math.min(i, 8) * .02,
								ease: [
									.22,
									1,
									.36,
									1
								]
							},
							children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Link, {
								to: t.route,
								title: `${t.name} — ${t.description}`,
								"aria-label": `Open ${t.name}`,
								className: "group flex h-full items-start gap-3 rounded-xl border border-slate-200 bg-white p-3 transition hover:-translate-y-0.5 hover:border-blue-300 hover:shadow-md dark:border-slate-800 dark:bg-slate-950",
								children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
									className: "grid h-9 w-9 shrink-0 place-items-center rounded-lg bg-blue-50 text-[10px] font-bold uppercase text-blue-700 dark:bg-blue-950 dark:text-blue-300",
									children: t.category.slice(0, 3)
								}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", {
									className: "min-w-0 flex-1",
									children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
										className: "block truncate text-sm font-semibold text-slate-900 dark:text-white",
										children: t.name
									}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
										className: "block truncate text-xs text-slate-500 dark:text-slate-400",
										children: t.description
									})]
								})]
							})
						}, t.id))
					})
				})
			}),
			filtered.length > visible && /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "mt-5 flex items-center justify-between text-sm",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", {
					className: "text-slate-500 dark:text-slate-400",
					children: [
						"Showing ",
						shown.length,
						" of ",
						filtered.length
					]
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
					type: "button",
					onClick: () => setVisible((v) => v + PAGE),
					title: "Load more tools",
					"aria-label": "Load more tools",
					className: "rounded-lg border border-slate-200 bg-white px-3 py-1.5 font-semibold text-slate-900 transition hover:border-blue-400 hover:text-blue-700 dark:border-slate-700 dark:bg-slate-950 dark:text-white",
					children: "Show more"
				})]
			})
		]
	}) });
}
var CATS = [
	{
		to: "/tools/text",
		title: "Text Tools",
		desc: "Counters, case converters, cleaners, encoders",
		count: TOOLS.filter((t) => t.category === "text").length,
		accent: "from-blue-500 to-cyan-400",
		Icon: Type
	},
	{
		to: "/tools/pdf",
		title: "PDF Tools",
		desc: "Merge, split, password, rotate, reorder",
		count: TOOLS.filter((t) => t.category === "pdf").length,
		accent: "from-blue-600 to-indigo-500",
		Icon: FileText
	},
	{
		to: "/tools/image",
		title: "Image Tools",
		desc: "Resize, crop, filter, convert, metadata",
		count: TOOLS.filter((t) => t.category === "image").length,
		accent: "from-sky-500 to-blue-600",
		Icon: Image
	},
	{
		to: "/tools/code",
		title: "Code Tools",
		desc: "JSON, XML, JWT, regex, hashes, UUIDs",
		count: TOOLS.filter((t) => t.category === "code").length,
		accent: "from-indigo-500 to-purple-500",
		Icon: CodeXml
	},
	{
		to: "/tools/password",
		title: "Password Tools",
		desc: "Generator, strength meter, passphrases, PINs",
		count: TOOLS.filter((t) => t.category === "password").length,
		accent: "from-emerald-500 to-teal-500",
		Icon: KeyRound
	},
	{
		to: "/tools/productivity",
		title: "Productivity Tools",
		desc: "Timer, to-do, calculators, unit converters",
		count: 20,
		accent: "from-amber-500 to-orange-500",
		Icon: Timer
	}
];
var FALLBACK_TRENDING = [
	TOOLS.find((t) => t.id === "pdf-merge"),
	TOOLS.find((t) => t.id === "word-count"),
	TOOLS.find((t) => t.id === "pw-generate")
];
function Home() {
	const [recent, setRecent] = (0, import_react.useState)([]);
	const [trending, setTrending] = (0, import_react.useState)([]);
	(0, import_react.useEffect)(() => {
		const refresh = () => {
			setRecent(getRecent().map((id) => TOOLS.find((t) => t.id === id)).filter(Boolean));
			const top = getTopUsed(3).map(({ id, count }) => {
				const tool = TOOLS.find((t) => t.id === id);
				return tool ? {
					tool,
					count
				} : null;
			}).filter(Boolean);
			setTrending(top);
		};
		refresh();
		return subscribeUsage(refresh);
	}, []);
	const trendingDisplay = trending.length > 0 ? trending : FALLBACK_TRENDING.map((t) => ({
		tool: t,
		count: 0
	}));
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Layout, { children: [
		/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("section", {
			className: "relative overflow-hidden border-b border-slate-200 bg-linear-to-b from-blue-50/60 via-white to-white dark:border-slate-800 dark:from-blue-950/40 dark:via-slate-950 dark:to-slate-950",
			children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
				className: "absolute inset-x-0 top-0 -z-10 h-[480px] bg-[radial-gradient(closest-side,rgba(37,99,235,0.18),transparent)]",
				"aria-hidden": true
			}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
				className: "mx-auto max-w-7xl px-4 py-16 sm:px-6 sm:py-24 lg:py-28",
				children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(motion.div, {
					initial: {
						opacity: 0,
						y: 16
					},
					animate: {
						opacity: 1,
						y: 0
					},
					transition: { duration: .6 },
					className: "mx-auto max-w-3xl text-center",
					children: [
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", {
							className: "inline-flex items-center gap-2 rounded-full border border-blue-200 bg-white/70 px-3 py-1 text-xs font-semibold text-blue-700 backdrop-blur dark:border-blue-900 dark:bg-blue-950/60 dark:text-blue-300",
							children: [
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", { className: "h-1.5 w-1.5 rounded-full bg-blue-500" }),
								" ",
								TOOLS.length,
								"+ tools · runs in your browser · no uploads"
							]
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("h1", {
							className: "mt-5 text-4xl font-bold tracking-tight text-slate-900 sm:text-6xl dark:text-white",
							style: { fontFamily: "'Space Grotesk', sans-serif" },
							children: [
								"One toolkit for ",
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
									className: "bg-linear-to-r from-blue-600 to-cyan-500 bg-clip-text text-transparent",
									children: "everything you write,"
								}),
								" ",
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
									className: "bg-linear-to-r from-blue-600 to-indigo-500 bg-clip-text text-transparent",
									children: "code and share."
								})
							]
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
							className: "mx-auto mt-5 max-w-2xl text-lg text-slate-600 dark:text-slate-300",
							children: "Text, PDF, image, code and password utilities — all in your browser. Nothing leaves your device."
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
							className: "mt-8 flex flex-wrap items-center justify-center gap-3",
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("a", {
								href: "#find-a-tool",
								onClick: (e) => {
									e.preventDefault();
									document.getElementById("find-a-tool")?.scrollIntoView({
										behavior: "smooth",
										block: "start"
									});
								},
								className: "inline-flex items-center gap-2 rounded-xl bg-blue-600 px-5 py-3 font-semibold text-white shadow-lg shadow-blue-600/30 transition hover:bg-blue-700",
								children: "Explore tools →"
							}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Link, {
								to: "/pricing",
								className: "inline-flex items-center rounded-xl border border-slate-200 bg-white px-5 py-3 font-semibold text-slate-900 transition hover:border-blue-500 hover:text-blue-700 dark:border-slate-700 dark:bg-slate-900 dark:text-white",
								children: "See pricing"
							})]
						})
					]
				})
			})]
		}),
		/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("section", {
			className: "mx-auto max-w-7xl px-4 pt-14 sm:px-6",
			"aria-labelledby": "find-a-tool",
			children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Reveal, { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h2", {
				id: "find-a-tool",
				className: "text-2xl font-bold text-slate-900 sm:text-3xl dark:text-white",
				style: { fontFamily: "'Space Grotesk', sans-serif" },
				children: "Find a tool"
			}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
				className: "mt-2 text-slate-600 dark:text-slate-400",
				children: "Search across every tool, or filter by category for instant suggestions."
			})] }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
				className: "mt-6",
				children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(CategoryToolFinder, {})
			})]
		}),
		/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("section", {
			className: "mx-auto max-w-7xl px-4 py-16 sm:px-6",
			children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Reveal, { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h2", {
				className: "text-2xl font-bold text-slate-900 sm:text-3xl dark:text-white",
				style: { fontFamily: "'Space Grotesk', sans-serif" },
				children: "Browse by category"
			}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
				className: "mt-2 text-slate-600 dark:text-slate-400",
				children: "Six focused categories covering every kind of tool you might need."
			})] }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
				className: "mt-8 grid gap-5 sm:grid-cols-2 lg:grid-cols-3",
				children: CATS.map((c, i) => {
					const Icon = c.Icon;
					return /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Reveal, {
						delay: i * .06,
						children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Link, {
							to: c.to,
							title: `${c.title} — ${c.desc}`,
							className: "group block h-full rounded-2xl border border-slate-200 bg-white p-6 shadow-sm transition hover:-translate-y-1 hover:border-blue-300 hover:shadow-xl hover:shadow-blue-500/10 dark:border-slate-800 dark:bg-slate-900",
							children: [
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
									className: `mb-4 grid h-12 w-12 place-items-center rounded-xl bg-gradient-to-br ${c.accent} text-white shadow-md`,
									"aria-hidden": true,
									children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Icon, {
										size: 24,
										strokeWidth: 2.2
									})
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h3", {
									className: "text-lg font-bold text-slate-900 dark:text-white",
									children: c.title
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
									className: "mt-1 text-sm text-slate-600 dark:text-slate-400",
									children: c.desc
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
									className: "mt-4 flex items-center justify-between text-sm font-semibold text-blue-600 dark:text-blue-400",
									children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", { children: c.count > 0 ? `${c.count} tools` : "Explore" }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
										"aria-hidden": true,
										className: "transition group-hover:translate-x-1",
										children: "→"
									})]
								})
							]
						})
					}, c.to);
				})
			})]
		}),
		/* @__PURE__ */ (0, import_jsx_runtime.jsx)("section", {
			className: "border-y border-slate-200 bg-slate-50 dark:border-slate-800 dark:bg-slate-900/40",
			children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "mx-auto max-w-7xl px-4 py-16 sm:px-6",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Reveal, { children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
					className: "flex items-end justify-between gap-4",
					children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h2", {
						className: "text-2xl font-bold text-slate-900 sm:text-3xl dark:text-white",
						style: { fontFamily: "'Space Grotesk', sans-serif" },
						children: "Trending on your device"
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
						className: "mt-2 text-slate-600 dark:text-slate-400",
						children: trending.length > 0 ? "Tools you've used the most." : "Use a tool to see it ranked here."
					})] })
				}) }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
					className: "mt-8 grid gap-4 md:grid-cols-3",
					children: trendingDisplay.map((p, i) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Reveal, {
						delay: i * .08,
						children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Link, {
							to: p.tool.route,
							className: "group flex h-full items-center gap-4 rounded-2xl border border-slate-200 bg-white p-5 transition hover:border-blue-300 hover:shadow-lg dark:border-slate-800 dark:bg-slate-950",
							children: [
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
									className: "grid h-12 w-12 shrink-0 place-items-center rounded-xl bg-blue-100 text-sm font-bold uppercase text-blue-700 dark:bg-blue-950 dark:text-blue-300",
									children: p.tool.category.slice(0, 3)
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", {
									className: "min-w-0 flex-1",
									children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
										className: "block truncate font-semibold text-slate-900 dark:text-white",
										children: p.tool.name
									}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
										className: "block text-xs text-slate-500 dark:text-slate-400",
										children: p.count > 0 ? `${p.count} use${p.count === 1 ? "" : "s"} so far` : p.tool.description
									})]
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
									className: "rounded-full bg-blue-50 px-2 py-1 text-xs font-semibold text-blue-700 dark:bg-blue-950 dark:text-blue-300",
									children: p.count > 0 ? `#${i + 1}` : "Popular"
								})
							]
						})
					}, p.tool.id))
				})]
			})
		}),
		recent.length > 0 && /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("section", {
			className: "mx-auto max-w-7xl px-4 py-16 sm:px-6",
			children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Reveal, { children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("h2", {
				className: "text-2xl font-bold text-slate-900 sm:text-3xl dark:text-white",
				style: { fontFamily: "'Space Grotesk', sans-serif" },
				children: "Recently used"
			}) }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
				className: "mt-6 grid gap-3 sm:grid-cols-2 lg:grid-cols-3",
				children: recent.map((t) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Link, {
					to: t.route,
					className: "rounded-xl border border-slate-200 bg-white p-4 transition hover:border-blue-300 dark:border-slate-800 dark:bg-slate-900",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
						className: "text-sm font-semibold text-slate-900 dark:text-white",
						children: t.name
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
						className: "text-xs text-slate-500 dark:text-slate-400",
						children: t.description
					})]
				}, t.id))
			})]
		}),
		/* @__PURE__ */ (0, import_jsx_runtime.jsx)("section", {
			className: "mx-auto max-w-7xl px-4 py-16 sm:px-6",
			children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
				className: "grid gap-6 md:grid-cols-3",
				children: [
					{
						t: "Private by design",
						d: "Everything runs in your browser. Your files never touch a server."
					},
					{
						t: "Lightning fast",
						d: "No uploads, no queues. Tools run instantly on your device."
					},
					{
						t: "Fair pricing",
						d: "Most tools are free. A few advanced tools unlock with Pro."
					}
				].map((f, i) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Reveal, {
					delay: i * .08,
					children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "h-full rounded-2xl border border-slate-200 bg-white p-6 dark:border-slate-800 dark:bg-slate-900",
						children: [
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
								className: "grid h-10 w-10 place-items-center rounded-lg bg-blue-600 text-white",
								children: "✓"
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h3", {
								className: "mt-4 font-bold text-slate-900 dark:text-white",
								children: f.t
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
								className: "mt-1 text-sm text-slate-600 dark:text-slate-400",
								children: f.d
							})
						]
					})
				}, f.t))
			})
		})
	] });
}
//#endregion
export { Home as component };
