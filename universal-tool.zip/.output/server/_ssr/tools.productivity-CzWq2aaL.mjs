import { o as __toESM } from "../_runtime.mjs";
import { nt as require_react } from "../_libs/@hookform/resolvers+[...].mjs";
import { r as require_jsx_runtime } from "../_libs/react+tanstack__react-query.mjs";
import { n as Layout } from "./Layout-8Jn4q3kq.mjs";
import { t as Reveal } from "./Reveal-CydLpVW7.mjs";
import { o as trackUse } from "./usage-tracking-C1qv9W3k.mjs";
import { t as CopyButton } from "./CopyDownload-BgPQcrMS.mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/tools.productivity-CzWq2aaL.js
var import_react = /* @__PURE__ */ __toESM(require_react());
var import_jsx_runtime = require_jsx_runtime();
function Card({ id, toolId, title, desc, children }) {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Reveal, {
		as: "section",
		children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("section", {
			id,
			"data-tool-id": toolId,
			className: "scroll-mt-32 rounded-2xl border border-slate-200 bg-white p-6 dark:border-slate-800 dark:bg-slate-900",
			children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h2", {
				className: "text-lg font-bold text-slate-900 dark:text-white",
				style: { fontFamily: "'Space Grotesk', sans-serif" },
				children: title
			}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
				className: "mt-1 text-sm text-slate-600 dark:text-slate-400",
				children: desc
			})] }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
				className: "mt-4",
				children
			})]
		})
	});
}
var btn = "inline-flex items-center rounded-lg bg-blue-600 px-4 py-2 text-sm font-semibold text-white transition hover:bg-blue-700 disabled:opacity-50";
var btnAlt = "inline-flex items-center rounded-lg border border-slate-200 bg-white px-3 py-2 text-sm font-medium text-slate-700 hover:border-blue-500 dark:border-slate-700 dark:bg-slate-950 dark:text-slate-200";
var inp = "w-full rounded-lg border border-slate-200 bg-white px-3 py-2 text-sm dark:border-slate-700 dark:bg-slate-950 dark:text-white";
var sel = inp;
function ConverterCard({ id, toolId, title, desc, units, defaultFrom, defaultTo }) {
	const [value, setValue] = (0, import_react.useState)("1");
	const [from, setFrom] = (0, import_react.useState)(defaultFrom);
	const [to, setTo] = (0, import_react.useState)(defaultTo);
	const num = parseFloat(value);
	const result = (0, import_react.useMemo)(() => {
		if (!isFinite(num)) return "";
		const out = num * units[from].factor / units[to].factor;
		trackUse(toolId);
		return formatNum(out);
	}, [
		num,
		from,
		to
	]);
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Card, {
		id,
		toolId,
		title,
		desc,
		children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
			className: "grid gap-3 sm:grid-cols-[1fr_auto_1fr] sm:items-end",
			children: [
				/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("label", {
						className: "text-xs font-medium text-slate-600 dark:text-slate-300",
						children: "From"
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
						type: "number",
						value,
						onChange: (e) => setValue(e.target.value),
						className: inp,
						"aria-label": `${title} input`
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("select", {
						value: from,
						onChange: (e) => setFrom(e.target.value),
						className: `${sel} mt-2`,
						"aria-label": `${title} from unit`,
						children: Object.entries(units).map(([k, v]) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)("option", {
							value: k,
							children: v.label
						}, k))
					})
				] }),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
					type: "button",
					onClick: () => {
						setFrom(to);
						setTo(from);
					},
					className: `${btnAlt} h-10 justify-center`,
					"aria-label": "swap units",
					title: "Swap",
					children: "⇄"
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("label", {
						className: "text-xs font-medium text-slate-600 dark:text-slate-300",
						children: "To"
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
						className: `${inp} font-mono tabular-nums`,
						"aria-live": "polite",
						children: result
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("select", {
						value: to,
						onChange: (e) => setTo(e.target.value),
						className: `${sel} mt-2`,
						"aria-label": `${title} to unit`,
						children: Object.entries(units).map(([k, v]) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)("option", {
							value: k,
							children: v.label
						}, k))
					})
				] })
			]
		})
	});
}
function formatNum(n) {
	if (!isFinite(n)) return "";
	const abs = Math.abs(n);
	if (abs !== 0 && (abs < 1e-4 || abs >= 0xe8d4a51000)) return n.toExponential(6);
	return parseFloat(n.toPrecision(10)).toString();
}
function TimerCard() {
	const [mins, setMins] = (0, import_react.useState)(5);
	const [secs, setSecs] = (0, import_react.useState)(0);
	const [remaining, setRemaining] = (0, import_react.useState)(0);
	const [running, setRunning] = (0, import_react.useState)(false);
	const ref = (0, import_react.useRef)(null);
	(0, import_react.useEffect)(() => {
		if (!running) return;
		ref.current = window.setInterval(() => {
			setRemaining((r) => {
				if (r <= 1) {
					setRunning(false);
					try {
						const ctx = new (window.AudioContext || window.webkitAudioContext)();
						const osc = ctx.createOscillator();
						osc.frequency.value = 880;
						osc.connect(ctx.destination);
						osc.start();
						setTimeout(() => {
							osc.stop();
							ctx.close();
						}, 400);
					} catch {}
					return 0;
				}
				return r - 1;
			});
		}, 1e3);
		return () => {
			if (ref.current) window.clearInterval(ref.current);
		};
	}, [running]);
	const start = () => {
		const total = Math.max(0, mins * 60 + secs);
		if (!total) return;
		if (!remaining) setRemaining(total);
		setRunning(true);
		trackUse("timer");
	};
	const pause = () => setRunning(false);
	const reset = () => {
		setRunning(false);
		setRemaining(0);
	};
	const display = remaining || mins * 60 + secs;
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Card, {
		id: "timer",
		toolId: "timer",
		title: "Timer",
		desc: "Countdown timer with an alarm.",
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "text-center font-mono text-5xl font-bold tabular-nums text-slate-900 dark:text-white",
				children: [
					Math.floor(display / 60).toString().padStart(2, "0"),
					":",
					(display % 60).toString().padStart(2, "0")
				]
			}),
			!remaining && /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "mt-4 grid grid-cols-2 gap-3",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("label", {
					className: "text-sm",
					children: ["Minutes", /* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
						type: "number",
						min: 0,
						max: 999,
						value: mins,
						onChange: (e) => setMins(Math.max(0, +e.target.value || 0)),
						className: `${inp} mt-1`
					})]
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("label", {
					className: "text-sm",
					children: ["Seconds", /* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
						type: "number",
						min: 0,
						max: 59,
						value: secs,
						onChange: (e) => setSecs(Math.min(59, Math.max(0, +e.target.value || 0))),
						className: `${inp} mt-1`
					})]
				})]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "mt-4 flex flex-wrap gap-2",
				children: [!running ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
					onClick: start,
					className: btn,
					children: "Start"
				}) : /* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
					onClick: pause,
					className: btn,
					children: "Pause"
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
					onClick: reset,
					className: btnAlt,
					children: "Reset"
				})]
			})
		]
	});
}
var TODO_KEY = "ut.productivity.todos.v1";
function TodoCard() {
	const [items, setItems] = (0, import_react.useState)([]);
	const [text, setText] = (0, import_react.useState)("");
	(0, import_react.useEffect)(() => {
		try {
			const raw = localStorage.getItem(TODO_KEY);
			if (raw) setItems(JSON.parse(raw));
		} catch {}
	}, []);
	(0, import_react.useEffect)(() => {
		try {
			localStorage.setItem(TODO_KEY, JSON.stringify(items));
		} catch {}
	}, [items]);
	const add = () => {
		const t = text.trim();
		if (!t) return;
		setItems((x) => [...x, {
			id: crypto.randomUUID(),
			text: t,
			done: false
		}]);
		setText("");
		trackUse("todo");
	};
	const toggle = (id) => setItems((x) => x.map((i) => i.id === id ? {
		...i,
		done: !i.done
	} : i));
	const remove = (id) => setItems((x) => x.filter((i) => i.id !== id));
	const clearDone = () => setItems((x) => x.filter((i) => !i.done));
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Card, {
		id: "todo",
		toolId: "todo",
		title: "To-Do List",
		desc: "Simple task list saved in your browser.",
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "flex gap-2",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
					value: text,
					onChange: (e) => setText(e.target.value),
					onKeyDown: (e) => e.key === "Enter" && add(),
					placeholder: "Add a task…",
					className: inp,
					"aria-label": "new task"
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
					onClick: add,
					className: btn,
					children: "Add"
				})]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("ul", {
				className: "mt-3 divide-y divide-slate-100 dark:divide-slate-800",
				children: [items.length === 0 && /* @__PURE__ */ (0, import_jsx_runtime.jsx)("li", {
					className: "py-3 text-sm text-slate-500",
					children: "No tasks yet."
				}), items.map((i) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("li", {
					className: "flex items-center gap-3 py-2",
					children: [
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
							type: "checkbox",
							checked: i.done,
							onChange: () => toggle(i.id),
							"aria-label": `toggle ${i.text}`
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
							className: `flex-1 text-sm ${i.done ? "text-slate-400 line-through" : "text-slate-800 dark:text-slate-200"}`,
							children: i.text
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
							onClick: () => remove(i.id),
							className: "text-xs text-red-600 hover:underline",
							"aria-label": `remove ${i.text}`,
							children: "Remove"
						})
					]
				}, i.id))]
			}),
			items.some((i) => i.done) && /* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
				onClick: clearDone,
				className: `${btnAlt} mt-3`,
				children: "Clear completed"
			})
		]
	});
}
function CalculatorCard() {
	const [expr, setExpr] = (0, import_react.useState)("");
	const [result, setResult] = (0, import_react.useState)("");
	const evaluate = () => {
		try {
			const clean = expr.replace(/[^0-9+\-*/().%\s]/g, "");
			if (!clean) return;
			const val = Function(`"use strict"; return (${clean})`)();
			setResult(String(val));
			trackUse("calculator");
		} catch {
			setResult("Error");
		}
	};
	const press = (v) => {
		if (v === "=") {
			evaluate();
			return;
		}
		if (v === "C") {
			setExpr("");
			setResult("");
			return;
		}
		if (v === "⌫") {
			setExpr((e) => e.slice(0, -1));
			return;
		}
		setExpr((e) => e + v);
	};
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Card, {
		id: "calculator",
		toolId: "calculator",
		title: "Calculator",
		desc: "Basic arithmetic calculator.",
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
				value: expr,
				onChange: (e) => setExpr(e.target.value),
				onKeyDown: (e) => e.key === "Enter" && evaluate(),
				placeholder: "e.g. 12*(3+4)",
				className: `${inp} font-mono`,
				"aria-label": "expression"
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
				className: "mt-2 rounded-lg bg-slate-950 p-3 text-right font-mono text-2xl text-emerald-300 tabular-nums",
				"aria-live": "polite",
				children: result || "0"
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "mt-3 grid grid-cols-4 gap-2",
				children: [
					[
						"7",
						"8",
						"9",
						"/",
						"4",
						"5",
						"6",
						"*",
						"1",
						"2",
						"3",
						"-",
						"0",
						".",
						"%",
						"+"
					].map((k) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
						onClick: () => press(k),
						className: `${btnAlt} justify-center`,
						children: k
					}, k)),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
						onClick: () => press("C"),
						className: `${btnAlt} justify-center`,
						children: "C"
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
						onClick: () => press("⌫"),
						className: `${btnAlt} justify-center`,
						children: "⌫"
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
						onClick: () => press("("),
						className: `${btnAlt} justify-center`,
						children: "("
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
						onClick: () => press(")"),
						className: `${btnAlt} justify-center`,
						children: ")"
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
						onClick: evaluate,
						className: `${btn} col-span-4 justify-center`,
						children: "="
					})
				]
			})
		]
	});
}
var CURRENCY = {
	USD: {
		label: "USD — US Dollar",
		perUSD: 1
	},
	EUR: {
		label: "EUR — Euro",
		perUSD: .92
	},
	GBP: {
		label: "GBP — British Pound",
		perUSD: .79
	},
	INR: {
		label: "INR — Indian Rupee",
		perUSD: 83.2
	},
	JPY: {
		label: "JPY — Japanese Yen",
		perUSD: 155
	},
	AUD: {
		label: "AUD — Australian Dollar",
		perUSD: 1.52
	},
	CAD: {
		label: "CAD — Canadian Dollar",
		perUSD: 1.36
	},
	CHF: {
		label: "CHF — Swiss Franc",
		perUSD: .88
	},
	CNY: {
		label: "CNY — Chinese Yuan",
		perUSD: 7.24
	},
	AED: {
		label: "AED — UAE Dirham",
		perUSD: 3.67
	},
	SGD: {
		label: "SGD — Singapore Dollar",
		perUSD: 1.35
	},
	SAR: {
		label: "SAR — Saudi Riyal",
		perUSD: 3.75
	}
};
function CurrencyCard() {
	const [amount, setAmount] = (0, import_react.useState)("100");
	const [from, setFrom] = (0, import_react.useState)("USD");
	const [to, setTo] = (0, import_react.useState)("INR");
	const n = parseFloat(amount);
	const converted = isFinite(n) ? n / CURRENCY[from].perUSD * CURRENCY[to].perUSD : NaN;
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Card, {
		id: "currency",
		toolId: "currency",
		title: "Currency Converter",
		desc: "Convert between major currencies using reference rates.",
		children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
			className: "grid gap-3 sm:grid-cols-[1fr_auto_1fr] sm:items-end",
			children: [
				/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("label", {
						className: "text-xs font-medium text-slate-600 dark:text-slate-300",
						children: "Amount"
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
						type: "number",
						value: amount,
						onChange: (e) => {
							setAmount(e.target.value);
							trackUse("currency");
						},
						className: inp,
						"aria-label": "amount"
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("select", {
						value: from,
						onChange: (e) => setFrom(e.target.value),
						className: `${sel} mt-2`,
						"aria-label": "from currency",
						children: Object.entries(CURRENCY).map(([k, v]) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)("option", {
							value: k,
							children: v.label
						}, k))
					})
				] }),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
					onClick: () => {
						setFrom(to);
						setTo(from);
					},
					className: `${btnAlt} h-10 justify-center`,
					"aria-label": "swap",
					children: "⇄"
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("label", {
						className: "text-xs font-medium text-slate-600 dark:text-slate-300",
						children: "Converted"
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
						className: `${inp} font-mono tabular-nums`,
						"aria-live": "polite",
						children: isFinite(converted) ? converted.toFixed(2) : ""
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("select", {
						value: to,
						onChange: (e) => setTo(e.target.value),
						className: `${sel} mt-2`,
						"aria-label": "to currency",
						children: Object.entries(CURRENCY).map(([k, v]) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)("option", {
							value: k,
							children: v.label
						}, k))
					})
				] })
			]
		}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
			className: "mt-2 text-xs text-slate-500",
			children: "Rates are indicative reference values, not live market rates."
		})]
	});
}
var TIMEZONES = [
	"UTC",
	"America/New_York",
	"America/Los_Angeles",
	"America/Chicago",
	"America/Toronto",
	"Europe/London",
	"Europe/Paris",
	"Europe/Berlin",
	"Europe/Moscow",
	"Africa/Cairo",
	"Asia/Dubai",
	"Asia/Kolkata",
	"Asia/Karachi",
	"Asia/Singapore",
	"Asia/Hong_Kong",
	"Asia/Shanghai",
	"Asia/Tokyo",
	"Australia/Sydney",
	"Pacific/Auckland"
];
function TimezoneCard() {
	const now = /* @__PURE__ */ new Date();
	const [dt, setDt] = (0, import_react.useState)((/* @__PURE__ */ new Date(now.getTime() - now.getTimezoneOffset() * 6e4)).toISOString().slice(0, 16));
	const [from, setFrom] = (0, import_react.useState)(Intl.DateTimeFormat().resolvedOptions().timeZone || "UTC");
	const [to, setTo] = (0, import_react.useState)("UTC");
	const fmt = (tz) => {
		try {
			const [d, t] = dt.split("T");
			const [y, mo, da] = d.split("-").map(Number);
			const [h, mi] = t.split(":").map(Number);
			const naiveUTC = Date.UTC(y, mo - 1, da, h, mi);
			const fromOffset = tzOffset(new Date(naiveUTC), from);
			const instant = new Date(naiveUTC - fromOffset);
			return new Intl.DateTimeFormat(void 0, {
				timeZone: tz,
				dateStyle: "medium",
				timeStyle: "short"
			}).format(instant);
		} catch {
			return "";
		}
	};
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Card, {
		id: "timezone",
		toolId: "timezone",
		title: "Timezone Converter",
		desc: "Convert a date/time from one timezone to another.",
		children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
			className: "grid gap-3 sm:grid-cols-2",
			children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("label", {
				className: "text-sm",
				children: ["Date & time", /* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
					type: "datetime-local",
					value: dt,
					onChange: (e) => {
						setDt(e.target.value);
						trackUse("timezone");
					},
					className: `${inp} mt-1`
				})]
			}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "grid grid-cols-2 gap-2",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("label", {
					className: "text-sm",
					children: ["From", /* @__PURE__ */ (0, import_jsx_runtime.jsx)("select", {
						value: from,
						onChange: (e) => setFrom(e.target.value),
						className: `${sel} mt-1`,
						children: TIMEZONES.map((t) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)("option", { children: t }, t))
					})]
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("label", {
					className: "text-sm",
					children: ["To", /* @__PURE__ */ (0, import_jsx_runtime.jsx)("select", {
						value: to,
						onChange: (e) => setTo(e.target.value),
						className: `${sel} mt-1`,
						children: TIMEZONES.map((t) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)("option", { children: t }, t))
					})]
				})]
			})]
		}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
			className: "mt-3 rounded-lg bg-slate-50 p-3 text-sm dark:bg-slate-950",
			"aria-live": "polite",
			children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [
				/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", {
					className: "font-semibold",
					children: [
						"In ",
						to,
						":"
					]
				}),
				" ",
				fmt(to)
			] })
		})]
	});
}
function tzOffset(date, tz) {
	const utc = new Date(date.toLocaleString("en-US", { timeZone: "UTC" }));
	return new Date(date.toLocaleString("en-US", { timeZone: tz })).getTime() - utc.getTime();
}
var LENGTH_UNITS = {
	km: {
		label: "Kilometer (km)",
		factor: 1e3
	},
	m: {
		label: "Meter (m)",
		factor: 1
	},
	dm: {
		label: "Decimeter (dm)",
		factor: .1
	},
	cm: {
		label: "Centimeter (cm)",
		factor: .01
	},
	mm: {
		label: "Millimeter (mm)",
		factor: .001
	},
	um: {
		label: "Micrometer (µm)",
		factor: 1e-6
	},
	nm: {
		label: "Nanometer (nm)",
		factor: 1e-9
	},
	pm: {
		label: "Picometer (pm)",
		factor: 1e-12
	},
	mi: {
		label: "Mile (mi)",
		factor: 1609.344
	},
	yd: {
		label: "Yard (yd)",
		factor: .9144
	},
	ft: {
		label: "Foot (ft)",
		factor: .3048
	},
	in: {
		label: "Inch (in)",
		factor: .0254
	},
	nmi: {
		label: "Nautical mile",
		factor: 1852
	},
	ly: {
		label: "Light year",
		factor: 9461e12
	}
};
var MASS_UNITS = {
	t: {
		label: "Tonne (t)",
		factor: 1e6
	},
	kg: {
		label: "Kilogram (kg)",
		factor: 1e3
	},
	g: {
		label: "Gram (g)",
		factor: 1
	},
	mg: {
		label: "Milligram (mg)",
		factor: .001
	},
	ug: {
		label: "Microgram (µg)",
		factor: 1e-6
	},
	ng: {
		label: "Nanogram (ng)",
		factor: 1e-9
	},
	lb: {
		label: "Pound (lb)",
		factor: 453.592
	},
	oz: {
		label: "Ounce (oz)",
		factor: 28.3495
	},
	st: {
		label: "Stone (st)",
		factor: 6350.29
	},
	ct: {
		label: "Carat (ct)",
		factor: .2
	}
};
var AREA_UNITS = {
	km2: {
		label: "Square kilometer (km²)",
		factor: 1e6
	},
	ha: {
		label: "Hectare (ha)",
		factor: 1e4
	},
	ac: {
		label: "Acre (ac)",
		factor: 4046.86
	},
	m2: {
		label: "Square meter (m²)",
		factor: 1
	},
	dm2: {
		label: "Square decimeter (dm²)",
		factor: .01
	},
	cm2: {
		label: "Square centimeter (cm²)",
		factor: 1e-4
	},
	mm2: {
		label: "Square millimeter (mm²)",
		factor: 1e-6
	},
	ft2: {
		label: "Square foot (ft²)",
		factor: .092903
	},
	in2: {
		label: "Square inch (in²)",
		factor: 64516e-8
	},
	yd2: {
		label: "Square yard (yd²)",
		factor: .836127
	},
	mi2: {
		label: "Square mile (mi²)",
		factor: 259e4
	}
};
var TIME_UNITS = {
	y: {
		label: "Year",
		factor: 31536e3
	},
	mo: {
		label: "Month (30d)",
		factor: 2592e3
	},
	wk: {
		label: "Week",
		factor: 604800
	},
	d: {
		label: "Day",
		factor: 86400
	},
	h: {
		label: "Hour",
		factor: 3600
	},
	min: {
		label: "Minute",
		factor: 60
	},
	s: {
		label: "Second",
		factor: 1
	},
	ms: {
		label: "Millisecond",
		factor: .001
	},
	us: {
		label: "Microsecond",
		factor: 1e-6
	},
	ns: {
		label: "Nanosecond",
		factor: 1e-9
	}
};
var DATA_UNITS = {
	bit: {
		label: "Bit",
		factor: 1 / 8
	},
	B: {
		label: "Byte (B)",
		factor: 1
	},
	KB: {
		label: "Kilobyte (KB)",
		factor: 1024
	},
	MB: {
		label: "Megabyte (MB)",
		factor: 1024 ** 2
	},
	GB: {
		label: "Gigabyte (GB)",
		factor: 1024 ** 3
	},
	TB: {
		label: "Terabyte (TB)",
		factor: 1024 ** 4
	},
	PB: {
		label: "Petabyte (PB)",
		factor: 1024 ** 5
	},
	EB: {
		label: "Exabyte (EB)",
		factor: 1024 ** 6
	}
};
var VOLUME_UNITS = {
	m3: {
		label: "Cubic meter (m³)",
		factor: 1e3
	},
	L: {
		label: "Liter (L)",
		factor: 1
	},
	mL: {
		label: "Milliliter (mL)",
		factor: .001
	},
	cm3: {
		label: "Cubic centimeter (cm³)",
		factor: .001
	},
	gal_us: {
		label: "US Gallon",
		factor: 3.78541
	},
	gal_uk: {
		label: "UK Gallon",
		factor: 4.54609
	},
	qt: {
		label: "US Quart",
		factor: .946353
	},
	pt: {
		label: "US Pint",
		factor: .473176
	},
	cup: {
		label: "US Cup",
		factor: .24
	},
	floz: {
		label: "US Fluid ounce",
		factor: .0295735
	},
	tbsp: {
		label: "Tablespoon",
		factor: .0147868
	},
	tsp: {
		label: "Teaspoon",
		factor: .00492892
	},
	ft3: {
		label: "Cubic foot (ft³)",
		factor: 28.3168
	},
	in3: {
		label: "Cubic inch (in³)",
		factor: .0163871
	},
	bbl: {
		label: "Oil barrel (bbl)",
		factor: 158.987
	}
};
var SPEED_UNITS = {
	mps: {
		label: "Meter/second (m/s)",
		factor: 1
	},
	kph: {
		label: "Kilometer/hour (km/h)",
		factor: 1 / 3.6
	},
	mph: {
		label: "Mile/hour (mph)",
		factor: .44704
	},
	fps: {
		label: "Foot/second (ft/s)",
		factor: .3048
	},
	kn: {
		label: "Knot (kn)",
		factor: .514444
	},
	mach: {
		label: "Mach (at sea level)",
		factor: 343
	},
	c: {
		label: "Speed of light (c)",
		factor: 299792458
	}
};
function TemperatureCard() {
	const [value, setValue] = (0, import_react.useState)("100");
	const [from, setFrom] = (0, import_react.useState)("C");
	const [to, setTo] = (0, import_react.useState)("F");
	const n = parseFloat(value);
	const toC = (v, u) => u === "C" ? v : u === "F" ? (v - 32) * 5 / 9 : v - 273.15;
	const fromC = (v, u) => u === "C" ? v : u === "F" ? v * 9 / 5 + 32 : v + 273.15;
	const result = isFinite(n) ? formatNum(fromC(toC(n, from), to)) : "";
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Card, {
		id: "temperature",
		toolId: "temperature",
		title: "Temperature Converter",
		desc: "Celsius, Fahrenheit and Kelvin.",
		children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
			className: "grid gap-3 sm:grid-cols-[1fr_auto_1fr] sm:items-end",
			children: [
				/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("label", {
						className: "text-xs font-medium text-slate-600 dark:text-slate-300",
						children: "From"
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
						type: "number",
						value,
						onChange: (e) => {
							setValue(e.target.value);
							trackUse("temperature");
						},
						className: inp
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("select", {
						value: from,
						onChange: (e) => setFrom(e.target.value),
						className: `${sel} mt-2`,
						children: [
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("option", {
								value: "C",
								children: "Celsius (°C)"
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("option", {
								value: "F",
								children: "Fahrenheit (°F)"
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("option", {
								value: "K",
								children: "Kelvin (K)"
							})
						]
					})
				] }),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
					onClick: () => {
						setFrom(to);
						setTo(from);
					},
					className: `${btnAlt} h-10 justify-center`,
					children: "⇄"
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("label", {
						className: "text-xs font-medium text-slate-600 dark:text-slate-300",
						children: "To"
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
						className: `${inp} font-mono tabular-nums`,
						"aria-live": "polite",
						children: result
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("select", {
						value: to,
						onChange: (e) => setTo(e.target.value),
						className: `${sel} mt-2`,
						children: [
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("option", {
								value: "C",
								children: "Celsius (°C)"
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("option", {
								value: "F",
								children: "Fahrenheit (°F)"
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("option", {
								value: "K",
								children: "Kelvin (K)"
							})
						]
					})
				] })
			]
		})
	});
}
function FinanceCard() {
	const [mode, setMode] = (0, import_react.useState)("loan");
	const [principal, setPrincipal] = (0, import_react.useState)("100000");
	const [rate, setRate] = (0, import_react.useState)("8");
	const [years, setYears] = (0, import_react.useState)("5");
	const [loanOut, setLoanOut] = (0, import_react.useState)(null);
	const calcLoan = () => {
		const P = parseFloat(principal);
		const r = parseFloat(rate) / 100 / 12;
		const n = parseFloat(years) * 12;
		if (!isFinite(P) || !isFinite(r) || !isFinite(n) || n <= 0) return;
		const emi = r === 0 ? P / n : P * r * Math.pow(1 + r, n) / (Math.pow(1 + r, n) - 1);
		const total = emi * n;
		setLoanOut({
			emi,
			total,
			interest: total - P
		});
		trackUse("finance");
	};
	const [invType, setInvType] = (0, import_react.useState)("one-time");
	const [invAmount, setInvAmount] = (0, import_react.useState)("10000");
	const [invRate, setInvRate] = (0, import_react.useState)("12");
	const [invYears, setInvYears] = (0, import_react.useState)("10");
	const [invOut, setInvOut] = (0, import_react.useState)(null);
	const calcInvest = () => {
		const A = parseFloat(invAmount);
		const r = parseFloat(invRate) / 100;
		const y = parseFloat(invYears);
		if (!isFinite(A) || !isFinite(r) || !isFinite(y)) return;
		if (invType === "one-time") {
			const fv = A * Math.pow(1 + r, y);
			setInvOut({
				future: fv,
				invested: A,
				gain: fv - A
			});
		} else {
			const n = y * 12;
			const mr = r / 12;
			const fv = mr === 0 ? A * n : A * ((Math.pow(1 + mr, n) - 1) / mr) * (1 + mr);
			setInvOut({
				future: fv,
				invested: A * n,
				gain: fv - A * n
			});
		}
		trackUse("finance");
	};
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Card, {
		id: "finance",
		toolId: "finance",
		title: "Finance Calculator",
		desc: "Loan EMI and investment growth.",
		children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
			className: "flex gap-4 text-sm",
			children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("label", {
				className: "flex items-center gap-1.5",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
					type: "radio",
					name: "fin-mode",
					checked: mode === "loan",
					onChange: () => setMode("loan")
				}), " Loan"]
			}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("label", {
				className: "flex items-center gap-1.5",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
					type: "radio",
					name: "fin-mode",
					checked: mode === "invest",
					onChange: () => setMode("invest")
				}), " Investment"]
			})]
		}), mode === "loan" ? /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
			className: "mt-4 space-y-3",
			children: [
				/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("label", {
					className: "block text-sm",
					children: ["Principal amount", /* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
						type: "number",
						value: principal,
						onChange: (e) => setPrincipal(e.target.value),
						className: `${inp} mt-1`
					})]
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("label", {
					className: "block text-sm",
					children: ["Interest rate (annual %)", /* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
						type: "number",
						step: "0.01",
						value: rate,
						onChange: (e) => setRate(e.target.value),
						className: `${inp} mt-1`
					})]
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("label", {
					className: "block text-sm",
					children: ["Duration (years)", /* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
						type: "number",
						value: years,
						onChange: (e) => setYears(e.target.value),
						className: `${inp} mt-1`
					})]
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
					onClick: calcLoan,
					className: btn,
					children: "Calculate"
				}),
				loanOut && /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "rounded-lg bg-slate-50 p-3 text-sm dark:bg-slate-950",
					"aria-live": "polite",
					children: [
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: ["Monthly EMI: ", /* @__PURE__ */ (0, import_jsx_runtime.jsx)("strong", {
							className: "font-mono tabular-nums",
							children: loanOut.emi.toFixed(2)
						})] }),
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: ["Total payment: ", /* @__PURE__ */ (0, import_jsx_runtime.jsx)("strong", {
							className: "font-mono tabular-nums",
							children: loanOut.total.toFixed(2)
						})] }),
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: ["Total interest: ", /* @__PURE__ */ (0, import_jsx_runtime.jsx)("strong", {
							className: "font-mono tabular-nums",
							children: loanOut.interest.toFixed(2)
						})] })
					]
				})
			]
		}) : /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
			className: "mt-4 space-y-3",
			children: [
				/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("label", {
					className: "block text-sm",
					children: ["Investment type", /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("select", {
						value: invType,
						onChange: (e) => setInvType(e.target.value),
						className: `${sel} mt-1`,
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("option", {
							value: "one-time",
							children: "One-time (lump sum)"
						}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("option", {
							value: "recurring",
							children: "Recurring (monthly SIP)"
						})]
					})]
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("label", {
					className: "block text-sm",
					children: [invType === "one-time" ? "Amount invested" : "Monthly contribution", /* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
						type: "number",
						value: invAmount,
						onChange: (e) => setInvAmount(e.target.value),
						className: `${inp} mt-1`
					})]
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("label", {
					className: "block text-sm",
					children: ["Expected annual return (%)", /* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
						type: "number",
						step: "0.01",
						value: invRate,
						onChange: (e) => setInvRate(e.target.value),
						className: `${inp} mt-1`
					})]
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("label", {
					className: "block text-sm",
					children: ["Duration (years)", /* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
						type: "number",
						value: invYears,
						onChange: (e) => setInvYears(e.target.value),
						className: `${inp} mt-1`
					})]
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
					onClick: calcInvest,
					className: btn,
					children: "Calculate"
				}),
				invOut && /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "rounded-lg bg-slate-50 p-3 text-sm dark:bg-slate-950",
					"aria-live": "polite",
					children: [
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: ["Future value: ", /* @__PURE__ */ (0, import_jsx_runtime.jsx)("strong", {
							className: "font-mono tabular-nums",
							children: invOut.future.toFixed(2)
						})] }),
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: ["Total invested: ", /* @__PURE__ */ (0, import_jsx_runtime.jsx)("strong", {
							className: "font-mono tabular-nums",
							children: invOut.invested.toFixed(2)
						})] }),
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: ["Estimated gain: ", /* @__PURE__ */ (0, import_jsx_runtime.jsx)("strong", {
							className: "font-mono tabular-nums",
							children: invOut.gain.toFixed(2)
						})] })
					]
				})
			]
		})]
	});
}
function DateDiffCard() {
	const today = (/* @__PURE__ */ new Date()).toISOString().slice(0, 10);
	const [from, setFrom] = (0, import_react.useState)(today);
	const [to, setTo] = (0, import_react.useState)(today);
	const out = (0, import_react.useMemo)(() => {
		const a = new Date(from);
		const b = new Date(to);
		if (isNaN(a.getTime()) || isNaN(b.getTime())) return null;
		const start = a <= b ? a : b;
		const end = a <= b ? b : a;
		let years = end.getFullYear() - start.getFullYear();
		let months = end.getMonth() - start.getMonth();
		let days = end.getDate() - start.getDate();
		if (days < 0) {
			months--;
			const prev = new Date(end.getFullYear(), end.getMonth(), 0).getDate();
			days += prev;
		}
		if (months < 0) {
			years--;
			months += 12;
		}
		const totalDays = Math.round((end.getTime() - start.getTime()) / 864e5);
		return {
			years,
			months,
			days,
			totalDays
		};
	}, [from, to]);
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Card, {
		id: "date-diff",
		toolId: "date-diff",
		title: "Date Difference",
		desc: "Years, months and days between two dates.",
		children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
			className: "grid gap-3 sm:grid-cols-2",
			children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("label", {
				className: "text-sm",
				children: ["From", /* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
					type: "date",
					value: from,
					onChange: (e) => {
						setFrom(e.target.value);
						trackUse("date-diff");
					},
					className: `${inp} mt-1`
				})]
			}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("label", {
				className: "text-sm",
				children: ["To", /* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
					type: "date",
					value: to,
					onChange: (e) => {
						setTo(e.target.value);
						trackUse("date-diff");
					},
					className: `${inp} mt-1`
				})]
			})]
		}), out && /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
			className: "mt-3 rounded-lg bg-slate-50 p-3 text-sm dark:bg-slate-950",
			"aria-live": "polite",
			children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("strong", {
					className: "font-mono",
					children: out.years
				}),
				" years, ",
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("strong", {
					className: "font-mono",
					children: out.months
				}),
				" months, ",
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("strong", {
					className: "font-mono",
					children: out.days
				}),
				" days"
			] }), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "mt-1 text-slate-500",
				children: [
					"Total: ",
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
						className: "font-mono",
						children: out.totalDays
					}),
					" days"
				]
			})]
		})]
	});
}
function DiscountCard() {
	const [price, setPrice] = (0, import_react.useState)("1000");
	const [discount, setDiscount] = (0, import_react.useState)("20");
	const p = parseFloat(price);
	const d = parseFloat(discount);
	const finalPrice = isFinite(p) && isFinite(d) ? p - p * d / 100 : NaN;
	const savings = isFinite(p) && isFinite(d) ? p * d / 100 : NaN;
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Card, {
		id: "discount",
		toolId: "discount",
		title: "Discount Calculator",
		desc: "Final price after applying a percentage discount.",
		children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
			className: "grid gap-3 sm:grid-cols-2",
			children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("label", {
				className: "text-sm",
				children: ["Original price", /* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
					type: "number",
					value: price,
					onChange: (e) => {
						setPrice(e.target.value);
						trackUse("discount");
					},
					className: `${inp} mt-1`
				})]
			}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("label", {
				className: "text-sm",
				children: ["Discount (%)", /* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
					type: "number",
					value: discount,
					onChange: (e) => {
						setDiscount(e.target.value);
						trackUse("discount");
					},
					className: `${inp} mt-1`
				})]
			})]
		}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
			className: "mt-3 rounded-lg bg-slate-50 p-3 text-sm dark:bg-slate-950",
			"aria-live": "polite",
			children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: ["Final price: ", /* @__PURE__ */ (0, import_jsx_runtime.jsx)("strong", {
				className: "font-mono tabular-nums",
				children: isFinite(finalPrice) ? finalPrice.toFixed(2) : ""
			})] }), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: ["You save: ", /* @__PURE__ */ (0, import_jsx_runtime.jsx)("strong", {
				className: "font-mono tabular-nums",
				children: isFinite(savings) ? savings.toFixed(2) : ""
			})] })]
		})]
	});
}
function BMICard() {
	const [age, setAge] = (0, import_react.useState)("30");
	const [gender, setGender] = (0, import_react.useState)("male");
	const [height, setHeight] = (0, import_react.useState)("170");
	const [weight, setWeight] = (0, import_react.useState)("70");
	const h = parseFloat(height) / 100;
	const w = parseFloat(weight);
	const bmi = isFinite(h) && h > 0 && isFinite(w) ? w / (h * h) : NaN;
	const cat = isFinite(bmi) ? bmi < 18.5 ? "Underweight" : bmi < 25 ? "Normal" : bmi < 30 ? "Overweight" : "Obese" : "";
	const color = !isFinite(bmi) ? "" : bmi < 18.5 ? "text-amber-600" : bmi < 25 ? "text-emerald-600" : bmi < 30 ? "text-orange-600" : "text-red-600";
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Card, {
		id: "bmi",
		toolId: "bmi",
		title: "BMI Calculator",
		desc: "Body Mass Index based on height and weight.",
		children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
			className: "grid gap-3 sm:grid-cols-2",
			children: [
				/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("label", {
					className: "text-sm",
					children: ["Age", /* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
						type: "number",
						value: age,
						onChange: (e) => {
							setAge(e.target.value);
							trackUse("bmi");
						},
						className: `${inp} mt-1`
					})]
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("label", {
					className: "text-sm",
					children: ["Gender", /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "mt-1 flex gap-3",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("label", {
							className: "flex items-center gap-1.5 text-sm",
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
								type: "radio",
								name: "bmi-g",
								checked: gender === "male",
								onChange: () => setGender("male")
							}), " Male"]
						}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("label", {
							className: "flex items-center gap-1.5 text-sm",
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
								type: "radio",
								name: "bmi-g",
								checked: gender === "female",
								onChange: () => setGender("female")
							}), " Female"]
						})]
					})]
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("label", {
					className: "text-sm",
					children: ["Height (cm)", /* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
						type: "number",
						value: height,
						onChange: (e) => {
							setHeight(e.target.value);
							trackUse("bmi");
						},
						className: `${inp} mt-1`
					})]
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("label", {
					className: "text-sm",
					children: ["Weight (kg)", /* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
						type: "number",
						value: weight,
						onChange: (e) => {
							setWeight(e.target.value);
							trackUse("bmi");
						},
						className: `${inp} mt-1`
					})]
				})
			]
		}), isFinite(bmi) && /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
			className: "mt-3 rounded-lg bg-slate-50 p-3 text-sm dark:bg-slate-950",
			"aria-live": "polite",
			children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [
				"BMI: ",
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("strong", {
					className: `font-mono tabular-nums text-lg ${color}`,
					children: bmi.toFixed(1)
				}),
				" — ",
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
					className: color,
					children: cat
				})
			] }), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "mt-1 text-xs text-slate-500",
				children: [
					"Age ",
					age,
					", ",
					gender,
					". BMI ranges are the same for adult men and women."
				]
			})]
		})]
	});
}
function GSTCard() {
	const [amount, setAmount] = (0, import_react.useState)("1000");
	const [rate, setRate] = (0, import_react.useState)("18");
	const [mode, setMode] = (0, import_react.useState)("add");
	const a = parseFloat(amount);
	const r = parseFloat(rate);
	let net = NaN, tax = NaN, gross = NaN;
	if (isFinite(a) && isFinite(r)) if (mode === "add") {
		net = a;
		tax = a * r / 100;
		gross = net + tax;
	} else {
		gross = a;
		net = a / (1 + r / 100);
		tax = gross - net;
	}
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Card, {
		id: "gst",
		toolId: "gst",
		title: "GST Calculator",
		desc: "Add GST to a net amount or extract GST from a gross amount.",
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "grid gap-3 sm:grid-cols-2",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("label", {
					className: "text-sm",
					children: ["Amount", /* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
						type: "number",
						value: amount,
						onChange: (e) => {
							setAmount(e.target.value);
							trackUse("gst");
						},
						className: `${inp} mt-1`
					})]
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("label", {
					className: "text-sm",
					children: ["GST rate (%)", /* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
						type: "number",
						value: rate,
						onChange: (e) => {
							setRate(e.target.value);
							trackUse("gst");
						},
						className: `${inp} mt-1`
					})]
				})]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "mt-2 flex gap-4 text-sm",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("label", {
					className: "flex items-center gap-1.5",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
						type: "radio",
						name: "gst-mode",
						checked: mode === "add",
						onChange: () => setMode("add")
					}), " Add GST"]
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("label", {
					className: "flex items-center gap-1.5",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
						type: "radio",
						name: "gst-mode",
						checked: mode === "remove",
						onChange: () => setMode("remove")
					}), " Remove GST"]
				})]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "mt-3 rounded-lg bg-slate-50 p-3 text-sm dark:bg-slate-950",
				"aria-live": "polite",
				children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: ["Net: ", /* @__PURE__ */ (0, import_jsx_runtime.jsx)("strong", {
						className: "font-mono tabular-nums",
						children: isFinite(net) ? net.toFixed(2) : ""
					})] }),
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: ["GST: ", /* @__PURE__ */ (0, import_jsx_runtime.jsx)("strong", {
						className: "font-mono tabular-nums",
						children: isFinite(tax) ? tax.toFixed(2) : ""
					})] }),
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: ["Gross: ", /* @__PURE__ */ (0, import_jsx_runtime.jsx)("strong", {
						className: "font-mono tabular-nums",
						children: isFinite(gross) ? gross.toFixed(2) : ""
					})] })
				]
			})
		]
	});
}
function NumeralCard() {
	const [value, setValue] = (0, import_react.useState)("255");
	const [base, setBase] = (0, import_react.useState)(10);
	const parsed = (0, import_react.useMemo)(() => {
		const s = value.trim();
		if (!s) return null;
		const n = parseInt(s, base);
		if (isNaN(n)) return null;
		trackUse("numeral");
		return n;
	}, [value, base]);
	const clear = () => {
		setValue("");
		setBase(10);
	};
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Card, {
		id: "numeral",
		toolId: "numeral",
		title: "Numeral System Converter",
		desc: "Convert between binary, octal, decimal and hexadecimal.",
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "grid gap-3 sm:grid-cols-[1fr_auto]",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
					value,
					onChange: (e) => setValue(e.target.value),
					className: inp,
					"aria-label": "Number to convert",
					placeholder: "Enter a number"
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("select", {
					value: base,
					onChange: (e) => setBase(parseInt(e.target.value)),
					className: sel,
					"aria-label": "Input base",
					children: [
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("option", {
							value: 2,
							children: "Binary (base 2)"
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("option", {
							value: 8,
							children: "Octal (base 8)"
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("option", {
							value: 10,
							children: "Decimal (base 10)"
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("option", {
							value: 16,
							children: "Hex (base 16)"
						})
					]
				})]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "mt-4 grid gap-2 text-sm",
				children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Row, {
						label: "Binary",
						val: parsed != null ? parsed.toString(2) : ""
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Row, {
						label: "Octal",
						val: parsed != null ? parsed.toString(8) : ""
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Row, {
						label: "Decimal",
						val: parsed != null ? parsed.toString(10) : ""
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Row, {
						label: "Hex",
						val: parsed != null ? parsed.toString(16).toUpperCase() : ""
					})
				]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
				className: "mt-4 flex justify-end",
				children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
					type: "button",
					onClick: clear,
					className: btnAlt,
					title: "Clear input",
					children: "Clear"
				})
			})
		]
	});
}
function Row({ label, val }) {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "flex items-center justify-between gap-3 rounded-lg border border-slate-200 bg-slate-50 px-3 py-2 dark:border-slate-700 dark:bg-slate-950",
		children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
			className: "text-xs font-medium uppercase tracking-wide text-slate-500",
			children: label
		}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
			className: "font-mono tabular-nums text-slate-900 dark:text-white",
			children: val || "—"
		})]
	});
}
function ProductivityTools() {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Layout, { children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("section", {
		className: "mx-auto max-w-6xl px-4 py-12 sm:px-6",
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Reveal, { children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("header", {
				className: "mb-8",
				children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
						className: "text-sm font-semibold uppercase tracking-wider text-blue-600",
						children: "Productivity tools"
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h1", {
						className: "mt-1 text-3xl font-bold text-slate-900 sm:text-4xl dark:text-white",
						style: { fontFamily: "'Space Grotesk', sans-serif" },
						children: "Calculators, converters and everyday helpers"
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
						className: "mt-2 text-slate-600 dark:text-slate-400",
						children: "Timers, to-dos, unit and currency converters, finance and health calculators — all in your browser."
					})
				]
			}) }),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "grid gap-5 lg:grid-cols-2",
				children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(TimerCard, {}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(TodoCard, {}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(CalculatorCard, {}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(CurrencyCard, {}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(TimezoneCard, {}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(ConverterCard, {
						id: "unit",
						toolId: "unit",
						title: "Unit Converter (Length)",
						desc: "Quick generic unit conversion.",
						units: LENGTH_UNITS,
						defaultFrom: "m",
						defaultTo: "ft"
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(ConverterCard, {
						id: "length",
						toolId: "length",
						title: "Length Converter",
						desc: "km, m, cm, mm, µm, nm, pm, mile, yard, foot, inch.",
						units: LENGTH_UNITS,
						defaultFrom: "m",
						defaultTo: "cm"
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(ConverterCard, {
						id: "mass",
						toolId: "mass",
						title: "Mass Converter",
						desc: "tonne, kg, g, mg, µg, lb, oz, carat.",
						units: MASS_UNITS,
						defaultFrom: "kg",
						defaultTo: "lb"
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(ConverterCard, {
						id: "area",
						toolId: "area",
						title: "Area Converter",
						desc: "km², ha, acre, m², cm², ft², yd², mi².",
						units: AREA_UNITS,
						defaultFrom: "m2",
						defaultTo: "ft2"
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(ConverterCard, {
						id: "time",
						toolId: "time",
						title: "Time Converter",
						desc: "year, month, week, day, hour, minute, second, ms, µs, ns.",
						units: TIME_UNITS,
						defaultFrom: "h",
						defaultTo: "min"
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(ConverterCard, {
						id: "data",
						toolId: "data",
						title: "Data Converter",
						desc: "bit, byte, KB, MB, GB, TB, PB, EB.",
						units: DATA_UNITS,
						defaultFrom: "MB",
						defaultTo: "GB"
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(TemperatureCard, {}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(ConverterCard, {
						id: "volume",
						toolId: "volume",
						title: "Volume Converter",
						desc: "m³, L, mL, gallon (US/UK), quart, pint, cup, fl oz, tbsp, tsp, ft³, in³, barrel.",
						units: VOLUME_UNITS,
						defaultFrom: "L",
						defaultTo: "gal_us"
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(ConverterCard, {
						id: "speed",
						toolId: "speed",
						title: "Speed Converter",
						desc: "m/s, km/h, mph, ft/s, knot, mach, speed of light.",
						units: SPEED_UNITS,
						defaultFrom: "kph",
						defaultTo: "mph"
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(NumeralCard, {}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(FinanceCard, {}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(DateDiffCard, {}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(DiscountCard, {}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(BMICard, {}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(GSTCard, {})
				]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
				className: "mt-8 flex justify-end",
				children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(CopyButton, {
					getText: () => window.location.href,
					label: "Copy page URL"
				})
			})
		]
	}) });
}
//#endregion
export { ProductivityTools as component };
