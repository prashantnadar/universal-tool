import { t as logUsage } from "./usage-log-DqdX7H0u.mjs";
import { a as pushRecent, i as newIdempotencyKey, t as checkAndRecord } from "./usage-limits-DDl6NoXq.mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/usage-tracking-C1qv9W3k.js
var KEY = "ut-usage-counts";
var listeners = /* @__PURE__ */ new Set();
function getCounts() {
	if (typeof window === "undefined") return {};
	try {
		return JSON.parse(localStorage.getItem(KEY) || "{}");
	} catch {
		return {};
	}
}
var METERED_PREFIXES = {
	pdf: ["pdf-"],
	image: ["img-"]
};
function categoryFor(id) {
	if (METERED_PREFIXES.pdf.some((p) => id.startsWith(p))) return "pdf";
	if (METERED_PREFIXES.image.some((p) => id.startsWith(p))) return "image";
	return null;
}
function isMetered(id) {
	return categoryFor(id) !== null;
}
var meteredState = { latest: null };
var meteredListeners = /* @__PURE__ */ new Set();
function getMeteredUsage() {
	return meteredState.latest;
}
function subscribeMeteredUsage(cb) {
	meteredListeners.add(cb);
	return () => meteredListeners.delete(cb);
}
function setMetered(u) {
	meteredState.latest = u;
	meteredListeners.forEach((l) => l());
}
function trackUse(id) {
	if (typeof window === "undefined") return;
	const c = getCounts();
	c[id] = (c[id] || 0) + 1;
	localStorage.setItem(KEY, JSON.stringify(c));
	pushRecent(id);
	listeners.forEach((l) => l());
	if (isMetered(id)) {
		const key = newIdempotencyKey();
		checkAndRecord(id, key).then((res) => {
			setMetered(res);
			if (res.allowed) logUsage("success", {
				tool: id,
				key,
				plan: res.plan,
				used: res.used,
				limit: res.limit,
				remaining: res.remaining
			});
			else logUsage("blocked", {
				tool: id,
				key,
				plan: res.plan,
				used: res.used,
				limit: res.limit,
				remaining: res.remaining
			});
		});
	}
}
function getTopUsed(limit = 3) {
	const c = getCounts();
	return Object.entries(c).map(([id, count]) => ({
		id,
		count
	})).sort((a, b) => b.count - a.count).slice(0, limit);
}
function subscribeUsage(cb) {
	listeners.add(cb);
	return () => listeners.delete(cb);
}
//#endregion
export { subscribeUsage as a, subscribeMeteredUsage as i, getMeteredUsage as n, trackUse as o, getTopUsed as r, getCounts as t };
