import { o as __toESM } from "../_runtime.mjs";
import { nt as require_react } from "../_libs/@hookform/resolvers+[...].mjs";
import { t as supabase } from "./client-CxWkeBjE.mjs";
import { r as require_jsx_runtime } from "../_libs/react+tanstack__react-query.mjs";
import { r as useAuth } from "./auth-context-DS3dl-5u.mjs";
import { n as Layout } from "./Layout-8Jn4q3kq.mjs";
import { a as Bar, c as Legend, i as CartesianGrid, n as YAxis, o as ResponsiveContainer, r as XAxis, s as Tooltip, t as BarChart } from "../_libs/recharts+[...].mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/admin-BWXQ45wu.js
var import_react = /* @__PURE__ */ __toESM(require_react());
var import_jsx_runtime = require_jsx_runtime();
var rpc = supabase.rpc.bind(supabase);
async function adminListUsers(limit = 100, offset = 0) {
	const { data, error } = await rpc("admin_list_users", {
		_limit: limit,
		_offset: offset
	});
	if (error) throw error;
	return data ?? [];
}
async function adminSetPlan(userId, plan) {
	const { error } = await rpc("admin_set_plan", {
		_target: userId,
		_plan: plan
	});
	if (error) throw error;
}
async function adminSetRole(userId, role, grant) {
	const { error } = await rpc("admin_set_role", {
		_target: userId,
		_role: role,
		_grant: grant
	});
	if (error) throw error;
}
async function adminStats() {
	const { data, error } = await rpc("admin_stats");
	if (error) throw error;
	return data;
}
async function adminActiveUsers(minutes = 5) {
	const { data, error } = await rpc("admin_active_users", { _minutes: minutes });
	if (error) throw error;
	return data ?? [];
}
async function adminDailyTotals(days = 30) {
	const { data, error } = await rpc("admin_daily_totals", { _days: days });
	if (error) throw error;
	return data ?? [];
}
async function adminToolLeaderboard(days = 7) {
	const { data, error } = await rpc("admin_tool_leaderboard", { _days: days });
	if (error) throw error;
	return data ?? [];
}
async function adminUserHistory(userId, limit = 100, offset = 0) {
	const { data, error } = await rpc("admin_user_history", {
		_target: userId,
		_limit: limit,
		_offset: offset
	});
	if (error) throw error;
	return data ?? [];
}
async function adminUsageSearch(f = {}) {
	const { data, error } = await rpc("admin_usage_search", {
		_actor: f.actor ?? null,
		_tool: f.tool ?? null,
		_from: f.from ?? null,
		_to: f.to ?? null,
		_kind: f.kind ?? "all",
		_limit: f.limit ?? 100,
		_offset: f.offset ?? 0
	});
	if (error) throw error;
	return data ?? [];
}
async function adminAuditSearch(f = {}) {
	const { data, error } = await rpc("admin_audit_search", {
		_actor: f.actor ?? null,
		_action: f.action ?? null,
		_from: f.from ?? null,
		_to: f.to ?? null,
		_limit: f.limit ?? 100,
		_offset: f.offset ?? 0
	});
	if (error) throw error;
	return data ?? [];
}
/** Trigger a CSV download using the current session's bearer token. */
async function downloadCsv(path, filename) {
	const { data: sess } = await supabase.auth.getSession();
	const token = sess.session?.access_token;
	if (!token) throw new Error("Not signed in");
	const res = await fetch(path, { headers: { Authorization: `Bearer ${token}` } });
	if (!res.ok) throw new Error(`Export failed (${res.status})`);
	const blob = await res.blob();
	const url = URL.createObjectURL(blob);
	const a = document.createElement("a");
	a.href = url;
	a.download = filename;
	document.body.appendChild(a);
	a.click();
	a.remove();
	setTimeout(() => URL.revokeObjectURL(url), 5e3);
}
function AdminPanel() {
	const { user } = useAuth();
	const [tab, setTab] = (0, import_react.useState)("overview");
	const [err, setErr] = (0, import_react.useState)(null);
	const isSuperAdmin = user?.id === "f0a17059-c9ac-46e1-859c-82bd1487f069" || user?.email?.toLowerCase() === "prashantnadar18@gmail.com";
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Layout, { children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("section", {
		className: "mx-auto max-w-7xl px-4 py-8 sm:px-6",
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "flex items-center justify-between",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h1", {
					className: "text-3xl font-bold text-slate-900 dark:text-white",
					style: { fontFamily: "'Space Grotesk', sans-serif" },
					children: "Admin panel"
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
					className: "mt-1 text-sm text-slate-600 dark:text-slate-400",
					children: ["Signed in as ", user?.email]
				})] }), isSuperAdmin ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
					className: "rounded-full bg-blue-400 dark:bg-blue-500 px-2 py-1 text-xs font-bold text-white dark:text-white animate-pulse",
					children: "👑 SUPER ADMIN"
				}) : /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
					className: "rounded-full bg-blue-50 px-3 py-1 text-xs font-semibold text-blue-700 dark:bg-blue-950/60 dark:text-blue-300",
					children: "ADMIN"
				})]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("nav", {
				className: "mt-6 flex flex-wrap gap-1 border-b border-slate-200 dark:border-slate-800",
				children: [
					"overview",
					"live",
					"users",
					"usage",
					"audit"
				].map((t) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
					onClick: () => setTab(t),
					className: `px-4 py-2 text-sm font-medium capitalize transition-colors ${tab === t ? "border-b-2 border-blue-600 text-blue-700 dark:text-blue-300" : "text-slate-600 hover:text-slate-900 dark:text-slate-400 dark:hover:text-white"}`,
					children: t === "audit" ? "Audit logs" : t === "usage" ? "Usage logs" : t
				}, t))
			}),
			err && /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
				role: "alert",
				className: "mt-4 rounded-lg border border-red-300 bg-red-50 p-3 text-sm text-red-800 dark:border-red-900 dark:bg-red-950/40 dark:text-red-300",
				children: err
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "mt-6",
				children: [
					tab === "overview" && /* @__PURE__ */ (0, import_jsx_runtime.jsx)(OverviewTab, { onErr: setErr }),
					tab === "live" && /* @__PURE__ */ (0, import_jsx_runtime.jsx)(LiveTab, { onErr: setErr }),
					tab === "users" && /* @__PURE__ */ (0, import_jsx_runtime.jsx)(UsersTab, {
						onErr: setErr,
						currentUserId: user?.id
					}),
					tab === "usage" && /* @__PURE__ */ (0, import_jsx_runtime.jsx)(UsageTab, { onErr: setErr }),
					tab === "audit" && /* @__PURE__ */ (0, import_jsx_runtime.jsx)(AuditTab, { onErr: setErr })
				]
			})
		]
	}) });
}
function OverviewTab({ onErr }) {
	const [stats, setStats] = (0, import_react.useState)(null);
	const [daily, setDaily] = (0, import_react.useState)([]);
	const [leaders, setLeaders] = (0, import_react.useState)([]);
	const [loading, setLoading] = (0, import_react.useState)(true);
	async function load() {
		setLoading(true);
		onErr(null);
		try {
			const [s, d, l] = await Promise.all([
				adminStats(),
				adminDailyTotals(30),
				adminToolLeaderboard(7)
			]);
			setStats(s);
			setDaily(d);
			setLeaders(l);
		} catch (e) {
			onErr(e.message);
		} finally {
			setLoading(false);
		}
	}
	(0, import_react.useEffect)(() => {
		load();
	}, []);
	const chartData = (0, import_react.useMemo)(() => daily.map((d) => ({
		day: d.day.slice(5),
		signed_in: Number(d.signed_in_uses),
		guest: Number(d.guest_uses)
	})), [daily]);
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "space-y-6",
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "grid gap-4 sm:grid-cols-2 lg:grid-cols-4",
				children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Stat, {
						label: "Total users (DB)",
						value: stats?.total_users ?? "…"
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Stat, {
						label: "Signed-in active 24h",
						value: stats?.signed_in_active_24h ?? "…"
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Stat, {
						label: "Signed-in active 7d",
						value: stats?.signed_in_active_7d ?? "…"
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Stat, {
						label: "Guests active 24h",
						value: stats?.guest_active_24h ?? "…"
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Stat, {
						label: "Premium users",
						value: stats?.premium_users ?? "…"
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Stat, {
						label: "Admins",
						value: stats?.admins ?? "…"
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Stat, {
						label: "Tool uses 24h",
						value: stats?.usage_24h ?? "…"
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Stat, {
						label: "Guest uses 24h",
						value: stats?.guest_usage_24h ?? "…"
					})
				]
			}),
			stats?.plan_breakdown && /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Card, {
				title: "Plan breakdown (active subscriptions)",
				children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
					className: "flex flex-wrap gap-3",
					children: Object.entries(stats.plan_breakdown).map(([plan, n]) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "rounded-lg border border-slate-200 px-3 py-2 dark:border-slate-800",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
							className: "text-xs uppercase text-slate-500",
							children: plan
						}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
							className: "text-lg font-semibold tabular-nums text-slate-900 dark:text-white",
							children: n
						})]
					}, plan))
				})
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Card, {
				title: "Uses per day (last 30 days)",
				children: loading ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
					className: "text-sm text-slate-500",
					children: "Loading…"
				}) : /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
					className: "h-72 w-full",
					children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(ResponsiveContainer, { children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(BarChart, {
						data: chartData,
						children: [
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)(CartesianGrid, { strokeDasharray: "3 3" }),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)(XAxis, {
								dataKey: "day",
								fontSize: 11
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)(YAxis, { fontSize: 11 }),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Tooltip, {}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Legend, {}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Bar, {
								dataKey: "signed_in",
								stackId: "a",
								fill: "#2563eb",
								name: "Signed-in"
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Bar, {
								dataKey: "guest",
								stackId: "a",
								fill: "#94a3b8",
								name: "Guests"
							})
						]
					}) })
				})
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Card, {
				title: "Tool leaderboard (last 7 days)",
				children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
					className: "overflow-x-auto",
					children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("table", {
						className: "w-full text-left text-sm",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("thead", {
							className: "text-xs uppercase text-slate-500",
							children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("tr", { children: [
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)("th", {
									className: "py-2",
									children: "Tool"
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)("th", { children: "Total" }),
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)("th", { children: "Signed-in" }),
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)("th", { children: "Guest" }),
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)("th", { children: "Unique actors" })
							] })
						}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("tbody", {
							className: "divide-y divide-slate-100 dark:divide-slate-800",
							children: [leaders.map((r) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("tr", { children: [
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)("td", {
									className: "py-2 font-mono text-slate-800 dark:text-slate-200",
									children: r.tool_slug
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)("td", {
									className: "tabular-nums",
									children: r.total
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)("td", {
									className: "tabular-nums",
									children: r.signed_in
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)("td", {
									className: "tabular-nums",
									children: r.guest
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)("td", {
									className: "tabular-nums",
									children: r.unique_actors
								})
							] }, r.tool_slug)), !leaders.length && /* @__PURE__ */ (0, import_jsx_runtime.jsx)("tr", { children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("td", {
								colSpan: 5,
								className: "py-4 text-sm text-slate-500",
								children: "No usage yet."
							}) })]
						})]
					})
				})
			})
		]
	});
}
function LiveTab({ onErr }) {
	const [rows, setRows] = (0, import_react.useState)([]);
	const [minutes, setMinutes] = (0, import_react.useState)(5);
	const [loading, setLoading] = (0, import_react.useState)(true);
	const timer = (0, import_react.useRef)(null);
	async function load() {
		try {
			const data = await adminActiveUsers(minutes);
			setRows(data);
			onErr(null);
		} catch (e) {
			onErr(e.message);
		} finally {
			setLoading(false);
		}
	}
	(0, import_react.useEffect)(() => {
		setLoading(true);
		load();
		const ch = supabase.channel("admin-live-usage").on("postgres_changes", {
			event: "INSERT",
			schema: "public",
			table: "tool_usage"
		}, () => load()).on("postgres_changes", {
			event: "INSERT",
			schema: "public",
			table: "guest_usage"
		}, () => load()).subscribe();
		timer.current = window.setInterval(load, 3e4);
		return () => {
			supabase.removeChannel(ch);
			if (timer.current) window.clearInterval(timer.current);
		};
	}, [minutes]);
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Card, {
		title: `Active in the last ${minutes} min (${rows.length})`,
		right: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
			className: "flex items-center gap-2",
			children: [
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("label", {
					className: "text-xs text-slate-500",
					children: "Window"
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("select", {
					value: minutes,
					onChange: (e) => setMinutes(Number(e.target.value)),
					className: "rounded-md border border-slate-200 bg-white px-2 py-1 text-xs dark:border-slate-700 dark:bg-slate-900 dark:text-white",
					children: [
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("option", {
							value: 2,
							children: "2 min"
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("option", {
							value: 5,
							children: "5 min"
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("option", {
							value: 15,
							children: "15 min"
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("option", {
							value: 60,
							children: "1 hour"
						})
					]
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", {
					className: "ml-2 inline-flex items-center gap-1 text-xs text-emerald-600 dark:text-emerald-400",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", { className: "h-2 w-2 animate-pulse rounded-full bg-emerald-500" }), " live"]
				})
			]
		}),
		children: loading ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
			className: "text-sm text-slate-500",
			children: "Loading…"
		}) : /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
			className: "overflow-x-auto",
			children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("table", {
				className: "w-full text-left text-sm",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("thead", {
					className: "text-xs uppercase text-slate-500",
					children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("tr", { children: [
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("th", {
							className: "py-2",
							children: "Kind"
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("th", { children: "Actor" }),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("th", { children: "Plan" }),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("th", { children: "Current tool" }),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("th", { children: "Uses" }),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("th", { children: "Country" }),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("th", { children: "Last seen" })
					] })
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("tbody", {
					className: "divide-y divide-slate-100 dark:divide-slate-800",
					children: [rows.map((r) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("tr", { children: [
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("td", {
							className: "py-2",
							children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(KindBadge, { kind: r.kind })
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("td", {
							className: "text-slate-800 dark:text-slate-200",
							children: r.kind === "user" ? r.email || r.display_name || r.actor_key.slice(0, 8) : /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", {
								className: "font-mono text-xs",
								children: ["guest·", r.actor_key.slice(0, 8)]
							})
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("td", { children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(PlanBadge, { plan: r.plan }) }),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("td", {
							className: "font-mono text-xs",
							children: r.last_tool_slug
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("td", {
							className: "tabular-nums",
							children: r.uses_in_window
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("td", {
							className: "text-xs",
							children: r.country_code || "—"
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("td", {
							className: "text-xs text-slate-500",
							children: new Date(r.last_seen).toLocaleTimeString()
						})
					] }, r.kind + r.actor_key)), !rows.length && /* @__PURE__ */ (0, import_jsx_runtime.jsx)("tr", { children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("td", {
						colSpan: 7,
						className: "py-4 text-sm text-slate-500",
						children: "No active users right now."
					}) })]
				})]
			})
		})
	});
}
function UsersTab({ onErr, currentUserId }) {
	const [users, setUsers] = (0, import_react.useState)([]);
	const [loading, setLoading] = (0, import_react.useState)(true);
	const [busyId, setBusyId] = (0, import_react.useState)(null);
	const [filter, setFilter] = (0, import_react.useState)("all");
	const [drawer, setDrawer] = (0, import_react.useState)(null);
	async function load() {
		setLoading(true);
		onErr(null);
		try {
			setUsers(await adminListUsers(200, 0));
		} catch (e) {
			onErr(e.message);
		} finally {
			setLoading(false);
		}
	}
	(0, import_react.useEffect)(() => {
		load();
	}, []);
	const filtered = users.filter((u) => {
		if (filter === "all") return true;
		if (filter === "admin") return u.is_admin;
		return u.plan === filter;
	});
	async function togglePlan(u) {
		if (u.email?.toLowerCase() === "prashantnadar18@gmail.com") {
			alert("Super Admin plan cannot be changed.");
			return;
		}
		setBusyId(u.user_id);
		try {
			await adminSetPlan(u.user_id, u.plan === "premium" ? "free" : "premium");
			await load();
		} catch (e) {
			onErr(e.message);
		} finally {
			setBusyId(null);
		}
	}
	async function toggleAdmin(u) {
		if (u.email?.toLowerCase() === "prashantnadar18@gmail.com") {
			alert("Super Admin role cannot be modified.");
			return;
		}
		if (!confirm(u.is_admin ? `Revoke admin from ${u.email}?` : `Grant admin to ${u.email}?`)) return;
		setBusyId(u.user_id);
		try {
			await adminSetRole(u.user_id, "admin", !u.is_admin);
			await load();
		} catch (e) {
			onErr(e.message);
		} finally {
			setBusyId(null);
		}
	}
	async function openHistory(u) {
		try {
			const rows = await adminUserHistory(u.user_id, 100, 0);
			setDrawer({
				user: u,
				rows
			});
		} catch (e) {
			onErr(e.message);
		}
	}
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Card, {
		title: `Users (${filtered.length})`,
		right: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
			className: "flex items-center gap-2",
			children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("select", {
				value: filter,
				onChange: (e) => setFilter(e.target.value),
				className: "rounded-md border border-slate-200 bg-white px-2 py-1 text-xs dark:border-slate-700 dark:bg-slate-900 dark:text-white",
				children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("option", {
						value: "all",
						children: "All"
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("option", {
						value: "free",
						children: "Free"
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("option", {
						value: "premium",
						children: "Premium"
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("option", {
						value: "admin",
						children: "Admins"
					})
				]
			}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
				onClick: load,
				className: "rounded-md border border-slate-200 px-3 py-1 text-xs font-medium dark:border-slate-700 dark:text-white",
				children: "Refresh"
			})]
		}),
		children: [loading ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
			className: "text-sm text-slate-500",
			children: "Loading…"
		}) : /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
			className: "overflow-x-auto",
			children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("table", {
				className: "w-full text-left text-sm",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("thead", {
					className: "text-xs uppercase text-slate-500",
					children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("tr", { children: [
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("th", {
							className: "py-2",
							children: "Email"
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("th", { children: "Plan" }),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("th", { children: "Role" }),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("th", { children: "Uses 24h" }),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("th", { children: "Joined" }),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("th", {
							className: "text-right",
							children: "Actions"
						})
					] })
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("tbody", {
					className: "divide-y divide-slate-100 dark:divide-slate-800",
					children: filtered.map((u) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("tr", { children: [
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("td", {
							className: "py-2 text-slate-800 dark:text-slate-200",
							children: u.email
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("td", { children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(PlanBadge, { plan: u.plan }) }),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("td", { children: u.email?.toLowerCase() === "prashantnadar18@gmail.com" ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
							className: "rounded-full bg-blue-400 dark:bg-blue-500 px-2 py-1 text-xs font-bold text-white dark:text-white animate-pulse",
							children: "👑 SUPER ADMIN"
						}) : u.is_admin ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
							className: "rounded-full bg-blue-50 px-2 py-0.5 text-xs font-semibold text-blue-700 animate-pulse",
							children: "ADMIN"
						}) : /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
							className: "text-xs text-slate-500",
							children: "USER"
						}) }),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("td", {
							className: "tabular-nums",
							children: u.usage_24h
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("td", {
							className: "text-xs text-slate-500",
							children: new Date(u.created_at).toLocaleDateString()
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("td", {
							className: "py-2 text-right",
							children: [
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
									onClick: () => openHistory(u),
									className: "mr-2 rounded-md border border-slate-200 px-2 py-1 text-xs font-medium dark:border-slate-700 dark:text-white",
									children: "History"
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("button", {
									onClick: () => togglePlan(u),
									className: "mr-2 rounded-md border border-slate-200 px-2 py-1 text-xs font-medium disabled:opacity-50 dark:border-slate-700 dark:text-white",
									disabled: busyId === u.user_id || u.email?.toLowerCase() === "prashantnadar18@gmail.com",
									children: [
										" disabled=",
										busyId === u.user_id,
										u.plan === "premium" ? "Downgrade" : "Upgrade"
									]
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("button", {
									onClick: () => toggleAdmin(u),
									className: "rounded-md border border-slate-200 px-2 py-1 text-xs font-medium disabled:opacity-50 dark:border-slate-700 dark:text-white",
									disabled: busyId === u.user_id || u.user_id === currentUserId || u.email?.toLowerCase() === "prashantnadar18@gmail.com",
									children: [
										" disabled=",
										busyId === u.user_id || u.user_id === currentUserId,
										u.is_admin ? "Revoke admin" : "Make admin"
									]
								})
							]
						})
					] }, u.user_id))
				})]
			})
		}), drawer && /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
			className: "fixed inset-0 z-50 flex items-end justify-end bg-black/40",
			onClick: () => setDrawer(null),
			children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				onClick: (e) => e.stopPropagation(),
				className: "h-full w-full max-w-xl overflow-y-auto bg-white p-6 shadow-xl dark:bg-slate-900",
				children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "flex items-center justify-between",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("h3", {
							className: "text-lg font-semibold text-slate-900 dark:text-white",
							children: ["History — ", drawer.user.email]
						}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
							onClick: () => setDrawer(null),
							className: "text-slate-500 hover:text-slate-900 dark:hover:text-white",
							children: "✕"
						})]
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
						className: "mt-1 text-xs text-slate-500",
						children: [
							"Last ",
							drawer.rows.length,
							" tool uses"
						]
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("ul", {
						className: "mt-4 divide-y divide-slate-100 text-sm dark:divide-slate-800",
						children: [drawer.rows.map((r) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("li", {
							className: "flex items-center justify-between py-2",
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
								className: "font-mono text-slate-700 dark:text-slate-300",
								children: r.tool_slug
							}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
								className: "text-xs text-slate-500",
								children: new Date(r.created_at).toLocaleString()
							})]
						}, r.id)), !drawer.rows.length && /* @__PURE__ */ (0, import_jsx_runtime.jsx)("li", {
							className: "py-4 text-slate-500",
							children: "No usage recorded."
						})]
					})
				]
			})
		})]
	});
}
function UsageTab({ onErr }) {
	const [rows, setRows] = (0, import_react.useState)([]);
	const [loading, setLoading] = (0, import_react.useState)(false);
	const [offset, setOffset] = (0, import_react.useState)(0);
	const [tool, setTool] = (0, import_react.useState)("");
	const [actor, setActor] = (0, import_react.useState)("");
	const [kind, setKind] = (0, import_react.useState)("all");
	const [from, setFrom] = (0, import_react.useState)("");
	const [to, setTo] = (0, import_react.useState)("");
	async function load(newOffset = 0) {
		setLoading(true);
		onErr(null);
		try {
			const data = await adminUsageSearch({
				tool: tool || null,
				actor: actor || null,
				from: from ? new Date(from).toISOString() : null,
				to: to ? new Date(to).toISOString() : null,
				kind,
				limit: 100,
				offset: newOffset
			});
			setRows(data);
			setOffset(newOffset);
		} catch (e) {
			onErr(e.message);
		} finally {
			setLoading(false);
		}
	}
	(0, import_react.useEffect)(() => {
		load(0);
	}, []);
	function exportCsv() {
		const qs = new URLSearchParams();
		if (tool) qs.set("tool", tool);
		if (actor) qs.set("actor", actor);
		if (kind !== "all") qs.set("kind", kind);
		if (from) qs.set("from", new Date(from).toISOString());
		if (to) qs.set("to", new Date(to).toISOString());
		downloadCsv(`/api/admin/export/tool-usage?${qs.toString()}`, `tool-usage-${(/* @__PURE__ */ new Date()).toISOString().slice(0, 10)}.csv`).catch((e) => onErr(e.message));
	}
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Card, {
		title: "Usage logs",
		right: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
			onClick: exportCsv,
			className: "rounded-md bg-blue-600 px-3 py-1 text-xs font-semibold text-white hover:bg-blue-700",
			children: "Export CSV"
		}),
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "mb-3 grid gap-2 sm:grid-cols-3 lg:grid-cols-6",
				children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Input, {
						label: "Tool slug",
						value: tool,
						onChange: setTool,
						placeholder: "pdf-merge"
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Input, {
						label: "Actor (user id)",
						value: actor,
						onChange: setActor,
						placeholder: "uuid"
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("label", {
						className: "text-xs text-slate-500",
						children: "Kind"
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("select", {
						value: kind,
						onChange: (e) => setKind(e.target.value),
						className: "w-full rounded-md border border-slate-200 bg-white px-2 py-1 text-sm dark:border-slate-700 dark:bg-slate-900 dark:text-white",
						children: [
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("option", {
								value: "all",
								children: "All"
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("option", {
								value: "user",
								children: "Signed-in"
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("option", {
								value: "guest",
								children: "Guest"
							})
						]
					})] }),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Input, {
						label: "From",
						type: "datetime-local",
						value: from,
						onChange: setFrom
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Input, {
						label: "To",
						type: "datetime-local",
						value: to,
						onChange: setTo
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
						className: "flex items-end",
						children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
							onClick: () => load(0),
							className: "w-full rounded-md border border-slate-200 px-3 py-1 text-sm font-medium dark:border-slate-700 dark:text-white",
							children: "Search"
						})
					})
				]
			}),
			loading ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
				className: "text-sm text-slate-500",
				children: "Loading…"
			}) : /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
				className: "overflow-x-auto",
				children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("table", {
					className: "w-full text-left text-sm",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("thead", {
						className: "text-xs uppercase text-slate-500",
						children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("tr", { children: [
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("th", {
								className: "py-2",
								children: "When"
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("th", { children: "Kind" }),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("th", { children: "Actor" }),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("th", { children: "Tool" }),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("th", { children: "Country" })
						] })
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("tbody", {
						className: "divide-y divide-slate-100 dark:divide-slate-800",
						children: [rows.map((r, i) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("tr", { children: [
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("td", {
								className: "py-2 text-xs text-slate-500",
								children: new Date(r.created_at).toLocaleString()
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("td", { children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(KindBadge, { kind: r.kind }) }),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("td", {
								className: "text-slate-800 dark:text-slate-200",
								children: r.kind === "user" ? r.email || r.actor_key.slice(0, 8) : /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", {
									className: "font-mono text-xs",
									children: ["guest·", r.actor_key.slice(0, 8)]
								})
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("td", {
								className: "font-mono text-xs",
								children: r.tool_slug
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("td", {
								className: "text-xs",
								children: r.country_code || "—"
							})
						] }, i)), !rows.length && /* @__PURE__ */ (0, import_jsx_runtime.jsx)("tr", { children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("td", {
							colSpan: 5,
							className: "py-4 text-sm text-slate-500",
							children: "No rows match."
						}) })]
					})]
				})
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Pager, {
				offset,
				count: rows.length,
				onPage: load
			})
		]
	});
}
function AuditTab({ onErr }) {
	const [rows, setRows] = (0, import_react.useState)([]);
	const [loading, setLoading] = (0, import_react.useState)(false);
	const [offset, setOffset] = (0, import_react.useState)(0);
	const [action, setAction] = (0, import_react.useState)("");
	const [actor, setActor] = (0, import_react.useState)("");
	const [from, setFrom] = (0, import_react.useState)("");
	const [to, setTo] = (0, import_react.useState)("");
	async function load(newOffset = 0) {
		setLoading(true);
		onErr(null);
		try {
			const data = await adminAuditSearch({
				action: action || null,
				actor: actor || null,
				from: from ? new Date(from).toISOString() : null,
				to: to ? new Date(to).toISOString() : null,
				limit: 100,
				offset: newOffset
			});
			setRows(data);
			setOffset(newOffset);
		} catch (e) {
			onErr(e.message);
		} finally {
			setLoading(false);
		}
	}
	(0, import_react.useEffect)(() => {
		load(0);
	}, []);
	function exportCsv() {
		const qs = new URLSearchParams();
		if (action) qs.set("action", action);
		if (actor) qs.set("actor", actor);
		if (from) qs.set("from", new Date(from).toISOString());
		if (to) qs.set("to", new Date(to).toISOString());
		downloadCsv(`/api/admin/export/audit-logs?${qs.toString()}`, `audit-logs-${(/* @__PURE__ */ new Date()).toISOString().slice(0, 10)}.csv`).catch((e) => onErr(e.message));
	}
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Card, {
		title: "Audit logs",
		right: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
			onClick: exportCsv,
			className: "rounded-md bg-blue-600 px-3 py-1 text-xs font-semibold text-white hover:bg-blue-700",
			children: "Export CSV"
		}),
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "mb-3 grid gap-2 sm:grid-cols-3 lg:grid-cols-5",
				children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Input, {
						label: "Action",
						value: action,
						onChange: setAction,
						placeholder: "admin_set_plan"
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Input, {
						label: "Actor (user id)",
						value: actor,
						onChange: setActor,
						placeholder: "uuid"
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Input, {
						label: "From",
						type: "datetime-local",
						value: from,
						onChange: setFrom
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Input, {
						label: "To",
						type: "datetime-local",
						value: to,
						onChange: setTo
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
						className: "flex items-end",
						children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
							onClick: () => load(0),
							className: "w-full rounded-md border border-slate-200 px-3 py-1 text-sm font-medium dark:border-slate-700 dark:text-white",
							children: "Search"
						})
					})
				]
			}),
			loading ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
				className: "text-sm text-slate-500",
				children: "Loading…"
			}) : /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
				className: "overflow-x-auto",
				children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("table", {
					className: "w-full text-left text-sm",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("thead", {
						className: "text-xs uppercase text-slate-500",
						children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("tr", { children: [
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("th", {
								className: "py-2",
								children: "When"
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("th", { children: "Actor" }),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("th", { children: "Action" }),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("th", { children: "Metadata" })
						] })
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("tbody", {
						className: "divide-y divide-slate-100 dark:divide-slate-800",
						children: [rows.map((r) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("tr", { children: [
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("td", {
								className: "py-2 text-xs text-slate-500",
								children: new Date(r.created_at).toLocaleString()
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("td", {
								className: "text-slate-800 dark:text-slate-200",
								children: r.email || (r.actor_id ? r.actor_id.slice(0, 8) : "—")
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("td", {
								className: "font-mono text-xs",
								children: r.action
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("td", {
								className: "max-w-[24rem] truncate text-xs text-slate-500",
								title: JSON.stringify(r.metadata),
								children: JSON.stringify(r.metadata)
							})
						] }, r.id)), !rows.length && /* @__PURE__ */ (0, import_jsx_runtime.jsx)("tr", { children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("td", {
							colSpan: 4,
							className: "py-4 text-sm text-slate-500",
							children: "No rows match."
						}) })]
					})]
				})
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Pager, {
				offset,
				count: rows.length,
				onPage: load
			})
		]
	});
}
function Card({ title, right, children }) {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "rounded-2xl border border-slate-200 bg-white p-5 dark:border-slate-800 dark:bg-slate-900",
		children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
			className: "mb-3 flex items-center justify-between",
			children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h2", {
				className: "font-semibold text-slate-900 dark:text-white",
				children: title
			}), right]
		}), children]
	});
}
function Stat({ label, value }) {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "rounded-2xl border border-slate-200 bg-white p-5 shadow-sm dark:border-slate-800 dark:bg-slate-900",
		children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
			className: "text-xs font-semibold uppercase tracking-wide text-slate-500",
			children: label
		}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
			className: "mt-1 text-2xl font-bold text-slate-900 dark:text-white tabular-nums",
			children: value
		})]
	});
}
function PlanBadge({ plan }) {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
		className: `rounded-full px-2 py-0.5 text-xs font-semibold ${plan === "premium" ? "bg-emerald-50 text-emerald-700 dark:bg-emerald-950/60 dark:text-emerald-300" : plan === "admin" ? "bg-blue-50 text-blue-700 dark:bg-blue-950/60 dark:text-blue-300" : plan === "guest" ? "bg-slate-100 text-slate-600 dark:bg-slate-800 dark:text-slate-400" : "bg-slate-100 text-slate-700 dark:bg-slate-800 dark:text-slate-300"}`,
		children: plan
	});
}
function KindBadge({ kind }) {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
		className: `rounded-full px-2 py-0.5 text-xs font-semibold ${kind === "user" ? "bg-blue-50 text-blue-700 dark:bg-blue-950/60 dark:text-blue-300" : "bg-slate-100 text-slate-600 dark:bg-slate-800 dark:text-slate-400"}`,
		children: kind
	});
}
function Input({ label, value, onChange, placeholder, type = "text" }) {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("label", {
		className: "text-xs text-slate-500",
		children: label
	}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
		type,
		value,
		onChange: (e) => onChange(e.target.value),
		placeholder,
		className: "w-full rounded-md border border-slate-200 bg-white px-2 py-1 text-sm dark:border-slate-700 dark:bg-slate-900 dark:text-white"
	})] });
}
function Pager({ offset, count, onPage }) {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "mt-3 flex items-center justify-between text-xs text-slate-500",
		children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", { children: [
			"Rows ",
			offset + 1,
			"–",
			offset + count
		] }), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
			className: "flex gap-2",
			children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
				disabled: offset === 0,
				onClick: () => onPage(Math.max(0, offset - 100)),
				className: "rounded-md border border-slate-200 px-2 py-1 disabled:opacity-40 dark:border-slate-700 dark:text-white",
				children: "Prev"
			}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
				disabled: count < 100,
				onClick: () => onPage(offset + 100),
				className: "rounded-md border border-slate-200 px-2 py-1 disabled:opacity-40 dark:border-slate-700 dark:text-white",
				children: "Next"
			})]
		})]
	});
}
//#endregion
export { AdminPanel as component };
