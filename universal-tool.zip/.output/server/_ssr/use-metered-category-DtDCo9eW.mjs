import { o as __toESM } from "../_runtime.mjs";
import { nt as require_react } from "../_libs/@hookform/resolvers+[...].mjs";
import { g as Link } from "../_libs/@tanstack/react-router+[...].mjs";
import { r as require_jsx_runtime } from "../_libs/react+tanstack__react-query.mjs";
import { f as CircleAlert, l as Gauge } from "../_libs/lucide-react.mjs";
import { r as getUsageStatus } from "./usage-limits-DDl6NoXq.mjs";
import { t as Swal } from "../_libs/sweetalert2.mjs";
import { i as subscribeMeteredUsage, n as getMeteredUsage } from "./usage-tracking-C1qv9W3k.mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/use-metered-category-DtDCo9eW.js
var import_react = /* @__PURE__ */ __toESM(require_react());
var import_jsx_runtime = require_jsx_runtime();
function UsageLimitBanner({ result }) {
	if (!result) return null;
	if (result.limit < 0) return null;
	const isGuest = result.plan === "guest";
	const remaining = Math.max(result.limit - result.used, 0);
	if (result.allowed) return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: `mb-4 flex flex-wrap items-center justify-between gap-3 rounded-lg border px-4 py-2.5 text-sm ${remaining <= 1 ? "border-amber-300 bg-amber-50 text-amber-900 dark:border-amber-800 dark:bg-amber-950/40 dark:text-amber-200" : "border-slate-200 bg-slate-50 text-slate-700 dark:border-slate-800 dark:bg-slate-900/60 dark:text-slate-300"}`,
		children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
			className: "flex items-center gap-2",
			children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Gauge, {
				className: "h-4 w-4",
				"aria-hidden": true
			}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", { children: [
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("strong", {
					className: "font-semibold",
					children: remaining
				}),
				" of ",
				result.limit,
				" daily uses left",
				isGuest ? " (guest)" : ""
			] })]
		}), isGuest && /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
			className: "flex gap-2",
			children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Link, {
				to: "/auth",
				className: "rounded-md bg-blue-600 px-2.5 py-1 text-xs font-semibold text-white hover:bg-blue-700",
				children: "Sign up — get 10/day"
			}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Link, {
				to: "/pricing",
				className: "rounded-md border border-slate-300 px-2.5 py-1 text-xs font-semibold hover:bg-white dark:border-slate-700 dark:hover:bg-slate-800",
				children: "Go Premium"
			})]
		})]
	});
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		role: "alert",
		"aria-live": "assertive",
		className: "mb-4 flex items-start gap-3 rounded-lg border border-amber-300 bg-amber-50 p-4 text-sm dark:border-amber-800 dark:bg-amber-950/40",
		children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(CircleAlert, {
			className: "mt-0.5 h-5 w-5 flex-none text-amber-600",
			"aria-hidden": true
		}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
			className: "flex-1",
			children: [
				/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
					className: "font-semibold text-amber-900 dark:text-amber-200",
					children: [
						"Daily limit reached (",
						result.used,
						"/",
						result.limit,
						")"
					]
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
					className: "mt-1 text-amber-800 dark:text-amber-300",
					children: isGuest ? "Sign up for a free account to get 10 tools per day, or upgrade to Premium for unlimited access." : "Upgrade to Premium for unlimited daily tool usage."
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "mt-3 flex flex-wrap gap-2",
					children: [isGuest && /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Link, {
						to: "/auth",
						className: "rounded-md bg-amber-600 px-3 py-1.5 text-xs font-semibold text-white hover:bg-amber-700",
						children: "Sign up free"
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Link, {
						to: "/pricing",
						className: "rounded-md border border-amber-400 px-3 py-1.5 text-xs font-semibold text-amber-900 hover:bg-amber-100 dark:text-amber-200 dark:hover:bg-amber-900/40",
						children: isGuest ? "View pricing" : "Upgrade to Premium"
					})]
				})
			]
		})]
	});
}
/**
* Show the "Daily limit reached" modal. Matches the banner copy.
* Returns a promise resolving after the user dismisses / clicks a CTA.
*/
function showLimitReachedModal(usage) {
	const used = usage?.used ?? 0;
	const limit = usage?.limit ?? 0;
	const isGuest = (usage?.plan ?? "guest") === "guest";
	const body = isGuest ? "Sign up for a free account to get 10 tools per day, or upgrade to Premium for unlimited access." : "Upgrade to Premium for unlimited daily tool usage.";
	return Swal.fire({
		icon: "warning",
		title: `Daily limit reached (${used}/${limit})`,
		text: body,
		showCancelButton: true,
		showDenyButton: isGuest,
		confirmButtonText: isGuest ? "Sign up free" : "Upgrade to Premium",
		denyButtonText: "View pricing",
		cancelButtonText: "Close",
		confirmButtonColor: "#2563eb",
		denyButtonColor: "#7c3aed",
		cancelButtonColor: "#64748b",
		reverseButtons: true,
		focusConfirm: true
	}).then((res) => {
		if (res.isConfirmed) window.location.href = isGuest ? "/auth" : "/pricing";
		else if (res.isDenied) window.location.href = "/pricing";
	});
}
/**
* Page-level meter for PDF / Image categories.
* - `banner` — amber "limit reached" banner (same copy as before).
* - `blocked` — true when quota is exhausted.
* - `guardClick(e)` — attach as `onClickCapture` on the tools grid.
*   When blocked, cancels the click and shows a SweetAlert2 modal with
*   the same messaging as the banner. Buttons stay visually enabled.
*/
function useMeteredCategory() {
	const [usage, setUsage] = (0, import_react.useState)(() => getMeteredUsage());
	(0, import_react.useEffect)(() => {
		let cancelled = false;
		if (!getMeteredUsage()) getUsageStatus().then((r) => {
			if (!cancelled) setUsage(r);
		});
		const off = subscribeMeteredUsage(() => setUsage(getMeteredUsage()));
		return () => {
			cancelled = true;
			off();
		};
	}, []);
	const blocked = Boolean(usage && usage.limit >= 0 && usage.used >= usage.limit);
	return {
		usage,
		blocked,
		banner: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(UsageLimitBanner, { result: usage ? {
			...usage,
			allowed: !blocked
		} : null }),
		guardClick: (0, import_react.useCallback)((e) => {
			if (!blocked) return;
			if (!e.target?.closest("button, [role='button'], input[type='submit'], input[type='button']")) return;
			e.preventDefault();
			e.stopPropagation();
			showLimitReachedModal(usage);
		}, [blocked, usage])
	};
}
//#endregion
export { useMeteredCategory as t };
