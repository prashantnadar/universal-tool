import { o as __toESM } from "../_runtime.mjs";
import { nt as require_react } from "../_libs/@hookform/resolvers+[...].mjs";
import { r as require_jsx_runtime } from "../_libs/react+tanstack__react-query.mjs";
import { n as Layout } from "./Layout-8Jn4q3kq.mjs";
import { t as Reveal } from "./Reveal-CydLpVW7.mjs";
import { o as trackUse } from "./usage-tracking-C1qv9W3k.mjs";
import { n as Skeleton, r as SkeletonLines, t as InlineSpinner } from "./Skeleton-C9Gtenx-.mjs";
import { t as useMeteredCategory } from "./use-metered-category-DtDCo9eW.mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/tools.image-V4q6sOuU.js
var import_react = /* @__PURE__ */ __toESM(require_react());
var import_jsx_runtime = require_jsx_runtime();
function Card({ id, title, desc, busy, onCancel, children }) {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Reveal, {
		as: "section",
		children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("section", {
			id,
			className: "scroll-mt-32 rounded-2xl border border-slate-200 bg-white p-6 dark:border-slate-800 dark:bg-slate-900",
			children: [
				/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h2", {
					className: "text-lg font-bold text-slate-900 dark:text-white",
					style: { fontFamily: "'Space Grotesk', sans-serif" },
					children: title
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
					className: "mt-1 text-sm text-slate-600 dark:text-slate-400",
					children: desc
				})] }),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
					className: "mt-4",
					"aria-busy": busy ? true : void 0,
					children
				}),
				busy && /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "mt-4 rounded-lg border border-dashed border-slate-200 bg-slate-50 p-4 dark:border-slate-700 dark:bg-slate-950/40",
					role: "status",
					"aria-live": "polite",
					children: [
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
							className: "flex items-center justify-between gap-3",
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
								className: "flex items-center gap-2 text-xs font-medium text-slate-500 dark:text-slate-400",
								children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(InlineSpinner, {}), " Processing image…"]
							}), onCancel && /* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
								type: "button",
								onClick: onCancel,
								"aria-label": `Cancel ${title}`,
								className: "rounded-lg border border-rose-300 bg-white px-3 py-1 text-xs font-semibold text-rose-700 transition hover:bg-rose-50 dark:border-rose-800 dark:bg-slate-900 dark:text-rose-300 dark:hover:bg-rose-950/40",
								children: "Cancel"
							})]
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
							className: "mt-3",
							children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Skeleton, { className: "h-32 w-full" })
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
							className: "mt-3",
							children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(SkeletonLines, { count: 2 })
						})
					]
				})
			]
		})
	});
}
var inputCls = "block w-full text-sm text-slate-700 file:mr-3 file:rounded-lg file:border-0 file:bg-blue-600 file:px-3 file:py-2 file:text-sm file:font-semibold file:text-white file:hover:bg-blue-700 dark:text-slate-200";
var btnCls = "mt-3 inline-flex items-center rounded-lg bg-blue-600 px-4 py-2 text-sm font-semibold text-white transition hover:bg-blue-700 disabled:opacity-60";
function loadImage(file) {
	return new Promise((resolve, reject) => {
		const url = URL.createObjectURL(file);
		const img = new Image();
		img.onload = () => {
			resolve(img);
		};
		img.onerror = reject;
		img.src = url;
	});
}
function downloadCanvas(canvas, name, type = "image/png", quality = .92, setStatus) {
	setStatus?.(`Preparing download: ${name}…`);
	canvas.toBlob((blob) => {
		if (!blob) {
			setStatus?.(`Download failed: ${name} (canvas produced no data)`);
			return;
		}
		try {
			const url = URL.createObjectURL(blob);
			const a = document.createElement("a");
			a.href = url;
			a.download = name;
			setStatus?.(`Download in progress: ${name}`);
			a.click();
			setTimeout(() => URL.revokeObjectURL(url), 1e3);
			setStatus?.(`Download completed: ${name} (${blob.size} bytes)`);
		} catch (err) {
			const reason = err?.message || "browser blocked the download";
			setStatus?.(`Download failed: ${reason}`);
		}
	}, type, quality);
}
function ImageTools() {
	const { banner, guardClick } = useMeteredCategory();
	(0, import_react.useEffect)(() => {
		trackUse("img-resize");
	}, []);
	const [file, setFile] = (0, import_react.useState)(null);
	const [meta, setMeta] = (0, import_react.useState)(null);
	const [preview, setPreview] = (0, import_react.useState)(null);
	const [busyId, setBusyId] = (0, import_react.useState)(null);
	const [status, setStatus] = (0, import_react.useState)("");
	const imgRef = (0, import_react.useRef)(null);
	const runTokenRef = (0, import_react.useRef)(0);
	const lastTriggerRef = (0, import_react.useRef)(null);
	(0, import_react.useEffect)(() => {
		return () => {
			runTokenRef.current++;
		};
	}, []);
	const cancelRun = () => {
		runTokenRef.current++;
		setBusyId(null);
		setStatus("Canceled");
		requestAnimationFrame(() => lastTriggerRef.current?.focus());
	};
	const runBusy = async (id, label, fn, e) => {
		if (e?.currentTarget) lastTriggerRef.current = e.currentTarget;
		const token = ++runTokenRef.current;
		setBusyId(id);
		setStatus(`${label} started`);
		try {
			await Promise.resolve(fn());
			await new Promise((r) => setTimeout(r, 250));
			if (token !== runTokenRef.current) return;
			setStatus((s) => s.startsWith("Download") ? s : `${label} complete`);
		} catch (err) {
			if (token !== runTokenRef.current) return;
			const reason = err?.message || "unknown error";
			setStatus(`${label} failed: ${reason}`);
		} finally {
			if (token === runTokenRef.current) setBusyId(null);
			requestAnimationFrame(() => lastTriggerRef.current?.focus());
		}
	};
	const [rw, setRw] = (0, import_react.useState)(800);
	const [rh, setRh] = (0, import_react.useState)(600);
	const [cx, setCx] = (0, import_react.useState)(0);
	const [cy, setCy] = (0, import_react.useState)(0);
	const [cw, setCw] = (0, import_react.useState)(400);
	const [ch, setCh] = (0, import_react.useState)(300);
	const [filter, setFilter] = (0, import_react.useState)("none");
	const [rotDeg, setRotDeg] = (0, import_react.useState)(90);
	const [fmt, setFmt] = (0, import_react.useState)("image/png");
	const [quality, setQuality] = (0, import_react.useState)(.7);
	const [wmText, setWmText] = (0, import_react.useState)("© UniversalTools");
	const [bright, setBright] = (0, import_react.useState)(100);
	const [contrast, setContrast] = (0, import_react.useState)(100);
	const [satur, setSatur] = (0, import_react.useState)(100);
	const [b64, setB64] = (0, import_react.useState)("");
	const onPick = async (f) => {
		runTokenRef.current++;
		setBusyId(null);
		setStatus(f ? "New image loaded" : "");
		setFile(f);
		if (!f) {
			setMeta(null);
			setPreview(null);
			return;
		}
		const img = await loadImage(f);
		imgRef.current = img;
		setPreview(img.src);
		setMeta({
			width: img.naturalWidth,
			height: img.naturalHeight,
			type: f.type || "unknown",
			sizeKb: Math.round(f.size / 1024),
			name: f.name
		});
		setRw(img.naturalWidth);
		setRh(img.naturalHeight);
		setCw(Math.min(400, img.naturalWidth));
		setCh(Math.min(300, img.naturalHeight));
	};
	const draw = (w, h, fn, name, type = "image/png", q = .92) => {
		const c = document.createElement("canvas");
		c.width = w;
		c.height = h;
		fn(c.getContext("2d"));
		downloadCanvas(c, name, type, q, setStatus);
	};
	const doResize = () => {
		trackUse("img-resize");
		if (!imgRef.current) return;
		draw(rw, rh, (ctx) => ctx.drawImage(imgRef.current, 0, 0, rw, rh), `resized-${rw}x${rh}.png`);
	};
	const doCrop = () => {
		trackUse("img-crop");
		if (!imgRef.current) return;
		draw(cw, ch, (ctx) => ctx.drawImage(imgRef.current, cx, cy, cw, ch, 0, 0, cw, ch), `cropped.png`);
	};
	const doFilter = () => {
		trackUse("img-filter");
		if (!imgRef.current) return;
		const img = imgRef.current;
		draw(img.naturalWidth, img.naturalHeight, (ctx) => {
			ctx.filter = filter;
			ctx.drawImage(img, 0, 0);
		}, `filtered.png`);
	};
	const doRotate = () => {
		trackUse("img-rotate");
		if (!imgRef.current) return;
		const img = imgRef.current;
		const swap = rotDeg % 180 !== 0;
		const w = swap ? img.naturalHeight : img.naturalWidth;
		const h = swap ? img.naturalWidth : img.naturalHeight;
		draw(w, h, (ctx) => {
			ctx.translate(w / 2, h / 2);
			ctx.rotate(rotDeg * Math.PI / 180);
			ctx.drawImage(img, -img.naturalWidth / 2, -img.naturalHeight / 2);
		}, `rotated-${rotDeg}.png`);
	};
	const doFormat = () => {
		trackUse("img-convert");
		if (!imgRef.current) return;
		const img = imgRef.current;
		const ext = fmt.split("/")[1];
		draw(img.naturalWidth, img.naturalHeight, (ctx) => ctx.drawImage(img, 0, 0), `image.${ext}`, fmt);
	};
	const doCompress = () => {
		trackUse("img-compress");
		if (!imgRef.current) return;
		const img = imgRef.current;
		draw(img.naturalWidth, img.naturalHeight, (ctx) => ctx.drawImage(img, 0, 0), `compressed-q${Math.round(quality * 100)}.jpg`, "image/jpeg", quality);
	};
	const doFlip = (axis) => {
		trackUse("img-flip");
		if (!imgRef.current) return;
		const img = imgRef.current;
		draw(img.naturalWidth, img.naturalHeight, (ctx) => {
			if (axis === "x") {
				ctx.translate(img.naturalWidth, 0);
				ctx.scale(-1, 1);
			} else {
				ctx.translate(0, img.naturalHeight);
				ctx.scale(1, -1);
			}
			ctx.drawImage(img, 0, 0);
		}, `flipped-${axis}.png`);
	};
	const doWatermark = () => {
		trackUse("img-watermark");
		if (!imgRef.current || !wmText.trim()) return;
		const img = imgRef.current;
		draw(img.naturalWidth, img.naturalHeight, (ctx) => {
			ctx.drawImage(img, 0, 0);
			const fs = Math.max(16, Math.min(img.naturalWidth, img.naturalHeight) / 18);
			ctx.font = `bold ${fs}px sans-serif`;
			ctx.fillStyle = "rgba(255,255,255,0.65)";
			ctx.strokeStyle = "rgba(0,0,0,0.5)";
			ctx.lineWidth = Math.max(1, fs / 14);
			ctx.textAlign = "right";
			ctx.textBaseline = "bottom";
			const pad = fs * .6;
			ctx.strokeText(wmText, img.naturalWidth - pad, img.naturalHeight - pad);
			ctx.fillText(wmText, img.naturalWidth - pad, img.naturalHeight - pad);
		}, `watermarked.png`);
	};
	const doAdjust = () => {
		trackUse("img-adjust");
		if (!imgRef.current) return;
		const img = imgRef.current;
		draw(img.naturalWidth, img.naturalHeight, (ctx) => {
			ctx.filter = `brightness(${bright}%) contrast(${contrast}%) saturate(${satur}%)`;
			ctx.drawImage(img, 0, 0);
		}, `adjusted.png`);
	};
	const doBase64 = async () => {
		trackUse("img-to-base64");
		if (!file) return;
		const reader = new FileReader();
		reader.onload = () => setB64(String(reader.result ?? ""));
		reader.readAsDataURL(file);
	};
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Layout, { children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("section", {
		className: "mx-auto max-w-5xl px-4 py-12 sm:px-6",
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Reveal, { children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("header", {
				className: "mb-8",
				children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
						className: "text-sm font-semibold uppercase tracking-wider text-blue-600",
						children: "Image tools"
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h1", {
						className: "mt-1 text-3xl font-bold text-slate-900 sm:text-4xl dark:text-white",
						style: { fontFamily: "'Space Grotesk', sans-serif" },
						children: "Resize, crop, filter & convert"
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
						className: "mt-2 text-slate-600 dark:text-slate-400",
						children: "Drop one image and use it across every tool."
					})
				]
			}) }),
			banner,
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
				role: "status",
				"aria-live": "polite",
				className: "sr-only",
				children: status
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				onClickCapture: guardClick,
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Reveal, {
					delay: .05,
					children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "rounded-2xl border border-dashed border-blue-300 bg-blue-50/40 p-6 dark:border-blue-900 dark:bg-blue-950/20",
						children: [
							/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
								className: "flex flex-wrap items-center justify-between gap-3",
								children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("label", {
									htmlFor: "img",
									className: "block text-sm font-medium text-slate-700 dark:text-slate-200",
									children: "Choose an image"
								}), file && /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("button", {
									type: "button",
									onClick: () => {
										onPick(null);
										setB64("");
										const el = document.getElementById("img");
										if (el) el.value = "";
									},
									"aria-label": "Clear selected image",
									className: "inline-flex items-center gap-1 rounded-lg border border-slate-200 bg-white px-3 py-1 text-xs font-semibold text-slate-600 transition hover:border-rose-300 hover:text-rose-600 dark:border-slate-700 dark:bg-slate-950 dark:text-slate-300",
									children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("svg", {
										viewBox: "0 0 24 24",
										className: "h-3.5 w-3.5",
										fill: "none",
										stroke: "currentColor",
										strokeWidth: "2",
										"aria-hidden": "true",
										children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("path", { d: "M18 6 6 18M6 6l12 12" })
									}), "Clear image"]
								})]
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
								id: "img",
								type: "file",
								accept: "image/*",
								onChange: (e) => onPick(e.target.files?.[0] ?? null),
								className: `mt-2 ${inputCls}`
							}),
							preview && /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
								className: "mt-4 grid gap-4 md:grid-cols-[1fr_auto]",
								children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("img", {
									src: preview,
									alt: "preview",
									className: "max-h-64 rounded-lg border border-slate-200 dark:border-slate-700"
								}), meta && /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("dl", {
									className: "grid grid-cols-2 gap-x-4 gap-y-1 text-sm text-slate-700 dark:text-slate-300",
									children: [
										/* @__PURE__ */ (0, import_jsx_runtime.jsx)("dt", {
											className: "font-medium",
											children: "Name"
										}),
										/* @__PURE__ */ (0, import_jsx_runtime.jsx)("dd", {
											className: "truncate",
											children: meta.name
										}),
										/* @__PURE__ */ (0, import_jsx_runtime.jsx)("dt", {
											className: "font-medium",
											children: "Dimensions"
										}),
										/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("dd", { children: [
											meta.width,
											"×",
											meta.height
										] }),
										/* @__PURE__ */ (0, import_jsx_runtime.jsx)("dt", {
											className: "font-medium",
											children: "Type"
										}),
										/* @__PURE__ */ (0, import_jsx_runtime.jsx)("dd", { children: meta.type }),
										/* @__PURE__ */ (0, import_jsx_runtime.jsx)("dt", {
											className: "font-medium",
											children: "Size"
										}),
										/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("dd", { children: [meta.sizeKb, " KB"] })
									]
								})]
							})
						]
					})
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "mt-6 grid gap-5 lg:grid-cols-2",
					children: [
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Card, {
							busy: busyId === "img-resize",
							onCancel: cancelRun,
							id: "resize",
							toolId: "img-resize",
							title: "Resize",
							desc: "Set new width and height.",
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
								className: "flex flex-wrap gap-3",
								children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("label", {
									className: "text-sm",
									children: ["W ", /* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
										type: "number",
										value: rw,
										onChange: (e) => setRw(+e.target.value),
										className: "ml-1 w-24 rounded border border-slate-200 px-2 py-1 dark:border-slate-700 dark:bg-slate-950"
									})]
								}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("label", {
									className: "text-sm",
									children: ["H ", /* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
										type: "number",
										value: rh,
										onChange: (e) => setRh(+e.target.value),
										className: "ml-1 w-24 rounded border border-slate-200 px-2 py-1 dark:border-slate-700 dark:bg-slate-950"
									})]
								})]
							}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
								onClick: (e) => runBusy("img-resize", "Resize", doResize, e),
								disabled: !file || busyId !== null,
								className: btnCls,
								children: "Resize & download"
							})]
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Card, {
							busy: busyId === "img-crop",
							onCancel: cancelRun,
							id: "crop",
							toolId: "img-crop",
							title: "Crop",
							desc: "Crop to a rectangle.",
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
								className: "grid grid-cols-2 gap-2 text-sm",
								children: [
									/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("label", { children: ["X ", /* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
										type: "number",
										value: cx,
										onChange: (e) => setCx(+e.target.value),
										className: "ml-1 w-full rounded border border-slate-200 px-2 py-1 dark:border-slate-700 dark:bg-slate-950"
									})] }),
									/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("label", { children: ["Y ", /* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
										type: "number",
										value: cy,
										onChange: (e) => setCy(+e.target.value),
										className: "ml-1 w-full rounded border border-slate-200 px-2 py-1 dark:border-slate-700 dark:bg-slate-950"
									})] }),
									/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("label", { children: ["W ", /* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
										type: "number",
										value: cw,
										onChange: (e) => setCw(+e.target.value),
										className: "ml-1 w-full rounded border border-slate-200 px-2 py-1 dark:border-slate-700 dark:bg-slate-950"
									})] }),
									/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("label", { children: ["H ", /* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
										type: "number",
										value: ch,
										onChange: (e) => setCh(+e.target.value),
										className: "ml-1 w-full rounded border border-slate-200 px-2 py-1 dark:border-slate-700 dark:bg-slate-950"
									})] })
								]
							}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
								onClick: (e) => runBusy("img-crop", "Crop", doCrop, e),
								disabled: !file || busyId !== null,
								className: btnCls,
								children: "Crop & download"
							})]
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Card, {
							busy: busyId === "img-filter",
							onCancel: cancelRun,
							id: "filter",
							toolId: "img-filter",
							title: "Filters",
							desc: "Apply CSS-style filters.",
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("select", {
								value: filter,
								onChange: (e) => setFilter(e.target.value),
								className: "w-full rounded border border-slate-200 px-2 py-2 text-sm dark:border-slate-700 dark:bg-slate-950",
								children: [
									/* @__PURE__ */ (0, import_jsx_runtime.jsx)("option", {
										value: "none",
										children: "None"
									}),
									/* @__PURE__ */ (0, import_jsx_runtime.jsx)("option", {
										value: "grayscale(1)",
										children: "Grayscale"
									}),
									/* @__PURE__ */ (0, import_jsx_runtime.jsx)("option", {
										value: "sepia(1)",
										children: "Sepia"
									}),
									/* @__PURE__ */ (0, import_jsx_runtime.jsx)("option", {
										value: "blur(3px)",
										children: "Blur"
									}),
									/* @__PURE__ */ (0, import_jsx_runtime.jsx)("option", {
										value: "contrast(1.5)",
										children: "High contrast"
									}),
									/* @__PURE__ */ (0, import_jsx_runtime.jsx)("option", {
										value: "brightness(1.3)",
										children: "Brighten"
									}),
									/* @__PURE__ */ (0, import_jsx_runtime.jsx)("option", {
										value: "invert(1)",
										children: "Invert"
									})
								]
							}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
								onClick: (e) => runBusy("img-filter", "Filter", doFilter, e),
								disabled: !file || busyId !== null,
								className: btnCls,
								children: "Apply & download"
							})]
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Card, {
							busy: busyId === "img-rotate",
							onCancel: cancelRun,
							id: "rotate",
							toolId: "img-rotate",
							title: "Rotate",
							desc: "Rotate the image.",
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
								className: "flex gap-2",
								children: [
									90,
									180,
									270
								].map((d) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("button", {
									onClick: () => setRotDeg(d),
									className: `rounded-lg border px-3 py-1.5 text-sm ${rotDeg === d ? "border-blue-500 bg-blue-50 text-blue-700 dark:bg-blue-950/60 dark:text-blue-300" : "border-slate-200 dark:border-slate-700"}`,
									children: [d, "°"]
								}, d))
							}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
								onClick: (e) => runBusy("img-rotate", "Rotate", doRotate, e),
								disabled: !file || busyId !== null,
								className: btnCls,
								children: "Rotate & download"
							})]
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Card, {
							busy: busyId === "img-convert",
							onCancel: cancelRun,
							id: "format",
							toolId: "img-convert",
							title: "Convert format",
							desc: "Re-encode as JPG, PNG or WebP.",
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("select", {
								value: fmt,
								onChange: (e) => setFmt(e.target.value),
								className: "w-full rounded border border-slate-200 px-2 py-2 text-sm dark:border-slate-700 dark:bg-slate-950",
								children: [
									/* @__PURE__ */ (0, import_jsx_runtime.jsx)("option", {
										value: "image/png",
										children: "PNG"
									}),
									/* @__PURE__ */ (0, import_jsx_runtime.jsx)("option", {
										value: "image/jpeg",
										children: "JPG"
									}),
									/* @__PURE__ */ (0, import_jsx_runtime.jsx)("option", {
										value: "image/webp",
										children: "WebP"
									})
								]
							}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
								onClick: (e) => runBusy("img-convert", "Convert", doFormat, e),
								disabled: !file || busyId !== null,
								className: btnCls,
								children: "Convert & download"
							})]
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Card, {
							id: "metadata",
							toolId: "img-metadata",
							title: "Metadata",
							desc: "Quick info about the image.",
							children: meta ? /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("ul", {
								className: "text-sm text-slate-700 dark:text-slate-300",
								children: [
									/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("li", { children: [
										/* @__PURE__ */ (0, import_jsx_runtime.jsx)("strong", { children: "Filename:" }),
										" ",
										meta.name
									] }),
									/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("li", { children: [
										/* @__PURE__ */ (0, import_jsx_runtime.jsx)("strong", { children: "Dimensions:" }),
										" ",
										meta.width,
										"×",
										meta.height
									] }),
									/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("li", { children: [
										/* @__PURE__ */ (0, import_jsx_runtime.jsx)("strong", { children: "Aspect:" }),
										" ",
										(meta.width / meta.height).toFixed(2)
									] }),
									/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("li", { children: [
										/* @__PURE__ */ (0, import_jsx_runtime.jsx)("strong", { children: "Type:" }),
										" ",
										meta.type
									] }),
									/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("li", { children: [
										/* @__PURE__ */ (0, import_jsx_runtime.jsx)("strong", { children: "Size:" }),
										" ",
										meta.sizeKb,
										" KB"
									] })
								]
							}) : /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
								className: "text-sm text-slate-500",
								children: "Upload an image to view metadata."
							})
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Card, {
							busy: busyId === "img-compress",
							onCancel: cancelRun,
							id: "compress",
							toolId: "img-compress",
							title: "Compress",
							desc: "Re-encode as JPG with a quality slider.",
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("label", {
								className: "block text-sm text-slate-600 dark:text-slate-400",
								children: [
									"Quality: ",
									/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", {
										className: "font-semibold text-slate-900 dark:text-white",
										children: [Math.round(quality * 100), "%"]
									}),
									/* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
										type: "range",
										min: 10,
										max: 100,
										value: Math.round(quality * 100),
										onChange: (e) => setQuality(parseInt(e.target.value, 10) / 100),
										className: "mt-2 w-full accent-blue-600"
									})
								]
							}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
								onClick: (e) => runBusy("img-compress", "Compress", doCompress, e),
								disabled: !file || busyId !== null,
								className: btnCls,
								children: "Compress & download"
							})]
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Card, {
							busy: busyId === "img-flip",
							onCancel: cancelRun,
							id: "flip",
							toolId: "img-flip",
							title: "Flip",
							desc: "Mirror horizontally or vertically.",
							children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
								className: "flex flex-wrap gap-2",
								children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
									onClick: (e) => runBusy("img-flip", "Flip", () => doFlip("x"), e),
									disabled: !file || busyId !== null,
									className: btnCls,
									children: "Flip horizontal"
								}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
									onClick: (e) => runBusy("img-flip", "Flip", () => doFlip("y"), e),
									disabled: !file || busyId !== null,
									className: btnCls,
									children: "Flip vertical"
								})]
							})
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Card, {
							busy: busyId === "img-watermark",
							onCancel: cancelRun,
							id: "watermark",
							toolId: "img-watermark",
							title: "Watermark",
							desc: "Stamp text in the bottom-right corner.",
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
								value: wmText,
								onChange: (e) => setWmText(e.target.value),
								placeholder: "© Your brand",
								className: "w-full rounded border border-slate-200 px-2 py-2 text-sm dark:border-slate-700 dark:bg-slate-950 dark:text-white"
							}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
								onClick: (e) => runBusy("img-watermark", "Watermark", doWatermark, e),
								disabled: !file || busyId !== null,
								className: btnCls,
								children: "Apply & download"
							})]
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Card, {
							busy: busyId === "img-adjust",
							onCancel: cancelRun,
							id: "adjust",
							toolId: "img-adjust",
							title: "Brightness & Contrast",
							desc: "Tune exposure, contrast and saturation.",
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
								className: "space-y-2 text-sm text-slate-600 dark:text-slate-400",
								children: [
									/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("label", {
										className: "block",
										children: [
											"Brightness ",
											bright,
											"% ",
											/* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
												type: "range",
												min: 0,
												max: 200,
												value: bright,
												onChange: (e) => setBright(+e.target.value),
												className: "mt-1 w-full accent-blue-600"
											})
										]
									}),
									/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("label", {
										className: "block",
										children: [
											"Contrast ",
											contrast,
											"% ",
											/* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
												type: "range",
												min: 0,
												max: 200,
												value: contrast,
												onChange: (e) => setContrast(+e.target.value),
												className: "mt-1 w-full accent-blue-600"
											})
										]
									}),
									/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("label", {
										className: "block",
										children: [
											"Saturation ",
											satur,
											"% ",
											/* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
												type: "range",
												min: 0,
												max: 200,
												value: satur,
												onChange: (e) => setSatur(+e.target.value),
												className: "mt-1 w-full accent-blue-600"
											})
										]
									})
								]
							}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
								onClick: (e) => runBusy("img-adjust", "Adjust", doAdjust, e),
								disabled: !file || busyId !== null,
								className: btnCls,
								children: "Apply & download"
							})]
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Card, {
							busy: busyId === "img-to-base64",
							onCancel: cancelRun,
							id: "base64",
							toolId: "img-to-base64",
							title: "Image → Base64",
							desc: "Get a data URL you can paste into CSS or HTML.",
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
								onClick: (e) => runBusy("img-to-base64", "Base64", doBase64, e),
								disabled: !file || busyId !== null,
								className: btnCls,
								children: "Generate"
							}), b64 && /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(import_jsx_runtime.Fragment, { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("textarea", {
								readOnly: true,
								value: b64,
								rows: 4,
								className: "mt-3 w-full rounded border border-slate-200 bg-slate-50 p-2 font-mono text-xs dark:border-slate-700 dark:bg-slate-950 dark:text-slate-200"
							}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
								onClick: () => navigator.clipboard.writeText(b64),
								className: "mt-2 rounded-lg border border-slate-200 px-3 py-1.5 text-xs font-medium hover:border-blue-500 hover:text-blue-700 dark:border-slate-700",
								children: "Copy data URL"
							})] })]
						})
					]
				})]
			})
		]
	}) });
}
//#endregion
export { ImageTools as component };
