import { o as __toESM } from "../_runtime.mjs";
import { nt as require_react } from "../_libs/@hookform/resolvers+[...].mjs";
import { r as require_jsx_runtime } from "../_libs/react+tanstack__react-query.mjs";
import { n as Layout } from "./Layout-8Jn4q3kq.mjs";
import { t as Reveal } from "./Reveal-CydLpVW7.mjs";
import { o as trackUse } from "./usage-tracking-C1qv9W3k.mjs";
import { t as CopyButton } from "./CopyDownload-BgPQcrMS.mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/tools.color-DBuRuQHm.js
var import_react = /* @__PURE__ */ __toESM(require_react());
var import_jsx_runtime = require_jsx_runtime();
function hexToRgb(hex) {
	let h = hex.trim().replace("#", "");
	if (h.length === 3) h = h.split("").map((c) => c + c).join("");
	if (!/^[0-9a-f]{6}$/i.test(h)) return {
		r: 0,
		g: 0,
		b: 0
	};
	return {
		r: parseInt(h.slice(0, 2), 16),
		g: parseInt(h.slice(2, 4), 16),
		b: parseInt(h.slice(4, 6), 16)
	};
}
function rgbToHex(r, g, b) {
	return "#" + [
		r,
		g,
		b
	].map((n) => Math.max(0, Math.min(255, Math.round(n))).toString(16).padStart(2, "0")).join("");
}
function rgbToHsl(r, g, b) {
	r /= 255;
	g /= 255;
	b /= 255;
	const max = Math.max(r, g, b), min = Math.min(r, g, b);
	let h = 0, s = 0;
	const l = (max + min) / 2;
	if (max !== min) {
		const d = max - min;
		s = l > .5 ? d / (2 - max - min) : d / (max + min);
		switch (max) {
			case r:
				h = (g - b) / d + (g < b ? 6 : 0);
				break;
			case g:
				h = (b - r) / d + 2;
				break;
			case b:
				h = (r - g) / d + 4;
				break;
		}
		h /= 6;
	}
	return {
		h: Math.round(h * 360),
		s: Math.round(s * 100),
		l: Math.round(l * 100)
	};
}
function hslToRgb(h, s, l) {
	h /= 360;
	s /= 100;
	l /= 100;
	if (s === 0) return {
		r: l * 255,
		g: l * 255,
		b: l * 255
	};
	const q = l < .5 ? l * (1 + s) : l + s - l * s;
	const p = 2 * l - q;
	const conv = (t) => {
		if (t < 0) t += 1;
		if (t > 1) t -= 1;
		if (t < 1 / 6) return p + (q - p) * 6 * t;
		if (t < 1 / 2) return q;
		if (t < 2 / 3) return p + (q - p) * (2 / 3 - t) * 6;
		return p;
	};
	return {
		r: Math.round(conv(h + 1 / 3) * 255),
		g: Math.round(conv(h) * 255),
		b: Math.round(conv(h - 1 / 3) * 255)
	};
}
function rgbToHwb(r, g, b) {
	const { h } = rgbToHsl(r, g, b);
	return {
		h,
		w: Math.round(Math.min(r, g, b) / 255 * 100),
		bl: Math.round((1 - Math.max(r, g, b) / 255) * 100)
	};
}
function rgbToCmyk(r, g, b) {
	const rr = r / 255, gg = g / 255, bb = b / 255;
	const k = 1 - Math.max(rr, gg, bb);
	if (k === 1) return {
		c: 0,
		m: 0,
		y: 0,
		k: 100
	};
	return {
		c: Math.round((1 - rr - k) / (1 - k) * 100),
		m: Math.round((1 - gg - k) / (1 - k) * 100),
		y: Math.round((1 - bb - k) / (1 - k) * 100),
		k: Math.round(k * 100)
	};
}
function relLum({ r, g, b }) {
	const conv = (v) => {
		v /= 255;
		return v <= .03928 ? v / 12.92 : Math.pow((v + .055) / 1.055, 2.4);
	};
	return .2126 * conv(r) + .7152 * conv(g) + .0722 * conv(b);
}
function contrastRatio(a, b) {
	const la = relLum(hexToRgb(a)), lb = relLum(hexToRgb(b));
	const [hi, lo] = la > lb ? [la, lb] : [lb, la];
	return (hi + .05) / (lo + .05);
}
var TAILWIND_COLORS = [
	["slate-50", "#f8fafc"],
	["slate-100", "#f1f5f9"],
	["slate-200", "#e2e8f0"],
	["slate-300", "#cbd5e1"],
	["slate-400", "#94a3b8"],
	["slate-500", "#64748b"],
	["slate-600", "#475569"],
	["slate-700", "#334155"],
	["slate-800", "#1e293b"],
	["slate-900", "#0f172a"],
	["gray-500", "#6b7280"],
	["gray-700", "#374151"],
	["gray-900", "#111827"],
	["red-400", "#f87171"],
	["red-500", "#ef4444"],
	["red-600", "#dc2626"],
	["red-700", "#b91c1c"],
	["orange-500", "#f97316"],
	["amber-500", "#f59e0b"],
	["yellow-400", "#facc15"],
	["yellow-500", "#eab308"],
	["lime-500", "#84cc16"],
	["green-500", "#22c55e"],
	["green-600", "#16a34a"],
	["emerald-500", "#10b981"],
	["teal-500", "#14b8a6"],
	["cyan-500", "#06b6d4"],
	["sky-400", "#38bdf8"],
	["sky-500", "#0ea5e9"],
	["sky-600", "#0284c7"],
	["blue-400", "#60a5fa"],
	["blue-500", "#3b82f6"],
	["blue-600", "#2563eb"],
	["blue-700", "#1d4ed8"],
	["indigo-500", "#6366f1"],
	["indigo-600", "#4f46e5"],
	["violet-500", "#8b5cf6"],
	["purple-500", "#a855f7"],
	["purple-600", "#9333ea"],
	["fuchsia-500", "#d946ef"],
	["pink-500", "#ec4899"],
	["rose-500", "#f43f5e"],
	["stone-500", "#78716c"],
	["zinc-500", "#71717a"],
	["neutral-500", "#737373"],
	["white", "#ffffff"],
	["black", "#000000"]
];
function nearestTailwind(hex) {
	const t = hexToRgb(hex);
	let best = TAILWIND_COLORS[0], dist = Infinity;
	for (const [, h] of TAILWIND_COLORS) {
		const c = hexToRgb(h);
		const d = (c.r - t.r) ** 2 + (c.g - t.g) ** 2 + (c.b - t.b) ** 2;
		if (d < dist) {
			dist = d;
			best = TAILWIND_COLORS.find((x) => x[1] === h);
		}
	}
	return {
		name: best[0],
		hex: best[1],
		distance: Math.sqrt(dist)
	};
}
function Card({ id, title, desc, children }) {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Reveal, {
		as: "section",
		children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("section", {
			id,
			className: "scroll-mt-32 rounded-2xl border border-slate-200 bg-white p-6 dark:border-slate-800 dark:bg-slate-900",
			children: [
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h2", {
					className: "text-lg font-bold text-slate-900 dark:text-white",
					style: { fontFamily: "'Space Grotesk', sans-serif" },
					children: title
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
					className: "mt-1 text-sm text-slate-600 dark:text-slate-400",
					children: desc
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
					className: "mt-4",
					children
				})
			]
		})
	});
}
var inputCls = "rounded-lg border border-slate-200 bg-white px-3 py-2 font-mono text-sm dark:border-slate-700 dark:bg-slate-950 dark:text-white";
var runBtn = "inline-flex items-center rounded-lg bg-blue-600 px-4 py-2 text-sm font-semibold text-white transition hover:bg-blue-700";
function Swatch({ color, size = "h-10 w-10" }) {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
		"aria-hidden": "true",
		className: `inline-block rounded-lg border border-slate-200 dark:border-slate-700 ${size}`,
		style: { background: color }
	});
}
function ColorTools() {
	const [pick, setPick] = (0, import_react.useState)("#2563eb");
	const pickRgb = hexToRgb(pick);
	const pickHsl = rgbToHsl(pickRgb.r, pickRgb.g, pickRgb.b);
	const [conv, setConv] = (0, import_react.useState)("#22c55e");
	const cRgb = hexToRgb(conv);
	const cHsl = rgbToHsl(cRgb.r, cRgb.g, cRgb.b);
	const cHwb = rgbToHwb(cRgb.r, cRgb.g, cRgb.b);
	const cCmyk = rgbToCmyk(cRgb.r, cRgb.g, cRgb.b);
	const [mixA, setMixA] = (0, import_react.useState)("#2563eb");
	const [mixB, setMixB] = (0, import_react.useState)("#f97316");
	const [mixPct, setMixPct] = (0, import_react.useState)(50);
	const mixed = (0, import_react.useMemo)(() => {
		const a = hexToRgb(mixA), b = hexToRgb(mixB), t = mixPct / 100;
		return rgbToHex(a.r + (b.r - a.r) * t, a.g + (b.g - a.g) * t, a.b + (b.b - a.b) * t);
	}, [
		mixA,
		mixB,
		mixPct
	]);
	const [hexBase, setHexBase] = (0, import_react.useState)("#2563eb");
	const shades = (0, import_react.useMemo)(() => {
		const rgb = hexToRgb(hexBase);
		const hsl = rgbToHsl(rgb.r, rgb.g, rgb.b);
		return [
			95,
			85,
			70,
			55,
			40,
			25,
			15
		].map((l) => {
			const c = hslToRgb(hsl.h, hsl.s, l);
			return {
				l,
				hex: rgbToHex(c.r, c.g, c.b)
			};
		});
	}, [hexBase]);
	const [hslH, setHslH] = (0, import_react.useState)(220);
	const [hslS, setHslS] = (0, import_react.useState)(90);
	const [hslL, setHslL] = (0, import_react.useState)(50);
	const hslRgb = hslToRgb(hslH, hslS, hslL);
	const hslHex = rgbToHex(hslRgb.r, hslRgb.g, hslRgb.b);
	const [hwbSrc, setHwbSrc] = (0, import_react.useState)("#0ea5e9");
	const hwbVal = (() => {
		const r = hexToRgb(hwbSrc);
		return rgbToHwb(r.r, r.g, r.b);
	})();
	const [cmykSrc, setCmykSrc] = (0, import_react.useState)("#ef4444");
	const cmykVal = (() => {
		const r = hexToRgb(cmykSrc);
		return rgbToCmyk(r.r, r.g, r.b);
	})();
	const [rgbR, setRgbR] = (0, import_react.useState)(37);
	const [rgbG, setRgbG] = (0, import_react.useState)(99);
	const [rgbB, setRgbB] = (0, import_react.useState)(235);
	const rgbHex = rgbToHex(rgbR, rgbG, rgbB);
	const [cFg, setCFg] = (0, import_react.useState)("#ffffff");
	const [cBg, setCBg] = (0, import_react.useState)("#2563eb");
	const ratio = contrastRatio(cFg, cBg);
	const wcag = {
		aaNormal: ratio >= 4.5,
		aaLarge: ratio >= 3,
		aaaNormal: ratio >= 7,
		aaaLarge: ratio >= 4.5
	};
	const [gStops, setGStops] = (0, import_react.useState)([
		"#2563eb",
		"#a855f7",
		"#ec4899"
	]);
	const [gAngle, setGAngle] = (0, import_react.useState)(90);
	const gradCss = `linear-gradient(${gAngle}deg, ${gStops.join(", ")})`;
	const [twHex, setTwHex] = (0, import_react.useState)("#3ab0ff");
	const tw = nearestTailwind(twHex);
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Layout, { children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("section", {
		className: "mx-auto max-w-5xl px-4 py-12 sm:px-6",
		children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Reveal, { children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("header", {
			className: "mb-8",
			children: [
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
					className: "text-sm font-semibold uppercase tracking-wider text-blue-600",
					children: "Color tools"
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h1", {
					className: "mt-1 text-3xl font-bold text-slate-900 sm:text-4xl dark:text-white",
					style: { fontFamily: "'Space Grotesk', sans-serif" },
					children: "Pick, convert and check colors"
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
					className: "mt-2 text-slate-600 dark:text-slate-400",
					children: "11 free color tools — picker, converter, blender, WCAG contrast, gradient builder and Tailwind finder."
				})
			]
		}) }), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
			className: "grid gap-5 lg:grid-cols-2",
			children: [
				/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Card, {
					id: "picker",
					title: "Color Picker",
					desc: "Pick a color and copy any format.",
					children: [
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
							className: "flex flex-wrap items-center gap-3",
							children: [
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
									type: "color",
									value: pick,
									onChange: (e) => {
										setPick(e.target.value);
										trackUse("color-picker");
									},
									"aria-label": "Color picker",
									className: "h-12 w-16 cursor-pointer rounded-lg border border-slate-200 dark:border-slate-700"
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
									value: pick,
									onChange: (e) => setPick(e.target.value),
									className: inputCls,
									"aria-label": "Hex value"
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Swatch, {
									color: pick,
									size: "h-12 w-12"
								})
							]
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("dl", {
							className: "mt-3 grid grid-cols-2 gap-2 text-sm sm:grid-cols-3",
							children: [
								/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("dt", {
									className: "text-xs text-slate-500",
									children: "HEX"
								}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("dd", {
									className: "font-mono",
									children: pick
								})] }),
								/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("dt", {
									className: "text-xs text-slate-500",
									children: "RGB"
								}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("dd", {
									className: "font-mono",
									children: [
										"rgb(",
										pickRgb.r,
										", ",
										pickRgb.g,
										", ",
										pickRgb.b,
										")"
									]
								})] }),
								/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("dt", {
									className: "text-xs text-slate-500",
									children: "HSL"
								}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("dd", {
									className: "font-mono",
									children: [
										"hsl(",
										pickHsl.h,
										", ",
										pickHsl.s,
										"%, ",
										pickHsl.l,
										"%)"
									]
								})] })
							]
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
							className: "mt-2",
							children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(CopyButton, { getText: () => `${pick}\nrgb(${pickRgb.r}, ${pickRgb.g}, ${pickRgb.b})\nhsl(${pickHsl.h}, ${pickHsl.s}%, ${pickHsl.l}%)` })
						})
					]
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Card, {
					id: "converter",
					title: "Color Converter",
					desc: "HEX ↔ RGB ↔ HSL ↔ HWB ↔ CMYK.",
					children: [
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
							className: "flex flex-wrap items-center gap-3",
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
								type: "color",
								value: conv,
								onChange: (e) => {
									setConv(e.target.value);
									trackUse("color-converter");
								},
								"aria-label": "Source color",
								className: "h-12 w-16 cursor-pointer rounded-lg border border-slate-200 dark:border-slate-700"
							}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
								value: conv,
								onChange: (e) => setConv(e.target.value),
								className: inputCls,
								"aria-label": "Hex"
							})]
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("dl", {
							className: "mt-3 grid grid-cols-1 gap-2 text-sm sm:grid-cols-2",
							children: [
								/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("dt", {
									className: "text-xs text-slate-500",
									children: "HEX"
								}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("dd", {
									className: "font-mono",
									children: conv.toUpperCase()
								})] }),
								/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("dt", {
									className: "text-xs text-slate-500",
									children: "RGB"
								}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("dd", {
									className: "font-mono",
									children: [
										"rgb(",
										cRgb.r,
										", ",
										cRgb.g,
										", ",
										cRgb.b,
										")"
									]
								})] }),
								/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("dt", {
									className: "text-xs text-slate-500",
									children: "HSL"
								}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("dd", {
									className: "font-mono",
									children: [
										"hsl(",
										cHsl.h,
										", ",
										cHsl.s,
										"%, ",
										cHsl.l,
										"%)"
									]
								})] }),
								/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("dt", {
									className: "text-xs text-slate-500",
									children: "HWB"
								}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("dd", {
									className: "font-mono",
									children: [
										"hwb(",
										cHwb.h,
										" ",
										cHwb.w,
										"% ",
										cHwb.bl,
										"%)"
									]
								})] }),
								/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
									className: "sm:col-span-2",
									children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("dt", {
										className: "text-xs text-slate-500",
										children: "CMYK"
									}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("dd", {
										className: "font-mono",
										children: [
											"cmyk(",
											cCmyk.c,
											"%, ",
											cCmyk.m,
											"%, ",
											cCmyk.y,
											"%, ",
											cCmyk.k,
											"%)"
										]
									})]
								})
							]
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
							className: "mt-2",
							children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(CopyButton, { getText: () => `HEX ${conv}\nRGB rgb(${cRgb.r}, ${cRgb.g}, ${cRgb.b})\nHSL hsl(${cHsl.h}, ${cHsl.s}%, ${cHsl.l}%)\nHWB hwb(${cHwb.h} ${cHwb.w}% ${cHwb.bl}%)\nCMYK cmyk(${cCmyk.c}%, ${cCmyk.m}%, ${cCmyk.y}%, ${cCmyk.k}%)` })
						})
					]
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Card, {
					id: "mixer",
					title: "Color Mixer",
					desc: "Blend two colors at any ratio.",
					children: [
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
							className: "flex flex-wrap items-center gap-3",
							children: [
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
									type: "color",
									value: mixA,
									onChange: (e) => {
										setMixA(e.target.value);
										trackUse("color-mixer");
									},
									"aria-label": "Color A",
									className: "h-10 w-14 rounded border border-slate-200 dark:border-slate-700"
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
									type: "color",
									value: mixB,
									onChange: (e) => setMixB(e.target.value),
									"aria-label": "Color B",
									className: "h-10 w-14 rounded border border-slate-200 dark:border-slate-700"
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("label", {
									className: "flex items-center gap-2 text-sm",
									children: [
										"Blend",
										/* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
											type: "range",
											min: 0,
											max: 100,
											value: mixPct,
											onChange: (e) => setMixPct(+e.target.value),
											"aria-label": "Blend ratio"
										}),
										/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", {
											className: "font-mono",
											children: [mixPct, "%"]
										})
									]
								})
							]
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
							className: "mt-3 flex items-center gap-3",
							children: [
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Swatch, { color: mixA }),
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
									"aria-hidden": true,
									children: "→"
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Swatch, {
									color: mixed,
									size: "h-14 w-14"
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
									"aria-hidden": true,
									children: "→"
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Swatch, { color: mixB }),
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
									className: "font-mono text-sm",
									children: mixed
								})
							]
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
							className: "mt-2",
							children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(CopyButton, {
								getText: () => mixed,
								label: "Copy blended HEX"
							})
						})
					]
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Card, {
					id: "hex",
					title: "Color HEX Explorer",
					desc: "Shades and tints from a base color.",
					children: [
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
							className: "flex items-center gap-3",
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
								type: "color",
								value: hexBase,
								onChange: (e) => {
									setHexBase(e.target.value);
									trackUse("color-hex");
								},
								"aria-label": "Base color",
								className: "h-10 w-14 rounded border border-slate-200 dark:border-slate-700"
							}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
								value: hexBase,
								onChange: (e) => setHexBase(e.target.value),
								className: inputCls,
								"aria-label": "Hex"
							})]
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
							className: "mt-3 grid grid-cols-7 gap-1",
							children: shades.map((s) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
								className: "text-center",
								children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
									className: "h-10 w-full rounded",
									style: { background: s.hex },
									"aria-label": `Lightness ${s.l}%`
								}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
									className: "mt-1 font-mono text-[10px] text-slate-500",
									children: s.hex
								})]
							}, s.l))
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
							className: "mt-2",
							children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(CopyButton, { getText: () => shades.map((s) => s.hex).join("\n") })
						})
					]
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Card, {
					id: "hsl",
					title: "Colors HSL",
					desc: "Explore by hue, saturation, lightness.",
					children: [
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
							className: "grid gap-2 sm:grid-cols-3",
							children: [
								/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("label", {
									className: "text-sm",
									children: [
										"Hue ",
										/* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
											type: "range",
											min: 0,
											max: 360,
											value: hslH,
											onChange: (e) => {
												setHslH(+e.target.value);
												trackUse("color-hsl");
											},
											"aria-label": "Hue",
											className: "w-full"
										}),
										/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", {
											className: "ml-1 font-mono",
											children: [hslH, "°"]
										})
									]
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("label", {
									className: "text-sm",
									children: [
										"Saturation ",
										/* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
											type: "range",
											min: 0,
											max: 100,
											value: hslS,
											onChange: (e) => setHslS(+e.target.value),
											"aria-label": "Saturation",
											className: "w-full"
										}),
										/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", {
											className: "ml-1 font-mono",
											children: [hslS, "%"]
										})
									]
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("label", {
									className: "text-sm",
									children: [
										"Lightness ",
										/* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
											type: "range",
											min: 0,
											max: 100,
											value: hslL,
											onChange: (e) => setHslL(+e.target.value),
											"aria-label": "Lightness",
											className: "w-full"
										}),
										/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", {
											className: "ml-1 font-mono",
											children: [hslL, "%"]
										})
									]
								})
							]
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
							className: "mt-3 flex items-center gap-3",
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Swatch, {
								color: hslHex,
								size: "h-14 w-14"
							}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", {
								className: "font-mono text-sm",
								children: [
									"hsl(",
									hslH,
									", ",
									hslS,
									"%, ",
									hslL,
									"%) — ",
									hslHex
								]
							})]
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
							className: "mt-2",
							children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(CopyButton, { getText: () => `hsl(${hslH}, ${hslS}%, ${hslL}%)` })
						})
					]
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Card, {
					id: "hwb",
					title: "Colors HWB",
					desc: "CSS4 hue / whiteness / blackness notation.",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "flex items-center gap-3",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
							type: "color",
							value: hwbSrc,
							onChange: (e) => {
								setHwbSrc(e.target.value);
								trackUse("color-hwb");
							},
							"aria-label": "Color",
							className: "h-10 w-14 rounded border border-slate-200 dark:border-slate-700"
						}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", {
							className: "font-mono text-sm",
							children: [
								"hwb(",
								hwbVal.h,
								" ",
								hwbVal.w,
								"% ",
								hwbVal.bl,
								"%)"
							]
						})]
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
						className: "mt-2",
						children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(CopyButton, { getText: () => `hwb(${hwbVal.h} ${hwbVal.w}% ${hwbVal.bl}%)` })
					})]
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Card, {
					id: "cmyk",
					title: "Colors CMYK",
					desc: "Print-ready CMYK values.",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "flex items-center gap-3",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
							type: "color",
							value: cmykSrc,
							onChange: (e) => {
								setCmykSrc(e.target.value);
								trackUse("color-cmyk");
							},
							"aria-label": "Color",
							className: "h-10 w-14 rounded border border-slate-200 dark:border-slate-700"
						}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", {
							className: "font-mono text-sm",
							children: [
								"cmyk(",
								cmykVal.c,
								"%, ",
								cmykVal.m,
								"%, ",
								cmykVal.y,
								"%, ",
								cmykVal.k,
								"%)"
							]
						})]
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
						className: "mt-2",
						children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(CopyButton, { getText: () => `cmyk(${cmykVal.c}%, ${cmykVal.m}%, ${cmykVal.y}%, ${cmykVal.k}%)` })
					})]
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Card, {
					id: "rgb",
					title: "Colors RGB",
					desc: "Tune red, green and blue channels.",
					children: [
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
							className: "grid gap-2 sm:grid-cols-3",
							children: [
								/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("label", {
									className: "text-sm",
									children: [
										"Red ",
										/* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
											type: "range",
											min: 0,
											max: 255,
											value: rgbR,
											onChange: (e) => {
												setRgbR(+e.target.value);
												trackUse("color-rgb");
											},
											"aria-label": "Red",
											className: "w-full"
										}),
										/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
											className: "ml-1 font-mono",
											children: rgbR
										})
									]
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("label", {
									className: "text-sm",
									children: [
										"Green ",
										/* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
											type: "range",
											min: 0,
											max: 255,
											value: rgbG,
											onChange: (e) => setRgbG(+e.target.value),
											"aria-label": "Green",
											className: "w-full"
										}),
										/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
											className: "ml-1 font-mono",
											children: rgbG
										})
									]
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("label", {
									className: "text-sm",
									children: [
										"Blue ",
										/* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
											type: "range",
											min: 0,
											max: 255,
											value: rgbB,
											onChange: (e) => setRgbB(+e.target.value),
											"aria-label": "Blue",
											className: "w-full"
										}),
										/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
											className: "ml-1 font-mono",
											children: rgbB
										})
									]
								})
							]
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
							className: "mt-3 flex items-center gap-3",
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Swatch, {
								color: rgbHex,
								size: "h-14 w-14"
							}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", {
								className: "font-mono text-sm",
								children: [
									rgbHex,
									" — rgb(",
									rgbR,
									", ",
									rgbG,
									", ",
									rgbB,
									")"
								]
							})]
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
							className: "mt-2",
							children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(CopyButton, { getText: () => rgbHex })
						})
					]
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Card, {
					id: "contrast",
					title: "Color Contrast Analyzer",
					desc: "WCAG 2.1 contrast for text and UI pairs.",
					children: [
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
							className: "flex flex-wrap items-center gap-3",
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("label", {
								className: "flex items-center gap-2 text-sm",
								children: ["Foreground ", /* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
									type: "color",
									value: cFg,
									onChange: (e) => {
										setCFg(e.target.value);
										trackUse("color-contrast");
									},
									"aria-label": "Foreground",
									className: "h-10 w-14 rounded border border-slate-200 dark:border-slate-700"
								})]
							}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("label", {
								className: "flex items-center gap-2 text-sm",
								children: ["Background ", /* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
									type: "color",
									value: cBg,
									onChange: (e) => setCBg(e.target.value),
									"aria-label": "Background",
									className: "h-10 w-14 rounded border border-slate-200 dark:border-slate-700"
								})]
							})]
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
							className: "mt-3 rounded-lg p-6 text-center text-lg font-semibold",
							style: {
								background: cBg,
								color: cFg
							},
							children: "The quick brown fox jumps over the lazy dog."
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
							className: "mt-3 flex flex-wrap items-center gap-3 text-sm",
							children: [
								/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", {
									className: "font-mono",
									children: [
										"Ratio ",
										ratio.toFixed(2),
										":1"
									]
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", {
									className: `rounded px-2 py-0.5 text-xs font-semibold ${wcag.aaNormal ? "bg-green-100 text-green-800" : "bg-red-100 text-red-700"}`,
									children: ["AA text ", wcag.aaNormal ? "pass" : "fail"]
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", {
									className: `rounded px-2 py-0.5 text-xs font-semibold ${wcag.aaLarge ? "bg-green-100 text-green-800" : "bg-red-100 text-red-700"}`,
									children: ["AA large ", wcag.aaLarge ? "pass" : "fail"]
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", {
									className: `rounded px-2 py-0.5 text-xs font-semibold ${wcag.aaaNormal ? "bg-green-100 text-green-800" : "bg-red-100 text-red-700"}`,
									children: ["AAA text ", wcag.aaaNormal ? "pass" : "fail"]
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", {
									className: `rounded px-2 py-0.5 text-xs font-semibold ${wcag.aaaLarge ? "bg-green-100 text-green-800" : "bg-red-100 text-red-700"}`,
									children: ["AAA large ", wcag.aaaLarge ? "pass" : "fail"]
								})
							]
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
							className: "mt-2",
							children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(CopyButton, { getText: () => `Ratio ${ratio.toFixed(2)}:1 — FG ${cFg} / BG ${cBg}` })
						})
					]
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Card, {
					id: "gradient",
					title: "Color Gradient Builder",
					desc: "Compose multi-stop linear gradients.",
					children: [
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
							className: "flex flex-wrap items-center gap-2",
							children: [
								gStops.map((s, i) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
									type: "color",
									value: s,
									onChange: (e) => {
										const c = [...gStops];
										c[i] = e.target.value;
										setGStops(c);
										trackUse("color-gradient");
									},
									"aria-label": `Stop ${i + 1}`,
									className: "h-10 w-14 rounded border border-slate-200 dark:border-slate-700"
								}, i)),
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
									className: runBtn,
									onClick: () => setGStops([...gStops, "#ffffff"]),
									children: "Add stop"
								}),
								gStops.length > 2 && /* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
									className: runBtn,
									onClick: () => setGStops(gStops.slice(0, -1)),
									children: "Remove"
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("label", {
									className: "ml-2 text-sm",
									children: [
										"Angle ",
										/* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
											type: "number",
											min: 0,
											max: 360,
											value: gAngle,
											onChange: (e) => setGAngle(+e.target.value),
											className: "ml-1 w-20 rounded border border-slate-200 px-2 py-1 dark:border-slate-700 dark:bg-slate-950 dark:text-white",
											"aria-label": "Gradient angle"
										}),
										"°"
									]
								})
							]
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
							className: "mt-3 h-24 rounded-lg border border-slate-200 dark:border-slate-700",
							style: { background: gradCss }
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("pre", {
							className: "mt-2 overflow-auto rounded-lg bg-slate-950 p-3 text-xs text-slate-100",
							children: [
								"background: ",
								gradCss,
								";"
							]
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
							className: "mt-2",
							children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(CopyButton, {
								getText: () => `background: ${gradCss};`,
								label: "Copy CSS"
							})
						})
					]
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Card, {
					id: "tailwind",
					title: "Tailwind Color Finder",
					desc: "Nearest Tailwind class for any color.",
					children: [
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
							className: "flex items-center gap-3",
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
								type: "color",
								value: twHex,
								onChange: (e) => {
									setTwHex(e.target.value);
									trackUse("color-tailwind");
								},
								"aria-label": "Any color",
								className: "h-10 w-14 rounded border border-slate-200 dark:border-slate-700"
							}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
								value: twHex,
								onChange: (e) => setTwHex(e.target.value),
								className: inputCls,
								"aria-label": "Hex"
							})]
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
							className: "mt-3 flex items-center gap-3",
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Swatch, {
								color: tw.hex,
								size: "h-12 w-12"
							}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
								className: "font-mono text-sm",
								children: [
									"bg-",
									tw.name,
									" · text-",
									tw.name
								]
							}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
								className: "text-xs text-slate-500",
								children: [
									tw.hex.toUpperCase(),
									" · distance ",
									tw.distance.toFixed(1)
								]
							})] })]
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
							className: "mt-2",
							children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(CopyButton, {
								getText: () => `bg-${tw.name}`,
								label: `Copy class`
							})
						})
					]
				})
			]
		})]
	}) });
}
//#endregion
export { ColorTools as component };
