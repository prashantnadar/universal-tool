import { o as __toESM } from "../_runtime.mjs";
import { nt as require_react } from "../_libs/@hookform/resolvers+[...].mjs";
import { r as require_jsx_runtime } from "../_libs/react+tanstack__react-query.mjs";
import { n as Layout } from "./Layout-8Jn4q3kq.mjs";
import { t as Reveal } from "./Reveal-CydLpVW7.mjs";
import { o as trackUse } from "./usage-tracking-C1qv9W3k.mjs";
import { n as DownloadButton, t as CopyButton } from "./CopyDownload-BgPQcrMS.mjs";
import { t as require_md5 } from "../_libs/js-md5.mjs";
import { t as g } from "../_libs/marked.mjs";
import { t as purify } from "../_libs/dompurify.mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/tools.code-BrtA75vN.js
var import_react = /* @__PURE__ */ __toESM(require_react());
var import_jsx_runtime = require_jsx_runtime();
var import_md5 = require_md5();
var HTML_TO_JSX_ATTR = {
	class: "className",
	for: "htmlFor",
	tabindex: "tabIndex",
	readonly: "readOnly",
	maxlength: "maxLength",
	minlength: "minLength",
	colspan: "colSpan",
	rowspan: "rowSpan",
	contenteditable: "contentEditable",
	spellcheck: "spellCheck",
	autocomplete: "autoComplete",
	autofocus: "autoFocus",
	autoplay: "autoPlay",
	crossorigin: "crossOrigin",
	enctype: "encType",
	formaction: "formAction",
	novalidate: "noValidate",
	srcset: "srcSet",
	usemap: "useMap",
	frameborder: "frameBorder",
	allowfullscreen: "allowFullScreen",
	accept: "accept",
	charset: "charSet",
	datetime: "dateTime",
	accesskey: "accessKey",
	playsinline: "playsInline"
};
var VOID_TAGS = /* @__PURE__ */ new Set([
	"area",
	"base",
	"br",
	"col",
	"embed",
	"hr",
	"img",
	"input",
	"link",
	"meta",
	"param",
	"source",
	"track",
	"wbr"
]);
function kebabToCamel(k) {
	return k.replace(/-([a-z])/g, (_, c) => c.toUpperCase());
}
function convertStyle(styleStr) {
	return `{{ ${styleStr.split(";").map((s) => s.trim()).filter(Boolean).map((d) => {
		const idx = d.indexOf(":");
		if (idx === -1) return null;
		const prop = d.slice(0, idx).trim();
		const val = d.slice(idx + 1).trim();
		return `${prop.startsWith("--") ? `"${prop}"` : kebabToCamel(prop)}: ${/^-?\d+(\.\d+)?$/.test(val) ? val : `"${val.replace(/"/g, "\\\"")}"`}`;
	}).filter(Boolean).join(", ")} }}`;
}
function htmlToJsx(html) {
	let out = html;
	out = out.replace(/<!--([\s\S]*?)-->/g, (_, c) => `{/*${c}*/}`);
	out = out.replace(/<([a-zA-Z][a-zA-Z0-9-]*)([^>]*)>/g, (_m, tag, attrs) => {
		let a = attrs;
		a = a.replace(/style\s*=\s*"([^"]*)"/gi, (_s, css) => `style=${convertStyle(css)}`);
		a = a.replace(/style\s*=\s*'([^']*)'/gi, (_s, css) => `style=${convertStyle(css)}`);
		a = a.replace(/\son([a-z]+)\s*=/gi, (_s, ev) => ` on${ev.charAt(0).toUpperCase()}${ev.slice(1).toLowerCase()}=`);
		a = a.replace(/\s([a-zA-Z-]+)(\s*=)/g, (_s, name, eq) => {
			const lower = name.toLowerCase();
			if (HTML_TO_JSX_ATTR[lower]) return ` ${HTML_TO_JSX_ATTR[lower]}${eq}`;
			if (lower.startsWith("data-") || lower.startsWith("aria-")) return ` ${lower}${eq}`;
			return ` ${name}${eq}`;
		});
		a = a.replace(/\s(readonly|disabled|checked|selected|required|autoplay|controls|loop|muted|hidden|open|reversed|multiple)(?=[\s/>])/gi, (_s, name) => {
			const lower = name.toLowerCase();
			return ` ${HTML_TO_JSX_ATTR[lower] || lower}`;
		});
		const isVoid = VOID_TAGS.has(tag.toLowerCase());
		const alreadySelf = /\/\s*$/.test(a);
		if (isVoid && !alreadySelf) return `<${tag}${a.replace(/\s*$/, "")} />`;
		return `<${tag}${a}>`;
	});
	out = out.replace(/&nbsp;/g, "{'\\u00A0'}");
	return out;
}
function htmlToTsx(html, componentName = "Converted") {
	const jsx = htmlToJsx(html).trim();
	const safeName = componentName.replace(/[^A-Za-z0-9_]/g, "") || "Converted";
	return `import type { FC } from "react";

const ${safeName}: FC = () => {
  return (
    <>
${jsx.split("\n").map((l) => "      " + l).join("\n")}
    </>
  );
};

export default ${safeName};
`;
}
function jsxToTsx(jsx, componentName = "Converted") {
	const safeName = componentName.replace(/[^A-Za-z0-9_]/g, "") || "Converted";
	if (/\b(function|const)\s+[A-Z][A-Za-z0-9_]*/.test(jsx)) {
		let out = jsx;
		if (!/from ["']react["']/.test(out)) out = `import type { FC } from "react";\n\n` + out;
		out = out.replace(/const\s+([A-Z][A-Za-z0-9_]*)\s*=\s*\(/, `const $1: FC = (`);
		return out;
	}
	return `import type { FC } from "react";

const ${safeName}: FC = () => {
  return (
    <>
${jsx.split("\n").map((l) => "      " + l).join("\n")}
    </>
  );
};

export default ${safeName};
`;
}
function tsxToJsx(tsx) {
	let out = tsx;
	out = out.replace(/^\s*import\s+type\s+[^;]+;?\s*$/gm, "");
	out = out.replace(/^\s*export\s+type\s+[^;]+;?\s*$/gm, "");
	out = out.replace(/^\s*type\s+\w+[^=]*=\s*[^;]+;?\s*$/gm, "");
	out = out.replace(/^\s*interface\s+\w+[^{]*\{[\s\S]*?\}\s*$/gm, "");
	out = out.replace(/([A-Za-z_$][\w$]*)<[^<>()=;{}]+>\s*\(/g, "$1(");
	out = out.replace(/\s+as\s+[A-Za-z_$][\w$.<>[\], |&]*/g, "");
	out = out.replace(/(\bconst\s+\w+|\blet\s+\w+|\bvar\s+\w+|\b\w+)\s*:\s*[A-Za-z_$][\w$.<>[\], |&?]*(?=\s*[=,)\]{])/g, "$1");
	out = out.replace(/\)\s*:\s*[A-Za-z_$][\w$.<>[\], |&?]*(\s*[={])/g, ")$1");
	out = out.replace(/([A-Za-z_$][\w$)\]]*)!(\W)/g, "$1$2");
	out = out.replace(/\n{3,}/g, "\n\n");
	return out.trim() + "\n";
}
var CSS_TO_TW = [
	[/^display:\s*flex$/, () => "flex"],
	[/^display:\s*inline-flex$/, () => "inline-flex"],
	[/^display:\s*grid$/, () => "grid"],
	[/^display:\s*block$/, () => "block"],
	[/^display:\s*inline-block$/, () => "inline-block"],
	[/^display:\s*inline$/, () => "inline"],
	[/^display:\s*none$/, () => "hidden"],
	[/^flex-direction:\s*row$/, () => "flex-row"],
	[/^flex-direction:\s*column$/, () => "flex-col"],
	[/^flex-wrap:\s*wrap$/, () => "flex-wrap"],
	[/^justify-content:\s*center$/, () => "justify-center"],
	[/^justify-content:\s*space-between$/, () => "justify-between"],
	[/^justify-content:\s*flex-start$/, () => "justify-start"],
	[/^justify-content:\s*flex-end$/, () => "justify-end"],
	[/^align-items:\s*center$/, () => "items-center"],
	[/^align-items:\s*flex-start$/, () => "items-start"],
	[/^align-items:\s*flex-end$/, () => "items-end"],
	[/^text-align:\s*center$/, () => "text-center"],
	[/^text-align:\s*left$/, () => "text-left"],
	[/^text-align:\s*right$/, () => "text-right"],
	[/^font-weight:\s*(\d+)$/, (m) => `font-[${m[1]}]`],
	[/^font-weight:\s*bold$/, () => "font-bold"],
	[/^font-weight:\s*normal$/, () => "font-normal"],
	[/^font-style:\s*italic$/, () => "italic"],
	[/^text-transform:\s*uppercase$/, () => "uppercase"],
	[/^text-transform:\s*lowercase$/, () => "lowercase"],
	[/^text-decoration:\s*underline$/, () => "underline"],
	[/^border-radius:\s*9999px$/, () => "rounded-full"],
	[/^border-radius:\s*(\d+)px$/, (m) => `rounded-[${m[1]}px]`],
	[/^border:\s*1px\s+solid\s+(.+)$/, (m) => `border border-[${m[1]}]`],
	[/^background(?:-color)?:\s*(.+)$/, (m) => `bg-[${m[1]}]`],
	[/^color:\s*(.+)$/, (m) => `text-[${m[1]}]`],
	[/^font-size:\s*(\d+)px$/, (m) => `text-[${m[1]}px]`],
	[/^line-height:\s*([\d.]+)$/, (m) => `leading-[${m[1]}]`],
	[/^padding:\s*(\d+)px$/, (m) => `p-[${m[1]}px]`],
	[/^padding-top:\s*(\d+)px$/, (m) => `pt-[${m[1]}px]`],
	[/^padding-right:\s*(\d+)px$/, (m) => `pr-[${m[1]}px]`],
	[/^padding-bottom:\s*(\d+)px$/, (m) => `pb-[${m[1]}px]`],
	[/^padding-left:\s*(\d+)px$/, (m) => `pl-[${m[1]}px]`],
	[/^margin:\s*(\d+)px$/, (m) => `m-[${m[1]}px]`],
	[/^margin-top:\s*(\d+)px$/, (m) => `mt-[${m[1]}px]`],
	[/^margin-right:\s*(\d+)px$/, (m) => `mr-[${m[1]}px]`],
	[/^margin-bottom:\s*(\d+)px$/, (m) => `mb-[${m[1]}px]`],
	[/^margin-left:\s*(\d+)px$/, (m) => `ml-[${m[1]}px]`],
	[/^width:\s*100%$/, () => "w-full"],
	[/^width:\s*(\d+)px$/, (m) => `w-[${m[1]}px]`],
	[/^height:\s*100%$/, () => "h-full"],
	[/^height:\s*(\d+)px$/, (m) => `h-[${m[1]}px]`],
	[/^gap:\s*(\d+)px$/, (m) => `gap-[${m[1]}px]`],
	[/^position:\s*(absolute|relative|fixed|sticky|static)$/, (m) => m[1]],
	[/^opacity:\s*([\d.]+)$/, (m) => `opacity-[${m[1]}]`],
	[/^cursor:\s*pointer$/, () => "cursor-pointer"],
	[/^overflow:\s*hidden$/, () => "overflow-hidden"],
	[/^overflow:\s*auto$/, () => "overflow-auto"],
	[/^z-index:\s*(-?\d+)$/, (m) => `z-[${m[1]}]`],
	[/^box-shadow:\s*none$/, () => "shadow-none"]
];
function cssToTailwind(css) {
	const blocks = [];
	const ruleRe = /([^{}]+)\{([^{}]+)\}/g;
	let m;
	let hadBlock = false;
	while ((m = ruleRe.exec(css)) !== null) {
		hadBlock = true;
		const selector = m[1].trim();
		const decls = m[2].split(";").map((s) => s.trim()).filter(Boolean);
		const classes = [];
		const leftover = [];
		for (const d of decls) {
			let matched = false;
			for (const [re, fn] of CSS_TO_TW) {
				const mm = d.match(re);
				if (mm) {
					classes.push(fn(mm));
					matched = true;
					break;
				}
			}
			if (!matched) leftover.push(d + ";");
		}
		let out = `/* ${selector} */\nclass="${classes.join(" ")}"`;
		if (leftover.length) out += `\n/* not mapped: ${leftover.join(" ")} */`;
		blocks.push(out);
	}
	if (!hadBlock) {
		const decls = css.split(";").map((s) => s.trim()).filter(Boolean);
		const classes = [];
		const leftover = [];
		for (const d of decls) {
			let matched = false;
			for (const [re, fn] of CSS_TO_TW) {
				const mm = d.match(re);
				if (mm) {
					classes.push(fn(mm));
					matched = true;
					break;
				}
			}
			if (!matched) leftover.push(d + ";");
		}
		let out = `class="${classes.join(" ")}"`;
		if (leftover.length) out += `\n/* not mapped: ${leftover.join(" ")} */`;
		return out;
	}
	return blocks.join("\n\n");
}
var TW_TO_CSS = [
	[/^flex$/, () => "display: flex;"],
	[/^inline-flex$/, () => "display: inline-flex;"],
	[/^grid$/, () => "display: grid;"],
	[/^block$/, () => "display: block;"],
	[/^inline-block$/, () => "display: inline-block;"],
	[/^inline$/, () => "display: inline;"],
	[/^hidden$/, () => "display: none;"],
	[/^flex-row$/, () => "flex-direction: row;"],
	[/^flex-col$/, () => "flex-direction: column;"],
	[/^flex-wrap$/, () => "flex-wrap: wrap;"],
	[/^justify-center$/, () => "justify-content: center;"],
	[/^justify-between$/, () => "justify-content: space-between;"],
	[/^justify-start$/, () => "justify-content: flex-start;"],
	[/^justify-end$/, () => "justify-content: flex-end;"],
	[/^items-center$/, () => "align-items: center;"],
	[/^items-start$/, () => "align-items: flex-start;"],
	[/^items-end$/, () => "align-items: flex-end;"],
	[/^text-center$/, () => "text-align: center;"],
	[/^text-left$/, () => "text-align: left;"],
	[/^text-right$/, () => "text-align: right;"],
	[/^font-bold$/, () => "font-weight: 700;"],
	[/^font-normal$/, () => "font-weight: 400;"],
	[/^font-semibold$/, () => "font-weight: 600;"],
	[/^italic$/, () => "font-style: italic;"],
	[/^uppercase$/, () => "text-transform: uppercase;"],
	[/^lowercase$/, () => "text-transform: lowercase;"],
	[/^underline$/, () => "text-decoration: underline;"],
	[/^rounded-full$/, () => "border-radius: 9999px;"],
	[/^rounded-\[(.+)\]$/, (m) => `border-radius: ${m[1]};`],
	[/^rounded$/, () => "border-radius: 0.25rem;"],
	[/^rounded-lg$/, () => "border-radius: 0.5rem;"],
	[/^rounded-xl$/, () => "border-radius: 0.75rem;"],
	[/^rounded-2xl$/, () => "border-radius: 1rem;"],
	[/^border$/, () => "border-width: 1px;"],
	[/^border-\[(.+)\]$/, (m) => `border-color: ${m[1]};`],
	[/^bg-\[(.+)\]$/, (m) => `background-color: ${m[1]};`],
	[/^text-\[(.+)\]$/, (m) => `color: ${m[1]};`],
	[/^p-\[(.+)\]$/, (m) => `padding: ${m[1]};`],
	[/^pt-\[(.+)\]$/, (m) => `padding-top: ${m[1]};`],
	[/^pr-\[(.+)\]$/, (m) => `padding-right: ${m[1]};`],
	[/^pb-\[(.+)\]$/, (m) => `padding-bottom: ${m[1]};`],
	[/^pl-\[(.+)\]$/, (m) => `padding-left: ${m[1]};`],
	[/^p-(\d+)$/, (m) => `padding: ${Number(m[1]) * .25}rem;`],
	[/^px-(\d+)$/, (m) => `padding-left: ${Number(m[1]) * .25}rem; padding-right: ${Number(m[1]) * .25}rem;`],
	[/^py-(\d+)$/, (m) => `padding-top: ${Number(m[1]) * .25}rem; padding-bottom: ${Number(m[1]) * .25}rem;`],
	[/^m-\[(.+)\]$/, (m) => `margin: ${m[1]};`],
	[/^m-(\d+)$/, (m) => `margin: ${Number(m[1]) * .25}rem;`],
	[/^mx-(\d+)$/, (m) => `margin-left: ${Number(m[1]) * .25}rem; margin-right: ${Number(m[1]) * .25}rem;`],
	[/^my-(\d+)$/, (m) => `margin-top: ${Number(m[1]) * .25}rem; margin-bottom: ${Number(m[1]) * .25}rem;`],
	[/^w-full$/, () => "width: 100%;"],
	[/^w-\[(.+)\]$/, (m) => `width: ${m[1]};`],
	[/^w-(\d+)$/, (m) => `width: ${Number(m[1]) * .25}rem;`],
	[/^h-full$/, () => "height: 100%;"],
	[/^h-\[(.+)\]$/, (m) => `height: ${m[1]};`],
	[/^h-(\d+)$/, (m) => `height: ${Number(m[1]) * .25}rem;`],
	[/^gap-\[(.+)\]$/, (m) => `gap: ${m[1]};`],
	[/^gap-(\d+)$/, (m) => `gap: ${Number(m[1]) * .25}rem;`],
	[/^(absolute|relative|fixed|sticky|static)$/, (m) => `position: ${m[1]};`],
	[/^opacity-\[(.+)\]$/, (m) => `opacity: ${m[1]};`],
	[/^opacity-(\d+)$/, (m) => `opacity: ${Number(m[1]) / 100};`],
	[/^cursor-pointer$/, () => "cursor: pointer;"],
	[/^overflow-hidden$/, () => "overflow: hidden;"],
	[/^overflow-auto$/, () => "overflow: auto;"],
	[/^shadow-none$/, () => "box-shadow: none;"],
	[/^shadow$/, () => "box-shadow: 0 1px 3px rgba(0,0,0,0.1);"],
	[/^shadow-lg$/, () => "box-shadow: 0 10px 15px rgba(0,0,0,0.1);"],
	[/^text-xs$/, () => "font-size: 0.75rem;"],
	[/^text-sm$/, () => "font-size: 0.875rem;"],
	[/^text-base$/, () => "font-size: 1rem;"],
	[/^text-lg$/, () => "font-size: 1.125rem;"],
	[/^text-xl$/, () => "font-size: 1.25rem;"],
	[/^text-2xl$/, () => "font-size: 1.5rem;"]
];
function tailwindToCss(input) {
	const tokens = input.replace(/class(Name)?=/g, "").replace(/["'`]/g, " ").split(/\s+/).map((t) => t.trim()).filter(Boolean);
	const decls = [];
	const unknown = [];
	for (const tok of tokens) {
		let matched = false;
		for (const [re, fn] of TW_TO_CSS) {
			const mm = tok.match(re);
			if (mm) {
				decls.push(fn(mm));
				matched = true;
				break;
			}
		}
		if (!matched) unknown.push(tok);
	}
	let out = ".converted {\n" + decls.map((d) => "  " + d).join("\n") + "\n}";
	if (unknown.length) out += `\n\n/* not mapped: ${unknown.join(" ")} */`;
	return out;
}
var KEYCODES = [
	{
		key: "Backspace",
		code: "Backspace",
		keyCode: 8,
		which: 8,
		description: "Delete previous character"
	},
	{
		key: "Tab",
		code: "Tab",
		keyCode: 9,
		which: 9,
		description: "Tab / focus move"
	},
	{
		key: "Enter",
		code: "Enter",
		keyCode: 13,
		which: 13,
		description: "Return / submit"
	},
	{
		key: "Shift",
		code: "ShiftLeft",
		keyCode: 16,
		which: 16,
		description: "Shift modifier"
	},
	{
		key: "Control",
		code: "ControlLeft",
		keyCode: 17,
		which: 17,
		description: "Ctrl modifier"
	},
	{
		key: "Alt",
		code: "AltLeft",
		keyCode: 18,
		which: 18,
		description: "Alt / Option"
	},
	{
		key: "Pause",
		code: "Pause",
		keyCode: 19,
		which: 19,
		description: "Pause / Break"
	},
	{
		key: "CapsLock",
		code: "CapsLock",
		keyCode: 20,
		which: 20,
		description: "Caps Lock"
	},
	{
		key: "Escape",
		code: "Escape",
		keyCode: 27,
		which: 27,
		description: "Escape"
	},
	{
		key: " ",
		code: "Space",
		keyCode: 32,
		which: 32,
		description: "Spacebar"
	},
	{
		key: "PageUp",
		code: "PageUp",
		keyCode: 33,
		which: 33,
		description: "Page Up"
	},
	{
		key: "PageDown",
		code: "PageDown",
		keyCode: 34,
		which: 34,
		description: "Page Down"
	},
	{
		key: "End",
		code: "End",
		keyCode: 35,
		which: 35,
		description: "End"
	},
	{
		key: "Home",
		code: "Home",
		keyCode: 36,
		which: 36,
		description: "Home"
	},
	{
		key: "ArrowLeft",
		code: "ArrowLeft",
		keyCode: 37,
		which: 37,
		description: "Left arrow"
	},
	{
		key: "ArrowUp",
		code: "ArrowUp",
		keyCode: 38,
		which: 38,
		description: "Up arrow"
	},
	{
		key: "ArrowRight",
		code: "ArrowRight",
		keyCode: 39,
		which: 39,
		description: "Right arrow"
	},
	{
		key: "ArrowDown",
		code: "ArrowDown",
		keyCode: 40,
		which: 40,
		description: "Down arrow"
	},
	{
		key: "Insert",
		code: "Insert",
		keyCode: 45,
		which: 45,
		description: "Insert"
	},
	{
		key: "Delete",
		code: "Delete",
		keyCode: 46,
		which: 46,
		description: "Forward delete"
	},
	...Array.from({ length: 10 }, (_, i) => ({
		key: String(i),
		code: `Digit${i}`,
		keyCode: 48 + i,
		which: 48 + i,
		description: `Number ${i}`
	})),
	...Array.from({ length: 26 }, (_, i) => ({
		key: String.fromCharCode(65 + i),
		code: `Key${String.fromCharCode(65 + i)}`,
		keyCode: 65 + i,
		which: 65 + i,
		description: `Letter ${String.fromCharCode(65 + i)}`
	})),
	{
		key: "Meta",
		code: "MetaLeft",
		keyCode: 91,
		which: 91,
		description: "Windows / Command key"
	},
	{
		key: "ContextMenu",
		code: "ContextMenu",
		keyCode: 93,
		which: 93,
		description: "Right-click menu key"
	},
	...Array.from({ length: 12 }, (_, i) => ({
		key: `F${i + 1}`,
		code: `F${i + 1}`,
		keyCode: 112 + i,
		which: 112 + i,
		description: `Function key F${i + 1}`
	})),
	{
		key: "NumLock",
		code: "NumLock",
		keyCode: 144,
		which: 144,
		description: "Num Lock"
	},
	{
		key: "ScrollLock",
		code: "ScrollLock",
		keyCode: 145,
		which: 145,
		description: "Scroll Lock"
	},
	{
		key: ";",
		code: "Semicolon",
		keyCode: 186,
		which: 186,
		description: "Semicolon"
	},
	{
		key: "=",
		code: "Equal",
		keyCode: 187,
		which: 187,
		description: "Equals"
	},
	{
		key: ",",
		code: "Comma",
		keyCode: 188,
		which: 188,
		description: "Comma"
	},
	{
		key: "-",
		code: "Minus",
		keyCode: 189,
		which: 189,
		description: "Minus"
	},
	{
		key: ".",
		code: "Period",
		keyCode: 190,
		which: 190,
		description: "Period"
	},
	{
		key: "/",
		code: "Slash",
		keyCode: 191,
		which: 191,
		description: "Forward slash"
	},
	{
		key: "`",
		code: "Backquote",
		keyCode: 192,
		which: 192,
		description: "Backtick"
	},
	{
		key: "[",
		code: "BracketLeft",
		keyCode: 219,
		which: 219,
		description: "Left bracket"
	},
	{
		key: "\\",
		code: "Backslash",
		keyCode: 220,
		which: 220,
		description: "Backslash"
	},
	{
		key: "]",
		code: "BracketRight",
		keyCode: 221,
		which: 221,
		description: "Right bracket"
	},
	{
		key: "'",
		code: "Quote",
		keyCode: 222,
		which: 222,
		description: "Apostrophe"
	}
];
var VOID = /* @__PURE__ */ new Set([
	"area",
	"base",
	"br",
	"col",
	"embed",
	"hr",
	"img",
	"input",
	"link",
	"meta",
	"source",
	"track",
	"wbr"
]);
var PRESERVE = /* @__PURE__ */ new Set([
	"pre",
	"textarea",
	"script",
	"style"
]);
var INLINE = /* @__PURE__ */ new Set([
	"a",
	"abbr",
	"b",
	"bdi",
	"bdo",
	"br",
	"cite",
	"code",
	"data",
	"dfn",
	"em",
	"i",
	"kbd",
	"label",
	"mark",
	"q",
	"rp",
	"rt",
	"ruby",
	"s",
	"samp",
	"small",
	"span",
	"strong",
	"sub",
	"sup",
	"time",
	"u",
	"var",
	"wbr",
	"del",
	"ins",
	"img",
	"input"
]);
function tokenize(src, warnings) {
	const toks = [];
	let i = 0;
	while (i < src.length) if (src[i] === "<") {
		if (src.startsWith("<!--", i)) {
			const end = src.indexOf("-->", i + 4);
			if (end === -1) {
				warnings.push({
					kind: "unclosed",
					message: "Unterminated comment auto-closed at end of input."
				});
				toks.push({
					kind: "comment",
					raw: src.slice(i) + "-->"
				});
				i = src.length;
			} else {
				toks.push({
					kind: "comment",
					raw: src.slice(i, end + 3)
				});
				i = end + 3;
			}
			continue;
		}
		if (src[i + 1] === "!") {
			const end = src.indexOf(">", i);
			const stop = end === -1 ? src.length : end + 1;
			toks.push({
				kind: "doctype",
				raw: src.slice(i, stop)
			});
			i = stop;
			continue;
		}
		const end = src.indexOf(">", i);
		if (end === -1) {
			warnings.push({
				kind: "stray",
				message: "Stray \"<\" treated as text."
			});
			toks.push({
				kind: "text",
				value: src.slice(i)
			});
			break;
		}
		const raw = src.slice(i, end + 1);
		const m = raw.match(/^<\s*(\/?)\s*([a-zA-Z][a-zA-Z0-9-]*)/);
		if (!m) {
			warnings.push({
				kind: "stray",
				message: `Malformed tag treated as text: ${raw}`
			});
			toks.push({
				kind: "text",
				value: raw
			});
			i = end + 1;
			continue;
		}
		const isClose = m[1] === "/";
		const name = m[2].toLowerCase();
		if (isClose) {
			toks.push({
				kind: "close",
				name,
				raw
			});
			i = end + 1;
			continue;
		}
		const selfClose = /\/\s*>$/.test(raw) || VOID.has(name);
		if (VOID.has(name) && !/\/\s*>$/.test(raw)) {}
		toks.push({
			kind: "open",
			name,
			raw,
			selfClose
		});
		i = end + 1;
		if (!selfClose && PRESERVE.has(name)) {
			const closeRe = new RegExp(`</\\s*${name}\\s*>`, "i");
			const rest = src.slice(i);
			const cm = rest.match(closeRe);
			if (!cm || cm.index === void 0) {
				warnings.push({
					kind: "unclosed",
					message: `<${name}> was not closed; content preserved to end of input.`
				});
				toks.push({
					kind: "raw",
					value: rest
				});
				toks.push({
					kind: "close",
					name,
					raw: `</${name}>`
				});
				i = src.length;
			} else {
				toks.push({
					kind: "raw",
					value: rest.slice(0, cm.index)
				});
				toks.push({
					kind: "close",
					name,
					raw: rest.slice(cm.index, cm.index + cm[0].length)
				});
				i += cm.index + cm[0].length;
			}
		}
	} else {
		const nxt = src.indexOf("<", i);
		const stop = nxt === -1 ? src.length : nxt;
		toks.push({
			kind: "text",
			value: src.slice(i, stop)
		});
		i = stop;
	}
	return toks;
}
function parse(toks, warnings) {
	const root = [];
	const stack = [{
		name: "#root",
		children: root
	}];
	for (const t of toks) {
		const top = stack[stack.length - 1];
		if (t.kind === "text") top.children.push({
			type: "text",
			value: t.value
		});
		else if (t.kind === "raw") top.children.push({
			type: "raw",
			value: t.value,
			parentName: top.name
		});
		else if (t.kind === "comment") top.children.push({
			type: "comment",
			raw: t.raw
		});
		else if (t.kind === "doctype") top.children.push({
			type: "doctype",
			raw: t.raw
		});
		else if (t.kind === "open") {
			const node = {
				type: "element",
				name: t.name,
				children: [],
				selfClose: t.selfClose,
				raw: t.raw
			};
			top.children.push(node);
			if (!t.selfClose) stack.push({
				name: t.name,
				children: node.children
			});
		} else if (t.kind === "close") {
			let idx = -1;
			for (let s = stack.length - 1; s >= 1; s--) if (stack[s].name === t.name) {
				idx = s;
				break;
			}
			if (idx === -1) warnings.push({
				kind: "mismatched",
				message: `Stray closing tag </${t.name}> ignored.`
			});
			else {
				if (idx !== stack.length - 1) {
					const skipped = stack.slice(idx + 1).map((s) => s.name).join(", ");
					warnings.push({
						kind: "unclosed",
						message: `Auto-closed unclosed tag(s): ${skipped}`
					});
				}
				stack.length = idx;
			}
		}
	}
	if (stack.length > 1) warnings.push({
		kind: "unclosed",
		message: `Unclosed at end of input: ${stack.slice(1).map((s) => s.name).join(", ")}`
	});
	return root;
}
function isInline(n) {
	if (n.type === "text" || n.type === "raw") return true;
	if (n.type === "element") return INLINE.has(n.name);
	return false;
}
function serialize(nodes) {
	const PAD = "  ";
	const out = [];
	function walk(nodes, depth, inlineParent) {
		let i = 0;
		while (i < nodes.length) {
			const n = nodes[i];
			if (n.type === "text") {
				if (!n.value.replace(/[\t\n\r\f ]+/g, " ").trim()) {
					i++;
					continue;
				}
				const run = [];
				while (i < nodes.length && isInline(nodes[i])) {
					run.push(nodes[i]);
					i++;
				}
				out.push(PAD.repeat(depth) + renderInlineRun(run));
				continue;
			}
			if (n.type === "element" && INLINE.has(n.name)) {
				const run = [];
				while (i < nodes.length && isInline(nodes[i])) {
					run.push(nodes[i]);
					i++;
				}
				out.push(PAD.repeat(depth) + renderInlineRun(run));
				continue;
			}
			if (n.type === "comment") {
				out.push(PAD.repeat(depth) + n.raw);
				i++;
				continue;
			}
			if (n.type === "doctype") {
				out.push(PAD.repeat(depth) + n.raw);
				i++;
				continue;
			}
			if (n.type === "raw") {
				out.push(n.value);
				i++;
				continue;
			}
			const el = n;
			if (el.selfClose || el.children.length === 0) out.push(PAD.repeat(depth) + el.raw + (el.selfClose ? "" : `</${el.name}>`));
			else if (PRESERVE.has(el.name)) {
				const inner = el.children.map((c) => c.type === "raw" || c.type === "text" ? c.value : "").join("");
				out.push(PAD.repeat(depth) + el.raw + inner + `</${el.name}>`);
			} else if (el.children.length === 1 && el.children[0].type === "text") {
				const collapsed = el.children[0].value.replace(/[\t\n\r\f ]+/g, " ").trim();
				out.push(PAD.repeat(depth) + el.raw + collapsed + `</${el.name}>`);
			} else if (el.children.every(isInline)) out.push(PAD.repeat(depth) + el.raw + renderInlineRun(el.children) + `</${el.name}>`);
			else {
				out.push(PAD.repeat(depth) + el.raw);
				walk(el.children, depth + 1, false);
				out.push(PAD.repeat(depth) + `</${el.name}>`);
			}
			i++;
		}
	}
	function renderInlineRun(run) {
		let s = "";
		for (const n of run) if (n.type === "text") s += n.value.replace(/[\t\n\r\f ]+/g, " ");
		else if (n.type === "element") {
			const inner = renderInlineRun(n.children);
			if (n.selfClose || n.children.length === 0) s += n.raw + (n.selfClose ? "" : `</${n.name}>`);
			else s += n.raw + inner + `</${n.name}>`;
		} else if (n.type === "raw") s += n.value;
		else if (n.type === "comment") s += n.raw;
		return s.replace(/[\t\n\r\f ]+/g, " ").trim();
	}
	walk(nodes, 0, false);
	return out.join("\n");
}
function formatHtml(source) {
	const warnings = [];
	if (!source.trim()) {
		warnings.push({
			kind: "empty",
			message: "Input is empty."
		});
		return {
			output: "",
			warnings
		};
	}
	const output = serialize(parse(tokenize(source, warnings), warnings));
	const seen = /* @__PURE__ */ new Set();
	return {
		output,
		warnings: warnings.filter((w) => seen.has(w.message) ? false : (seen.add(w.message), true))
	};
}
function lineDiff(a, b) {
	const A = a.split("\n");
	const B = b.split("\n");
	const n = A.length, m = B.length;
	const dp = Array.from({ length: n + 1 }, () => new Array(m + 1).fill(0));
	for (let i = n - 1; i >= 0; i--) for (let j = m - 1; j >= 0; j--) dp[i][j] = A[i] === B[j] ? dp[i + 1][j + 1] + 1 : Math.max(dp[i + 1][j], dp[i][j + 1]);
	const left = [];
	const right = [];
	let i = 0, j = 0;
	while (i < n && j < m) if (A[i] === B[j]) {
		left.push({
			value: A[i],
			kind: "same"
		});
		right.push({
			value: B[j],
			kind: "same"
		});
		i++;
		j++;
	} else if (dp[i + 1][j] >= dp[i][j + 1]) {
		left.push({
			value: A[i],
			kind: "del"
		});
		i++;
	} else {
		right.push({
			value: B[j],
			kind: "add"
		});
		j++;
	}
	while (i < n) left.push({
		value: A[i++],
		kind: "del"
	});
	while (j < m) right.push({
		value: B[j++],
		kind: "add"
	});
	return {
		left,
		right
	};
}
function Card({ id, toolId, title, desc, children }) {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Reveal, {
		as: "section",
		children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("section", {
			id,
			className: "scroll-mt-32 rounded-2xl border border-slate-200 bg-white p-6 dark:border-slate-800 dark:bg-slate-900",
			children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
				className: "flex items-start justify-between gap-3",
				children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h2", {
					className: "text-lg font-bold text-slate-900 dark:text-white",
					style: { fontFamily: "'Space Grotesk', sans-serif" },
					children: title
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
					className: "mt-1 text-sm text-slate-600 dark:text-slate-400",
					children: desc
				})] })
			}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
				className: "mt-4",
				children
			})]
		})
	});
}
var ta = "block w-full rounded-lg border border-slate-200 bg-slate-50 px-3 py-2 font-mono text-xs text-slate-900 outline-none focus:border-blue-500 dark:border-slate-700 dark:bg-slate-950 dark:text-slate-100";
var runBtn = "inline-flex items-center rounded-lg bg-blue-600 px-4 py-2 text-sm font-semibold text-white transition hover:bg-blue-700";
function formatXML(xml) {
	const PADDING = "  ";
	let pad = 0;
	return xml.replace(/(>)(<)(\/*)/g, "$1\n$2$3").split("\n").map((node) => {
		let indent = 0;
		if (node.match(/.+<\/\w[^>]*>$/)) indent = 0;
		else if (node.match(/^<\/\w/)) pad = Math.max(pad - 1, 0);
		else if (node.match(/^<\w[^>]*[^/]>.*$/)) indent = 1;
		const out = PADDING.repeat(pad) + node;
		pad += indent;
		return out;
	}).join("\n");
}
function formatSQL(sql) {
	const kw = [
		"SELECT",
		"FROM",
		"WHERE",
		"AND",
		"OR",
		"INNER JOIN",
		"LEFT JOIN",
		"RIGHT JOIN",
		"OUTER JOIN",
		"GROUP BY",
		"ORDER BY",
		"HAVING",
		"LIMIT",
		"OFFSET",
		"INSERT INTO",
		"VALUES",
		"UPDATE",
		"SET",
		"DELETE FROM"
	];
	let s = sql.replace(/\s+/g, " ").trim();
	kw.forEach((k) => {
		s = s.replace(new RegExp(`\\b${k}\\b`, "gi"), `\n${k}`);
	});
	return s.trim();
}
function CodeTools() {
	const run = (_id, fn) => {
		try {
			Promise.resolve(fn()).catch(() => {});
		} catch {}
	};
	const banner = null;
	const [jsonIn, setJsonIn] = (0, import_react.useState)("{\"hello\":\"world\",\"items\":[1,2,3]}");
	const [jsonOut, setJsonOut] = (0, import_react.useState)("");
	const jsonFmt = () => run("json-format", () => {
		try {
			setJsonOut(JSON.stringify(JSON.parse(jsonIn), null, 2));
			trackUse("json-format");
		} catch (e) {
			setJsonOut(`/* Invalid JSON: ${e.message} */`);
		}
	});
	const jsonMin = () => run("json-minify", () => {
		try {
			setJsonOut(JSON.stringify(JSON.parse(jsonIn)));
			trackUse("json-minify");
		} catch (e) {
			setJsonOut(`/* Invalid JSON: ${e.message} */`);
		}
	});
	const [xmlIn, setXmlIn] = (0, import_react.useState)("<root><item id=\"1\">A</item><item id=\"2\">B</item></root>");
	const [xmlOut, setXmlOut] = (0, import_react.useState)("");
	const [minIn, setMinIn] = (0, import_react.useState)("/* paste HTML, CSS or JS */\n.box { color: red;  padding: 10px; }\n");
	const [minOut, setMinOut] = (0, import_react.useState)("");
	const [sqlIn, setSqlIn] = (0, import_react.useState)("select id, name from users where active = 1 order by name");
	const [sqlOut, setSqlOut] = (0, import_react.useState)("");
	const [jwt, setJwt] = (0, import_react.useState)("");
	const jwtOut = (0, import_react.useMemo)(() => {
		if (!jwt.trim()) return "";
		const parts = jwt.split(".");
		if (parts.length < 2) return "Invalid JWT (expected 3 parts)";
		try {
			const dec = (s) => JSON.parse(atob(s.replace(/-/g, "+").replace(/_/g, "/")));
			return JSON.stringify({
				header: dec(parts[0]),
				payload: dec(parts[1])
			}, null, 2);
		} catch (e) {
			return `Decode error: ${e.message}`;
		}
	}, [jwt]);
	const [pattern, setPattern] = (0, import_react.useState)("\\b\\w+@\\w+\\.\\w+\\b");
	const [flags, setFlags] = (0, import_react.useState)("g");
	const [regexInput, setRegexInput] = (0, import_react.useState)("Contact us at hi@example.com or sales@acme.io for help.");
	const regexResult = (0, import_react.useMemo)(() => {
		try {
			const re = new RegExp(pattern, flags);
			const matches = regexInput.match(re) || [];
			return matches.length ? `Found ${matches.length} match(es):\n${matches.join("\n")}` : "No matches.";
		} catch (e) {
			return `Invalid regex: ${e.message}`;
		}
	}, [
		pattern,
		flags,
		regexInput
	]);
	const [uuids, setUuids] = (0, import_react.useState)([]);
	const [uuidCount, setUuidCount] = (0, import_react.useState)(5);
	const genUuids = () => run("uuid-gen", () => {
		const out = [];
		for (let i = 0; i < uuidCount; i++) out.push(crypto.randomUUID());
		setUuids(out);
		trackUse("uuid-gen");
	});
	const [hashIn, setHashIn] = (0, import_react.useState)("hello world");
	const [hashAlgo, setHashAlgo] = (0, import_react.useState)("SHA-256");
	const [hashOut, setHashOut] = (0, import_react.useState)("");
	const doHash = () => run("hash-gen", async () => {
		if (hashAlgo === "MD5") setHashOut((0, import_md5.md5)(hashIn));
		else {
			const buf = new TextEncoder().encode(hashIn);
			const digest = await crypto.subtle.digest(hashAlgo, buf);
			setHashOut(Array.from(new Uint8Array(digest)).map((b) => b.toString(16).padStart(2, "0")).join(""));
		}
		trackUse("hash-gen");
	});
	const [ts, setTs] = (0, import_react.useState)(Math.floor(Date.now() / 1e3).toString());
	const [dt, setDt] = (0, import_react.useState)((/* @__PURE__ */ new Date()).toISOString().slice(0, 19));
	const tsToDate = () => run("timestamp", () => {
		setDt((/* @__PURE__ */ new Date(parseInt(ts) * 1e3)).toISOString().slice(0, 19));
		trackUse("timestamp");
	});
	const dateToTs = () => run("timestamp", () => {
		setTs(Math.floor(new Date(dt).getTime() / 1e3).toString());
		trackUse("timestamp");
	});
	const [hex, setHex] = (0, import_react.useState)("#2563eb");
	const [rgb, setRgb] = (0, import_react.useState)("rgb(37, 99, 235)");
	const hexToRgb = () => run("color-convert", () => {
		const m = hex.replace("#", "").match(/.{1,2}/g);
		if (!m || m.length < 3) return;
		setRgb(`rgb(${parseInt(m[0], 16)}, ${parseInt(m[1], 16)}, ${parseInt(m[2], 16)})`);
		trackUse("color-convert");
	});
	const rgbToHex = () => run("color-convert", () => {
		const m = rgb.match(/\d+/g);
		if (!m || m.length < 3) return;
		setHex("#" + m.slice(0, 3).map((x) => parseInt(x).toString(16).padStart(2, "0")).join(""));
		trackUse("color-convert");
	});
	const [paras, setParas] = (0, import_react.useState)(3);
	const [lorem, setLorem] = (0, import_react.useState)("");
	const genLorem = () => run("lorem-ipsum", () => {
		const base = "Lorem ipsum dolor sit amet, consectetur adipiscing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua. Ut enim ad minim veniam, quis nostrud exercitation ullamco laboris nisi ut aliquip ex ea commodo consequat.";
		setLorem(Array.from({ length: paras }, () => base).join("\n\n"));
		trackUse("lorem-ipsum");
	});
	const [htmlEd, setHtmlEd] = (0, import_react.useState)("<h1>Hello</h1>\n<p>Edit me!</p>");
	const [cssEd, setCssEd] = (0, import_react.useState)("h1 { color: #2563eb; font-family: system-ui; }");
	const [jsEd, setJsEd] = (0, import_react.useState)("console.log('hi from sandbox');");
	const previewSrc = (0, import_react.useMemo)(() => `<!doctype html><html><head><meta charset="utf-8"><style>${cssEd}</style></head><body>${htmlEd}<script>try{${jsEd}}catch(e){document.body.insertAdjacentHTML('beforeend','<pre style=\\'color:red\\'>'+e+'</pre>')}<\/script></body></html>`, [
		htmlEd,
		cssEd,
		jsEd
	]);
	const [mdIn, setMdIn] = (0, import_react.useState)("# Hello\n\nThis is **markdown** with a [link](https://example.com).");
	const mdOut = (0, import_react.useMemo)(() => {
		try {
			const raw = g.parse(mdIn, { async: false });
			return typeof window !== "undefined" ? purify.sanitize(raw) : raw;
		} catch (e) {
			return `<!-- ${e.message} -->`;
		}
	}, [mdIn]);
	const [numVal, setNumVal] = (0, import_react.useState)("255");
	const [numBase, setNumBase] = (0, import_react.useState)(10);
	const numOut = (0, import_react.useMemo)(() => {
		try {
			const n = parseInt(numVal, numBase);
			if (isNaN(n)) return {
				bin: "—",
				oct: "—",
				dec: "—",
				hex: "—"
			};
			return {
				bin: n.toString(2),
				oct: n.toString(8),
				dec: n.toString(10),
				hex: n.toString(16).toUpperCase()
			};
		} catch {
			return {
				bin: "—",
				oct: "—",
				dec: "—",
				hex: "—"
			};
		}
	}, [numVal, numBase]);
	const [phpIn, setPhpIn] = (0, import_react.useState)("<?php function hi($n){echo 'Hello '.$n;} hi('world');");
	const [phpOut, setPhpOut] = (0, import_react.useState)("");
	const formatPhp = () => run("php-format", () => {
		let d = 0;
		const out = phpIn.replace(/\s*([{};])\s*/g, "$1\n").split("\n").map((line) => {
			const t = line.trim();
			if (!t) return "";
			if (t.startsWith("}")) d = Math.max(d - 1, 0);
			const s = "  ".repeat(d) + t;
			if (t.endsWith("{")) d += 1;
			return s;
		}).filter(Boolean).join("\n");
		setPhpOut(out);
		trackUse("php-format");
	});
	const [htmlFmtIn, setHtmlFmtIn] = (0, import_react.useState)("<div><h1>Title</h1><p>Hello <strong>world</strong></p></div>");
	const [htmlFmtOut, setHtmlFmtOut] = (0, import_react.useState)("");
	const [htmlFmtWarnings, setHtmlFmtWarnings] = (0, import_react.useState)([]);
	const [htmlFmtDiff, setHtmlFmtDiff] = (0, import_react.useState)(null);
	const [htmlFmtDiffSkipped, setHtmlFmtDiffSkipped] = (0, import_react.useState)(false);
	const [htmlFmtDiffPage, setHtmlFmtDiffPage] = (0, import_react.useState)(1);
	const [htmlFmtBusy, setHtmlFmtBusy] = (0, import_react.useState)(false);
	const htmlFmtRunId = (0, import_react.useRef)(0);
	const htmlFmtTimer = (0, import_react.useRef)(null);
	const DIFF_MAX_CHARS = 5e4;
	const DIFF_PAGE_SIZE = 500;
	const runFormatHtml = (0, import_react.useCallback)((source) => {
		const myId = ++htmlFmtRunId.current;
		setHtmlFmtBusy(true);
		setTimeout(() => {
			const { output, warnings } = formatHtml(source);
			if (myId !== htmlFmtRunId.current) return;
			setHtmlFmtOut(output);
			setHtmlFmtWarnings(warnings);
			const tooBig = source.length > DIFF_MAX_CHARS || output.length > DIFF_MAX_CHARS;
			setHtmlFmtDiffSkipped(tooBig);
			setHtmlFmtDiff(tooBig ? null : lineDiff(source, output));
			setHtmlFmtDiffPage(1);
			setHtmlFmtBusy(false);
			trackUse("html-format");
		}, 0);
	}, []);
	(0, import_react.useEffect)(() => {
		if (htmlFmtTimer.current) clearTimeout(htmlFmtTimer.current);
		const delay = htmlFmtIn.length > 2e4 ? 500 : 200;
		htmlFmtTimer.current = setTimeout(() => runFormatHtml(htmlFmtIn), delay);
		return () => {
			if (htmlFmtTimer.current) clearTimeout(htmlFmtTimer.current);
		};
	}, [htmlFmtIn, runFormatHtml]);
	const [phraseText, setPhraseText] = (0, import_react.useState)("A secret message.");
	const [phrasePass, setPhrasePass] = (0, import_react.useState)("");
	const [phraseOut, setPhraseOut] = (0, import_react.useState)("");
	const [phraseErr, setPhraseErr] = (0, import_react.useState)("");
	const b64ToBuf = (b64) => Uint8Array.from(atob(b64), (c) => c.charCodeAt(0));
	const bufToB64 = (buf) => btoa(String.fromCharCode(...new Uint8Array(buf)));
	const deriveKey = async (pass, salt) => {
		const km = await crypto.subtle.importKey("raw", new TextEncoder().encode(pass), "PBKDF2", false, ["deriveKey"]);
		return crypto.subtle.deriveKey({
			name: "PBKDF2",
			salt,
			iterations: 1e5,
			hash: "SHA-256"
		}, km, {
			name: "AES-GCM",
			length: 256
		}, false, ["encrypt", "decrypt"]);
	};
	const doEncrypt = () => {
		setPhraseErr("");
		if (!phrasePass) {
			setPhraseErr("Passphrase required.");
			return;
		}
		run("phrase-crypt", async () => {
			try {
				const salt = crypto.getRandomValues(/* @__PURE__ */ new Uint8Array(16));
				const iv = crypto.getRandomValues(/* @__PURE__ */ new Uint8Array(12));
				const key = await deriveKey(phrasePass, salt);
				const ct = await crypto.subtle.encrypt({
					name: "AES-GCM",
					iv
				}, key, new TextEncoder().encode(phraseText));
				const pack = new Uint8Array(salt.length + iv.length + ct.byteLength);
				pack.set(salt, 0);
				pack.set(iv, salt.length);
				pack.set(new Uint8Array(ct), salt.length + iv.length);
				setPhraseOut(bufToB64(pack.buffer));
				trackUse("phrase-crypt");
			} catch (e) {
				setPhraseErr(e.message);
				throw e;
			}
		});
	};
	const doDecrypt = () => {
		setPhraseErr("");
		if (!phrasePass) {
			setPhraseErr("Passphrase required.");
			return;
		}
		run("phrase-crypt", async () => {
			try {
				const pack = b64ToBuf(phraseText.trim());
				const salt = pack.slice(0, 16);
				const iv = pack.slice(16, 28);
				const ct = pack.slice(28);
				const key = await deriveKey(phrasePass, salt);
				const pt = await crypto.subtle.decrypt({
					name: "AES-GCM",
					iv
				}, key, ct);
				setPhraseOut(new TextDecoder().decode(pt));
				trackUse("phrase-crypt");
			} catch (e) {
				setPhraseErr("Decryption failed — wrong passphrase or corrupt input.");
				throw e;
			}
		});
	};
	const [features, setFeatures] = (0, import_react.useState)([]);
	(0, import_react.useEffect)(() => {
		const w = window;
		const n = navigator;
		setFeatures([
			{
				name: "Clipboard API",
				ok: !!navigator.clipboard
			},
			{
				name: "Service Worker",
				ok: "serviceWorker" in navigator
			},
			{
				name: "WebGL",
				ok: !!document.createElement("canvas").getContext("webgl")
			},
			{
				name: "WebGPU",
				ok: "gpu" in navigator
			},
			{
				name: "IndexedDB",
				ok: "indexedDB" in w
			},
			{
				name: "Web Crypto (Subtle)",
				ok: !!(w.crypto && w.crypto.subtle)
			},
			{
				name: "WebRTC",
				ok: "RTCPeerConnection" in w
			},
			{
				name: "Geolocation",
				ok: "geolocation" in navigator
			},
			{
				name: "Notifications",
				ok: "Notification" in w
			},
			{
				name: "WebSocket",
				ok: "WebSocket" in w
			},
			{
				name: "Intersection Observer",
				ok: "IntersectionObserver" in w
			},
			{
				name: "ResizeObserver",
				ok: "ResizeObserver" in w
			},
			{
				name: "Web Share",
				ok: "share" in navigator
			},
			{
				name: "File System Access",
				ok: "showOpenFilePicker" in w
			},
			{
				name: "Payment Request",
				ok: "PaymentRequest" in w
			},
			{
				name: "Bluetooth",
				ok: "bluetooth" in n
			},
			{
				name: "USB",
				ok: "usb" in n
			},
			{
				name: "Speech Synthesis",
				ok: "speechSynthesis" in w
			}
		]);
	}, []);
	const [htmlSrc, setHtmlSrc] = (0, import_react.useState)("<div class=\"card\" style=\"color:red;padding:10px\" tabindex=\"0\">\n  <input type=\"text\" readonly>\n  <br>\n  <label for=\"n\">Hi</label>\n</div>");
	const htmlToJsxOut = (0, import_react.useMemo)(() => {
		try {
			return htmlToJsx(htmlSrc);
		} catch (e) {
			return `/* ${e.message} */`;
		}
	}, [htmlSrc]);
	const htmlToTsxOut = (0, import_react.useMemo)(() => {
		try {
			return htmlToTsx(htmlSrc, "Converted");
		} catch (e) {
			return `/* ${e.message} */`;
		}
	}, [htmlSrc]);
	const [jsxSrc, setJsxSrc] = (0, import_react.useState)("const App = () => {\n  return <button onClick={() => alert(\"hi\")}>Click</button>;\n};");
	const jsxToTsxOut = (0, import_react.useMemo)(() => {
		try {
			return jsxToTsx(jsxSrc, "App");
		} catch (e) {
			return `/* ${e.message} */`;
		}
	}, [jsxSrc]);
	const [tsxSrc, setTsxSrc] = (0, import_react.useState)("import type { FC } from \"react\";\n\ninterface Props { name: string }\nconst App: FC<Props> = ({ name }: Props) => {\n  const n: number = 1 as number;\n  return <div>{name} {n}</div>;\n};\nexport default App;");
	const tsxToJsxOut = (0, import_react.useMemo)(() => {
		try {
			return tsxToJsx(tsxSrc);
		} catch (e) {
			return `/* ${e.message} */`;
		}
	}, [tsxSrc]);
	const [cssSrc, setCssSrc] = (0, import_react.useState)(".card {\n  display: flex;\n  padding: 16px;\n  background-color: #2563eb;\n  color: #fff;\n  border-radius: 12px;\n  font-weight: bold;\n}");
	const cssToTwOut = (0, import_react.useMemo)(() => {
		try {
			return cssToTailwind(cssSrc);
		} catch (e) {
			return `/* ${e.message} */`;
		}
	}, [cssSrc]);
	const [twSrc, setTwSrc] = (0, import_react.useState)("flex items-center justify-between p-4 bg-[#2563eb] text-[#fff] rounded-lg font-bold shadow");
	const twToCssOut = (0, import_react.useMemo)(() => {
		try {
			return tailwindToCss(twSrc);
		} catch (e) {
			return `/* ${e.message} */`;
		}
	}, [twSrc]);
	const [lastKey, setLastKey] = (0, import_react.useState)(null);
	const [kcFilter, setKcFilter] = (0, import_react.useState)("");
	const kcRows = (0, import_react.useMemo)(() => {
		const q = kcFilter.trim().toLowerCase();
		if (!q) return KEYCODES;
		return KEYCODES.filter((r) => r.key.toLowerCase().includes(q) || r.code.toLowerCase().includes(q) || r.description.toLowerCase().includes(q) || String(r.keyCode).includes(q));
	}, [kcFilter]);
	(0, import_react.useEffect)(() => {}, []);
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Layout, { children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("section", {
		className: "mx-auto max-w-5xl px-4 py-12 sm:px-6",
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Reveal, { children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("header", {
				className: "mb-8",
				children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
						className: "text-sm font-semibold uppercase tracking-wider text-blue-600",
						children: "Code tools"
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h1", {
						className: "mt-1 text-3xl font-bold text-slate-900 sm:text-4xl dark:text-white",
						style: { fontFamily: "'Space Grotesk', sans-serif" },
						children: "Format, decode and generate"
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
						className: "mt-2 text-slate-600 dark:text-slate-400",
						children: "20+ developer utilities — HTML editor, JSON, XML, JWT, regex, hashes, AES phrase crypto, base converter and more."
					})
				]
			}) }),
			banner,
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "grid gap-5 lg:grid-cols-2",
				children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Card, {
						id: "json-format",
						toolId: "json-format",
						title: "JSON Formatter",
						desc: "Beautify or minify JSON.",
						children: [
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("textarea", {
								value: jsonIn,
								onChange: (e) => setJsonIn(e.target.value),
								rows: 5,
								className: ta,
								"aria-label": "JSON input"
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
								className: "mt-2 flex flex-wrap gap-2",
								children: [
									/* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
										onClick: jsonFmt,
										className: runBtn,
										children: "Beautify"
									}),
									/* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
										onClick: jsonMin,
										className: runBtn,
										children: "Minify"
									}),
									/* @__PURE__ */ (0, import_jsx_runtime.jsx)(CopyButton, { getText: () => jsonOut }),
									/* @__PURE__ */ (0, import_jsx_runtime.jsx)(DownloadButton, {
										getText: () => jsonOut,
										filename: "formatted.json",
										type: "application/json"
									})
								]
							}),
							jsonOut && /* @__PURE__ */ (0, import_jsx_runtime.jsx)("pre", {
								className: "mt-3 max-h-60 overflow-auto rounded-lg bg-slate-950 p-3 text-xs text-slate-100",
								children: jsonOut
							})
						]
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Card, {
						id: "xml-format",
						toolId: "xml-format",
						title: "XML Formatter",
						desc: "Pretty-print XML or RSS.",
						children: [
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("textarea", {
								value: xmlIn,
								onChange: (e) => setXmlIn(e.target.value),
								rows: 5,
								className: ta,
								"aria-label": "XML input"
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
								className: "mt-2 flex flex-wrap gap-2",
								children: [
									/* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
										onClick: () => run("xml-format", () => {
											setXmlOut(formatXML(xmlIn));
											trackUse("xml-format");
										}),
										className: runBtn,
										children: "Format"
									}),
									/* @__PURE__ */ (0, import_jsx_runtime.jsx)(CopyButton, { getText: () => xmlOut }),
									/* @__PURE__ */ (0, import_jsx_runtime.jsx)(DownloadButton, {
										getText: () => xmlOut,
										filename: "formatted.xml",
										type: "application/xml"
									})
								]
							}),
							xmlOut && /* @__PURE__ */ (0, import_jsx_runtime.jsx)("pre", {
								className: "mt-3 max-h-60 overflow-auto rounded-lg bg-slate-950 p-3 text-xs text-slate-100",
								children: xmlOut
							})
						]
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Card, {
						id: "html-minify",
						toolId: "html-minify",
						title: "HTML / CSS / JS Minifier",
						desc: "Strip whitespace and comments.",
						children: [
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("textarea", {
								value: minIn,
								onChange: (e) => setMinIn(e.target.value),
								rows: 5,
								className: ta,
								"aria-label": "Code input"
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
								className: "mt-2 flex flex-wrap gap-2",
								children: [
									/* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
										onClick: () => run("html-minify", () => {
											setMinOut(minIn.replace(/<!--[\s\S]*?-->/g, "").replace(/>\s+</g, "><").replace(/\s{2,}/g, " ").trim());
											trackUse("html-minify");
										}),
										className: runBtn,
										children: "HTML"
									}),
									/* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
										onClick: () => run("css-minify", () => {
											setMinOut(minIn.replace(/\/\*[\s\S]*?\*\//g, "").replace(/\s*([{}:;,])\s*/g, "$1").replace(/;}/g, "}").trim());
											trackUse("css-minify");
										}),
										className: runBtn,
										children: "CSS"
									}),
									/* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
										onClick: () => run("js-minify", () => {
											setMinOut(minIn.replace(/\/\*[\s\S]*?\*\//g, "").replace(/\/\/.*$/gm, "").replace(/\s{2,}/g, " ").trim());
											trackUse("js-minify");
										}),
										className: runBtn,
										children: "JS"
									}),
									/* @__PURE__ */ (0, import_jsx_runtime.jsx)(CopyButton, { getText: () => minOut }),
									/* @__PURE__ */ (0, import_jsx_runtime.jsx)(DownloadButton, {
										getText: () => minOut,
										filename: "minified.txt"
									})
								]
							}),
							minOut && /* @__PURE__ */ (0, import_jsx_runtime.jsx)("pre", {
								className: "mt-3 max-h-60 overflow-auto rounded-lg bg-slate-950 p-3 text-xs text-slate-100",
								children: minOut
							})
						]
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Card, {
						id: "sql-format",
						toolId: "sql-format",
						title: "SQL Formatter",
						desc: "Pretty-print SQL queries.",
						children: [
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("textarea", {
								value: sqlIn,
								onChange: (e) => setSqlIn(e.target.value),
								rows: 5,
								className: ta,
								"aria-label": "SQL input"
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
								className: "mt-2 flex flex-wrap gap-2",
								children: [
									/* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
										onClick: () => run("sql-format", () => {
											setSqlOut(formatSQL(sqlIn));
											trackUse("sql-format");
										}),
										className: runBtn,
										children: "Format"
									}),
									/* @__PURE__ */ (0, import_jsx_runtime.jsx)(CopyButton, { getText: () => sqlOut }),
									/* @__PURE__ */ (0, import_jsx_runtime.jsx)(DownloadButton, {
										getText: () => sqlOut,
										filename: "query.sql"
									})
								]
							}),
							sqlOut && /* @__PURE__ */ (0, import_jsx_runtime.jsx)("pre", {
								className: "mt-3 max-h-60 overflow-auto rounded-lg bg-slate-950 p-3 text-xs text-slate-100",
								children: sqlOut
							})
						]
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Card, {
						id: "jwt-decode",
						toolId: "jwt-decode",
						title: "JWT Decoder",
						desc: "Inspect the header and payload of a JSON Web Token.",
						children: [
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("textarea", {
								value: jwt,
								onChange: (e) => {
									setJwt(e.target.value);
									if (e.target.value.length > 10) trackUse("jwt-decode");
								},
								rows: 3,
								placeholder: "eyJhbGciOi...",
								className: ta,
								"aria-label": "JWT"
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
								className: "mt-2 flex flex-wrap gap-2",
								children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(CopyButton, {
									getText: () => jwtOut,
									label: "Copy decoded"
								})
							}),
							jwtOut && /* @__PURE__ */ (0, import_jsx_runtime.jsx)("pre", {
								className: "mt-3 max-h-60 overflow-auto rounded-lg bg-slate-950 p-3 text-xs text-slate-100",
								children: jwtOut
							})
						]
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Card, {
						id: "regex-test",
						toolId: "regex-test",
						title: "Regex Tester",
						desc: "Live test a regular expression.",
						children: [
							/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
								className: "flex gap-2",
								children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
									value: pattern,
									onChange: (e) => setPattern(e.target.value),
									placeholder: "pattern",
									"aria-label": "pattern",
									className: "flex-1 rounded-lg border border-slate-200 bg-white px-3 py-2 font-mono text-xs dark:border-slate-700 dark:bg-slate-950 dark:text-white"
								}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
									value: flags,
									onChange: (e) => setFlags(e.target.value),
									placeholder: "g",
									"aria-label": "flags",
									className: "w-16 rounded-lg border border-slate-200 bg-white px-3 py-2 font-mono text-xs dark:border-slate-700 dark:bg-slate-950 dark:text-white"
								})]
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("textarea", {
								value: regexInput,
								onChange: (e) => {
									setRegexInput(e.target.value);
									trackUse("regex-test");
								},
								rows: 3,
								className: `${ta} mt-2`,
								"aria-label": "Regex input"
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("pre", {
								className: "mt-3 max-h-40 overflow-auto rounded-lg bg-slate-950 p-3 text-xs text-slate-100",
								children: regexResult
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
								className: "mt-2",
								children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(CopyButton, { getText: () => regexResult })
							})
						]
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Card, {
						id: "uuid-gen",
						toolId: "uuid-gen",
						title: "UUID Generator",
						desc: "Random v4 identifiers.",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
							className: "flex items-center gap-2",
							children: [
								/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("label", {
									className: "text-sm",
									children: ["Count ", /* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
										type: "number",
										min: 1,
										max: 100,
										value: uuidCount,
										onChange: (e) => setUuidCount(+e.target.value),
										className: "ml-1 w-20 rounded border border-slate-200 px-2 py-1 dark:border-slate-700 dark:bg-slate-950 dark:text-white"
									})]
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
									onClick: genUuids,
									className: runBtn,
									children: "Generate"
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)(CopyButton, { getText: () => uuids.join("\n") }),
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)(DownloadButton, {
									getText: () => uuids.join("\n"),
									filename: "uuids.txt"
								})
							]
						}), uuids.length > 0 && /* @__PURE__ */ (0, import_jsx_runtime.jsx)("pre", {
							className: "mt-3 max-h-40 overflow-auto rounded-lg bg-slate-950 p-3 text-xs text-slate-100",
							children: uuids.join("\n")
						})]
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Card, {
						id: "hash-gen",
						toolId: "hash-gen",
						title: "Hash Generator",
						desc: "MD5, SHA-1, SHA-256, SHA-512 digests.",
						children: [
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("textarea", {
								value: hashIn,
								onChange: (e) => setHashIn(e.target.value),
								rows: 3,
								className: ta,
								"aria-label": "hash input"
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
								className: "mt-2 flex flex-wrap items-center gap-2",
								children: [
									/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("select", {
										value: hashAlgo,
										onChange: (e) => setHashAlgo(e.target.value),
										"aria-label": "Hash algorithm",
										className: "rounded-lg border border-slate-200 px-2 py-1.5 text-sm dark:border-slate-700 dark:bg-slate-950 dark:text-white",
										children: [
											/* @__PURE__ */ (0, import_jsx_runtime.jsx)("option", { children: "MD5" }),
											/* @__PURE__ */ (0, import_jsx_runtime.jsx)("option", { children: "SHA-1" }),
											/* @__PURE__ */ (0, import_jsx_runtime.jsx)("option", { children: "SHA-256" }),
											/* @__PURE__ */ (0, import_jsx_runtime.jsx)("option", { children: "SHA-512" })
										]
									}),
									/* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
										onClick: doHash,
										className: runBtn,
										children: "Hash"
									}),
									/* @__PURE__ */ (0, import_jsx_runtime.jsx)(CopyButton, { getText: () => hashOut })
								]
							}),
							hashOut && /* @__PURE__ */ (0, import_jsx_runtime.jsx)("pre", {
								className: "mt-3 break-all rounded-lg bg-slate-950 p-3 text-xs text-slate-100",
								children: hashOut
							})
						]
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Card, {
						id: "timestamp",
						toolId: "timestamp",
						title: "Timestamp Converter",
						desc: "Unix epoch ↔ ISO date.",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
							className: "grid gap-2 sm:grid-cols-2",
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)("label", {
									className: "text-xs font-medium text-slate-500",
									children: "Unix (sec)"
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
									value: ts,
									onChange: (e) => setTs(e.target.value),
									className: "mt-1 w-full rounded-lg border border-slate-200 px-3 py-2 font-mono text-sm dark:border-slate-700 dark:bg-slate-950 dark:text-white",
									"aria-label": "unix timestamp"
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
									onClick: tsToDate,
									className: `${runBtn} mt-2`,
									children: "→ Date"
								})
							] }), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)("label", {
									className: "text-xs font-medium text-slate-500",
									children: "Date (ISO)"
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
									value: dt,
									onChange: (e) => setDt(e.target.value),
									className: "mt-1 w-full rounded-lg border border-slate-200 px-3 py-2 font-mono text-sm dark:border-slate-700 dark:bg-slate-950 dark:text-white",
									"aria-label": "iso date"
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
									onClick: dateToTs,
									className: `${runBtn} mt-2`,
									children: "→ Unix"
								})
							] })]
						}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
							className: "mt-2",
							children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(CopyButton, { getText: () => `${ts}  ${dt}` })
						})]
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Card, {
						id: "color-convert",
						toolId: "color-convert",
						title: "HEX ↔ RGB",
						desc: "Convert color formats.",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
							className: "grid gap-2 sm:grid-cols-[1fr_1fr_auto]",
							children: [
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
									value: hex,
									onChange: (e) => setHex(e.target.value),
									placeholder: "#2563eb",
									"aria-label": "hex",
									className: "rounded-lg border border-slate-200 px-3 py-2 font-mono text-sm dark:border-slate-700 dark:bg-slate-950 dark:text-white"
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
									value: rgb,
									onChange: (e) => setRgb(e.target.value),
									placeholder: "rgb(37,99,235)",
									"aria-label": "rgb",
									className: "rounded-lg border border-slate-200 px-3 py-2 font-mono text-sm dark:border-slate-700 dark:bg-slate-950 dark:text-white"
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
									className: "grid place-items-center rounded-lg border border-slate-200 dark:border-slate-700",
									style: { background: hex },
									"aria-label": "color preview",
									children: "\xA0\xA0\xA0\xA0"
								})
							]
						}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
							className: "mt-2 flex flex-wrap gap-2",
							children: [
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
									onClick: hexToRgb,
									className: runBtn,
									children: "HEX → RGB"
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
									onClick: rgbToHex,
									className: runBtn,
									children: "RGB → HEX"
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)(CopyButton, { getText: () => `${hex}  ${rgb}` })
							]
						})]
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Card, {
						id: "lorem-ipsum",
						toolId: "lorem-ipsum",
						title: "Lorem Ipsum",
						desc: "Generate placeholder paragraphs.",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
							className: "flex items-center gap-2",
							children: [
								/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("label", {
									className: "text-sm",
									children: ["Paragraphs ", /* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
										type: "number",
										min: 1,
										max: 20,
										value: paras,
										onChange: (e) => setParas(+e.target.value),
										className: "ml-1 w-20 rounded border border-slate-200 px-2 py-1 dark:border-slate-700 dark:bg-slate-950 dark:text-white"
									})]
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
									onClick: genLorem,
									className: runBtn,
									children: "Generate"
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)(CopyButton, { getText: () => lorem }),
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)(DownloadButton, {
									getText: () => lorem,
									filename: "lorem.txt"
								})
							]
						}), lorem && /* @__PURE__ */ (0, import_jsx_runtime.jsx)("pre", {
							className: "mt-3 max-h-60 overflow-auto whitespace-pre-wrap rounded-lg bg-slate-50 p-3 text-xs text-slate-700 dark:bg-slate-950 dark:text-slate-200",
							children: lorem
						})]
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Card, {
						id: "html-editor",
						toolId: "html-editor",
						title: "HTML Live Editor",
						desc: "Edit HTML, CSS and JS with a sandboxed live preview.",
						children: [
							/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
								className: "grid gap-2 sm:grid-cols-3",
								children: [
									/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("label", {
										className: "text-xs font-medium text-slate-500",
										children: "HTML"
									}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("textarea", {
										value: htmlEd,
										onChange: (e) => {
											setHtmlEd(e.target.value);
											trackUse("html-editor");
										},
										rows: 6,
										className: `${ta} mt-1`,
										"aria-label": "HTML"
									})] }),
									/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("label", {
										className: "text-xs font-medium text-slate-500",
										children: "CSS"
									}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("textarea", {
										value: cssEd,
										onChange: (e) => setCssEd(e.target.value),
										rows: 6,
										className: `${ta} mt-1`,
										"aria-label": "CSS"
									})] }),
									/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("label", {
										className: "text-xs font-medium text-slate-500",
										children: "JS"
									}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("textarea", {
										value: jsEd,
										onChange: (e) => setJsEd(e.target.value),
										rows: 6,
										className: `${ta} mt-1`,
										"aria-label": "JavaScript"
									})] })
								]
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
								className: "mt-3 overflow-hidden rounded-lg border border-slate-200 dark:border-slate-700",
								children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("iframe", {
									title: "HTML preview",
									sandbox: "allow-scripts",
									srcDoc: previewSrc,
									className: "h-64 w-full bg-white"
								})
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
								className: "mt-2 flex flex-wrap gap-2",
								children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(CopyButton, {
									getText: () => previewSrc,
									label: "Copy document"
								}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(DownloadButton, {
									getText: () => previewSrc,
									filename: "playground.html",
									type: "text/html"
								})]
							})
						]
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Card, {
						id: "markdown",
						toolId: "markdown-html",
						title: "Markdown to HTML",
						desc: "Convert Markdown to HTML on the fly.",
						children: [
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("textarea", {
								value: mdIn,
								onChange: (e) => {
									setMdIn(e.target.value);
									trackUse("markdown-html");
								},
								rows: 6,
								className: ta,
								"aria-label": "Markdown input"
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
								className: "mt-2 flex flex-wrap gap-2",
								children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(CopyButton, {
									getText: () => mdOut,
									label: "Copy HTML"
								}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(DownloadButton, {
									getText: () => mdOut,
									filename: "output.html",
									type: "text/html"
								})]
							}),
							mdOut && /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(import_jsx_runtime.Fragment, { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("pre", {
								className: "mt-3 max-h-40 overflow-auto rounded-lg bg-slate-950 p-3 text-xs text-slate-100",
								children: mdOut
							}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
								className: "mt-2 rounded-lg border border-slate-200 bg-white p-3 text-sm text-slate-800 dark:border-slate-700 dark:bg-slate-950 dark:text-slate-100 prose prose-sm max-w-none",
								dangerouslySetInnerHTML: { __html: mdOut }
							})] })
						]
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Card, {
						id: "number-base",
						toolId: "number-base",
						title: "Number Base Converter",
						desc: "Binary, octal, decimal and hexadecimal — all directions.",
						children: [
							/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
								className: "flex flex-wrap items-center gap-2",
								children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("label", {
									className: "text-sm",
									children: ["Input base", /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("select", {
										value: numBase,
										onChange: (e) => {
											setNumBase(Number(e.target.value));
											trackUse("number-base");
										},
										"aria-label": "Input base",
										className: "ml-2 rounded border border-slate-200 px-2 py-1 dark:border-slate-700 dark:bg-slate-950 dark:text-white",
										children: [
											/* @__PURE__ */ (0, import_jsx_runtime.jsx)("option", {
												value: 2,
												children: "Binary"
											}),
											/* @__PURE__ */ (0, import_jsx_runtime.jsx)("option", {
												value: 8,
												children: "Octal"
											}),
											/* @__PURE__ */ (0, import_jsx_runtime.jsx)("option", {
												value: 10,
												children: "Decimal"
											}),
											/* @__PURE__ */ (0, import_jsx_runtime.jsx)("option", {
												value: 16,
												children: "Hex"
											})
										]
									})]
								}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
									value: numVal,
									onChange: (e) => setNumVal(e.target.value),
									"aria-label": "Number value",
									className: "flex-1 rounded-lg border border-slate-200 px-3 py-2 font-mono text-sm dark:border-slate-700 dark:bg-slate-950 dark:text-white"
								})]
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("dl", {
								className: "mt-3 grid grid-cols-2 gap-2 text-sm sm:grid-cols-4",
								children: [
									/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("dt", {
										className: "text-xs text-slate-500",
										children: "Binary"
									}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("dd", {
										className: "break-all font-mono",
										children: numOut.bin
									})] }),
									/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("dt", {
										className: "text-xs text-slate-500",
										children: "Octal"
									}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("dd", {
										className: "break-all font-mono",
										children: numOut.oct
									})] }),
									/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("dt", {
										className: "text-xs text-slate-500",
										children: "Decimal"
									}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("dd", {
										className: "break-all font-mono",
										children: numOut.dec
									})] }),
									/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("dt", {
										className: "text-xs text-slate-500",
										children: "Hex"
									}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("dd", {
										className: "break-all font-mono",
										children: numOut.hex
									})] })
								]
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
								className: "mt-2",
								children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(CopyButton, { getText: () => `bin: ${numOut.bin}\noct: ${numOut.oct}\ndec: ${numOut.dec}\nhex: ${numOut.hex}` })
							})
						]
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Card, {
						id: "html-format",
						toolId: "html-format",
						title: "HTML Formatter",
						desc: "Pretty-print HTML with browser-accurate whitespace, validation warnings, and a side-by-side diff.",
						children: [
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("textarea", {
								value: htmlFmtIn,
								onChange: (e) => setHtmlFmtIn(e.target.value),
								rows: 5,
								className: ta,
								"aria-label": "HTML input"
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
								className: "mt-2 flex flex-wrap items-center gap-2",
								children: [
									/* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
										onClick: () => run("html-format", () => runFormatHtml(htmlFmtIn)),
										className: runBtn,
										"aria-busy": htmlFmtBusy,
										disabled: htmlFmtBusy,
										children: "Format"
									}),
									/* @__PURE__ */ (0, import_jsx_runtime.jsx)(CopyButton, { getText: () => htmlFmtOut }),
									/* @__PURE__ */ (0, import_jsx_runtime.jsx)(DownloadButton, {
										getText: () => htmlFmtOut,
										filename: "formatted.html",
										type: "text/html"
									}),
									htmlFmtBusy && /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", {
										role: "status",
										"aria-live": "polite",
										className: "inline-flex items-center gap-2 text-xs text-slate-500",
										children: [
											/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
												"aria-hidden": "true",
												className: "h-3 w-3 animate-spin rounded-full border-2 border-slate-300 border-t-slate-600 dark:border-slate-700 dark:border-t-slate-200"
											}),
											"Formatting ",
											htmlFmtIn.length.toLocaleString(),
											" chars…"
										]
									})
								]
							}),
							htmlFmtWarnings.length > 0 && /* @__PURE__ */ (0, import_jsx_runtime.jsx)("ul", {
								role: "status",
								"aria-live": "polite",
								className: "mt-3 space-y-1 rounded-lg border border-amber-300 bg-amber-50 p-3 text-xs text-amber-900 dark:border-amber-700/50 dark:bg-amber-950/40 dark:text-amber-200",
								children: htmlFmtWarnings.map((w, idx) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("li", { children: [
									/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", {
										className: "font-semibold uppercase tracking-wide",
										children: [w.kind, ":"]
									}),
									" ",
									w.message
								] }, idx))
							}),
							htmlFmtOut && htmlFmtDiffSkipped && /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
								role: "status",
								"aria-live": "polite",
								className: "mt-3 rounded-lg border border-slate-200 bg-slate-50 p-3 text-xs text-slate-600 dark:border-slate-700 dark:bg-slate-900 dark:text-slate-300",
								children: [
									"Diff preview hidden for large inputs (over ",
									DIFF_MAX_CHARS.toLocaleString(),
									" characters). The full formatted HTML is available via Copy and Download above."
								]
							}),
							htmlFmtOut && htmlFmtDiff && (() => {
								const totalLeft = htmlFmtDiff.left.length;
								const totalRight = htmlFmtDiff.right.length;
								const shown = htmlFmtDiffPage * DIFF_PAGE_SIZE;
								const leftSlice = htmlFmtDiff.left.slice(0, shown);
								const rightSlice = htmlFmtDiff.right.slice(0, shown);
								const hasMore = shown < Math.max(totalLeft, totalRight);
								return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
									className: "mt-3 space-y-2",
									children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
										className: "grid gap-2 md:grid-cols-2",
										children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
											className: "mb-1 text-xs font-medium text-slate-500",
											children: "Original"
										}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("pre", {
											className: "max-h-72 overflow-auto rounded-lg bg-slate-950 p-3 text-xs leading-5 text-slate-100",
											"aria-label": "Original HTML with removed lines highlighted",
											children: leftSlice.map((p, i) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
												className: p.kind === "del" ? "bg-red-500/25 text-red-100" : "",
												children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
													className: "mr-2 select-none text-slate-500",
													children: p.kind === "del" ? "-" : " "
												}), p.value || "\xA0"]
											}, i))
										})] }), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
											className: "mb-1 text-xs font-medium text-slate-500",
											children: "Formatted"
										}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("pre", {
											className: "max-h-72 overflow-auto rounded-lg bg-slate-950 p-3 text-xs leading-5 text-slate-100",
											"aria-label": "Formatted HTML with added lines highlighted",
											children: rightSlice.map((p, i) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
												className: p.kind === "add" ? "bg-emerald-500/25 text-emerald-100" : "",
												children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
													className: "mr-2 select-none text-slate-500",
													children: p.kind === "add" ? "+" : " "
												}), p.value || "\xA0"]
											}, i))
										})] })]
									}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
										className: "flex flex-wrap items-center gap-2 text-xs text-slate-500",
										"aria-live": "polite",
										children: [
											/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", { children: [
												"Showing ",
												Math.min(shown, totalLeft).toLocaleString(),
												" / ",
												totalLeft.toLocaleString(),
												" original · ",
												Math.min(shown, totalRight).toLocaleString(),
												" / ",
												totalRight.toLocaleString(),
												" formatted lines"
											] }),
											hasMore && /* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
												onClick: () => setHtmlFmtDiffPage((p) => p + 1),
												className: "rounded-md border border-slate-300 px-2 py-1 text-xs font-medium hover:bg-slate-50 dark:border-slate-700 dark:hover:bg-slate-800",
												children: "Show more"
											}),
											shown > DIFF_PAGE_SIZE && /* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
												onClick: () => setHtmlFmtDiffPage(1),
												className: "rounded-md border border-slate-300 px-2 py-1 text-xs font-medium hover:bg-slate-50 dark:border-slate-700 dark:hover:bg-slate-800",
												children: "Collapse"
											})
										]
									})]
								});
							})()
						]
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Card, {
						id: "php-format",
						toolId: "php-format",
						title: "PHP Formatter",
						desc: "Basic PHP re-indentation.",
						children: [
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("textarea", {
								value: phpIn,
								onChange: (e) => setPhpIn(e.target.value),
								rows: 5,
								className: ta,
								"aria-label": "PHP input"
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
								className: "mt-2 flex flex-wrap gap-2",
								children: [
									/* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
										onClick: formatPhp,
										className: runBtn,
										children: "Format"
									}),
									/* @__PURE__ */ (0, import_jsx_runtime.jsx)(CopyButton, { getText: () => phpOut }),
									/* @__PURE__ */ (0, import_jsx_runtime.jsx)(DownloadButton, {
										getText: () => phpOut,
										filename: "formatted.php"
									})
								]
							}),
							phpOut && /* @__PURE__ */ (0, import_jsx_runtime.jsx)("pre", {
								className: "mt-3 max-h-60 overflow-auto rounded-lg bg-slate-950 p-3 text-xs text-slate-100",
								children: phpOut
							})
						]
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Card, {
						id: "phrase-crypt",
						toolId: "phrase-crypt",
						title: "Phrase Encrypt / Decrypt",
						desc: "AES-GCM 256 with PBKDF2 passphrase (100k iterations). Runs locally.",
						children: [
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("textarea", {
								value: phraseText,
								onChange: (e) => setPhraseText(e.target.value),
								rows: 4,
								className: ta,
								"aria-label": "Text or ciphertext",
								placeholder: "Plain text to encrypt, or ciphertext to decrypt"
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
								type: "password",
								value: phrasePass,
								onChange: (e) => setPhrasePass(e.target.value),
								className: "mt-2 w-full rounded-lg border border-slate-200 px-3 py-2 text-sm dark:border-slate-700 dark:bg-slate-950 dark:text-white",
								"aria-label": "Passphrase",
								placeholder: "Passphrase"
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
								className: "mt-2 flex flex-wrap gap-2",
								children: [
									/* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
										onClick: doEncrypt,
										className: runBtn,
										children: "Encrypt"
									}),
									/* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
										onClick: doDecrypt,
										className: runBtn,
										children: "Decrypt"
									}),
									/* @__PURE__ */ (0, import_jsx_runtime.jsx)(CopyButton, { getText: () => phraseOut })
								]
							}),
							phraseErr && /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
								role: "alert",
								className: "mt-2 text-xs text-red-600",
								children: phraseErr
							}),
							phraseOut && /* @__PURE__ */ (0, import_jsx_runtime.jsx)("pre", {
								className: "mt-3 max-h-40 overflow-auto break-all rounded-lg bg-slate-950 p-3 text-xs text-slate-100",
								children: phraseOut
							})
						]
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Card, {
						id: "browser-features",
						toolId: "browser-features",
						title: "Browser Feature Detection",
						desc: "Which modern web APIs your browser supports.",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("ul", {
							className: "grid grid-cols-1 gap-1 sm:grid-cols-2 md:grid-cols-3",
							children: features.map((f) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("li", {
								className: "flex items-center justify-between rounded-lg border border-slate-200 px-3 py-1.5 text-sm dark:border-slate-700",
								children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
									className: "text-slate-700 dark:text-slate-200",
									children: f.name
								}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
									"aria-label": f.ok ? "supported" : "not supported",
									className: f.ok ? "text-green-600" : "text-slate-400",
									children: f.ok ? "✓" : "✗"
								})]
							}, f.name))
						}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
							className: "mt-2",
							children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(CopyButton, {
								getText: () => features.map((f) => `${f.ok ? "✓" : "✗"} ${f.name}`).join("\n"),
								label: "Copy report"
							})
						})]
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Card, {
						id: "html-to-jsx",
						toolId: "html-to-jsx",
						title: "HTML to JSX Converter",
						desc: "Rewrites class→className, inline styles to objects, and self-closes void tags.",
						children: [
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("textarea", {
								value: htmlSrc,
								onChange: (e) => {
									setHtmlSrc(e.target.value);
									trackUse("html-to-jsx");
								},
								rows: 6,
								className: ta,
								"aria-label": "HTML source"
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
								className: "mt-2 flex flex-wrap gap-2",
								children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(CopyButton, {
									getText: () => htmlToJsxOut,
									label: "Copy JSX"
								}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(DownloadButton, {
									getText: () => htmlToJsxOut,
									filename: "component.jsx"
								})]
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("pre", {
								className: "mt-3 max-h-60 overflow-auto rounded-lg bg-slate-950 p-3 text-xs text-slate-100",
								children: htmlToJsxOut
							})
						]
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Card, {
						id: "html-to-tsx",
						toolId: "html-to-tsx",
						title: "HTML to TSX Converter",
						desc: "Wraps converted JSX in a typed React function component.",
						children: [
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("textarea", {
								value: htmlSrc,
								onChange: (e) => {
									setHtmlSrc(e.target.value);
									trackUse("html-to-tsx");
								},
								rows: 6,
								className: ta,
								"aria-label": "HTML source (shared)"
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
								className: "mt-2 flex flex-wrap gap-2",
								children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(CopyButton, {
									getText: () => htmlToTsxOut,
									label: "Copy TSX"
								}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(DownloadButton, {
									getText: () => htmlToTsxOut,
									filename: "Component.tsx"
								})]
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("pre", {
								className: "mt-3 max-h-60 overflow-auto rounded-lg bg-slate-950 p-3 text-xs text-slate-100",
								children: htmlToTsxOut
							})
						]
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Card, {
						id: "jsx-to-tsx",
						toolId: "jsx-to-tsx",
						title: "JSX to TSX Converter",
						desc: "Adds an FC-typed signature and a React type import.",
						children: [
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("textarea", {
								value: jsxSrc,
								onChange: (e) => {
									setJsxSrc(e.target.value);
									trackUse("jsx-to-tsx");
								},
								rows: 6,
								className: ta,
								"aria-label": "JSX source"
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
								className: "mt-2 flex flex-wrap gap-2",
								children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(CopyButton, {
									getText: () => jsxToTsxOut,
									label: "Copy TSX"
								}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(DownloadButton, {
									getText: () => jsxToTsxOut,
									filename: "Component.tsx"
								})]
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("pre", {
								className: "mt-3 max-h-60 overflow-auto rounded-lg bg-slate-950 p-3 text-xs text-slate-100",
								children: jsxToTsxOut
							})
						]
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Card, {
						id: "tsx-to-jsx",
						toolId: "tsx-to-jsx",
						title: "TSX to JSX Converter",
						desc: "Strips TypeScript annotations, generics, casts and type imports (best-effort).",
						children: [
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("textarea", {
								value: tsxSrc,
								onChange: (e) => {
									setTsxSrc(e.target.value);
									trackUse("tsx-to-jsx");
								},
								rows: 6,
								className: ta,
								"aria-label": "TSX source"
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
								className: "mt-2 flex flex-wrap gap-2",
								children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(CopyButton, {
									getText: () => tsxToJsxOut,
									label: "Copy JSX"
								}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(DownloadButton, {
									getText: () => tsxToJsxOut,
									filename: "Component.jsx"
								})]
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("pre", {
								className: "mt-3 max-h-60 overflow-auto rounded-lg bg-slate-950 p-3 text-xs text-slate-100",
								children: tsxToJsxOut
							})
						]
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Card, {
						id: "css-to-tailwind",
						toolId: "css-to-tailwind",
						title: "CSS to Tailwind Converter",
						desc: "Maps plain CSS declarations to Tailwind utility classes. Uses arbitrary values where needed.",
						children: [
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("textarea", {
								value: cssSrc,
								onChange: (e) => {
									setCssSrc(e.target.value);
									trackUse("css-to-tailwind");
								},
								rows: 6,
								className: ta,
								"aria-label": "CSS source"
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
								className: "mt-2 flex flex-wrap gap-2",
								children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(CopyButton, {
									getText: () => cssToTwOut,
									label: "Copy classes"
								}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(DownloadButton, {
									getText: () => cssToTwOut,
									filename: "tailwind.txt"
								})]
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("pre", {
								className: "mt-3 max-h-60 overflow-auto rounded-lg bg-slate-950 p-3 text-xs text-slate-100",
								children: cssToTwOut
							})
						]
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Card, {
						id: "tailwind-to-css",
						toolId: "tailwind-to-css",
						title: "Tailwind to CSS Converter",
						desc: "Expand Tailwind utility classes into a CSS rule block.",
						children: [
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("textarea", {
								value: twSrc,
								onChange: (e) => {
									setTwSrc(e.target.value);
									trackUse("tailwind-to-css");
								},
								rows: 4,
								className: ta,
								"aria-label": "Tailwind classes"
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
								className: "mt-2 flex flex-wrap gap-2",
								children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(CopyButton, {
									getText: () => twToCssOut,
									label: "Copy CSS"
								}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(DownloadButton, {
									getText: () => twToCssOut,
									filename: "styles.css",
									type: "text/css"
								})]
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("pre", {
								className: "mt-3 max-h-60 overflow-auto rounded-lg bg-slate-950 p-3 text-xs text-slate-100",
								children: twToCssOut
							})
						]
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Card, {
						id: "js-keycodes",
						toolId: "js-keycodes",
						title: "JavaScript Keycode Table",
						desc: "Reference for event.key, event.code, keyCode and which. Focus the box and press any key.",
						children: [
							/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
								className: "grid gap-2 sm:grid-cols-2",
								children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
									type: "text",
									onKeyDown: (e) => {
										e.preventDefault();
										setLastKey({
											key: e.key,
											code: e.code,
											keyCode: e.keyCode,
											which: e.which,
											description: "Live capture"
										});
										trackUse("js-keycodes");
									},
									placeholder: "Focus me and press any key…",
									"aria-label": "Keycode capture input",
									className: "rounded-lg border border-slate-200 bg-white px-3 py-2 text-sm dark:border-slate-700 dark:bg-slate-950 dark:text-white"
								}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
									value: kcFilter,
									onChange: (e) => setKcFilter(e.target.value),
									placeholder: "Filter table (key, code, number)…",
									"aria-label": "Filter keycodes",
									className: "rounded-lg border border-slate-200 bg-white px-3 py-2 text-sm dark:border-slate-700 dark:bg-slate-950 dark:text-white"
								})]
							}),
							lastKey && /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
								className: "mt-3 grid grid-cols-2 gap-2 rounded-lg border border-blue-200 bg-blue-50 p-3 text-xs dark:border-blue-900 dark:bg-blue-950/40 sm:grid-cols-4",
								role: "status",
								"aria-live": "polite",
								children: [
									/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("dt", {
										className: "font-semibold text-slate-500",
										children: "event.key"
									}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("dd", {
										className: "font-mono",
										children: lastKey.key === " " ? "Space" : lastKey.key
									})] }),
									/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("dt", {
										className: "font-semibold text-slate-500",
										children: "event.code"
									}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("dd", {
										className: "font-mono",
										children: lastKey.code
									})] }),
									/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("dt", {
										className: "font-semibold text-slate-500",
										children: "keyCode"
									}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("dd", {
										className: "font-mono",
										children: lastKey.keyCode
									})] }),
									/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("dt", {
										className: "font-semibold text-slate-500",
										children: "which"
									}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("dd", {
										className: "font-mono",
										children: lastKey.which
									})] })
								]
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
								className: "mt-3 max-h-80 overflow-auto rounded-lg border border-slate-200 dark:border-slate-700",
								children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("table", {
									className: "w-full text-left text-xs",
									children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("thead", {
										className: "sticky top-0 bg-slate-100 dark:bg-slate-800",
										children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("tr", { children: [
											/* @__PURE__ */ (0, import_jsx_runtime.jsx)("th", {
												scope: "col",
												className: "px-3 py-2 font-semibold",
												children: "key"
											}),
											/* @__PURE__ */ (0, import_jsx_runtime.jsx)("th", {
												scope: "col",
												className: "px-3 py-2 font-semibold",
												children: "code"
											}),
											/* @__PURE__ */ (0, import_jsx_runtime.jsx)("th", {
												scope: "col",
												className: "px-3 py-2 font-semibold",
												children: "keyCode"
											}),
											/* @__PURE__ */ (0, import_jsx_runtime.jsx)("th", {
												scope: "col",
												className: "px-3 py-2 font-semibold",
												children: "Description"
											})
										] })
									}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("tbody", { children: kcRows.map((r) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("tr", {
										className: "border-t border-slate-100 dark:border-slate-800",
										children: [
											/* @__PURE__ */ (0, import_jsx_runtime.jsx)("td", {
												className: "px-3 py-1.5 font-mono",
												children: r.key === " " ? "Space" : r.key
											}),
											/* @__PURE__ */ (0, import_jsx_runtime.jsx)("td", {
												className: "px-3 py-1.5 font-mono",
												children: r.code
											}),
											/* @__PURE__ */ (0, import_jsx_runtime.jsx)("td", {
												className: "px-3 py-1.5 font-mono",
												children: r.keyCode
											}),
											/* @__PURE__ */ (0, import_jsx_runtime.jsx)("td", {
												className: "px-3 py-1.5 text-slate-600 dark:text-slate-300",
												children: r.description
											})
										]
									}, r.code)) })]
								})
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
								className: "mt-2",
								children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(CopyButton, {
									getText: () => KEYCODES.map((r) => `${r.key}\t${r.code}\t${r.keyCode}`).join("\n"),
									label: "Copy full table"
								})
							})
						]
					})
				]
			})
		]
	}) });
}
//#endregion
export { CodeTools as component };
