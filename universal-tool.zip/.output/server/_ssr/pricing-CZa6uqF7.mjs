import { o as __toESM } from "../_runtime.mjs";
import { nt as require_react } from "../_libs/@hookform/resolvers+[...].mjs";
import { g as Link } from "../_libs/@tanstack/react-router+[...].mjs";
import { r as require_jsx_runtime } from "../_libs/react+tanstack__react-query.mjs";
import { n as Layout } from "./Layout-8Jn4q3kq.mjs";
import { t as Reveal } from "./Reveal-CydLpVW7.mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/pricing-CZa6uqF7.js
var import_react = /* @__PURE__ */ __toESM(require_react());
var import_jsx_runtime = require_jsx_runtime();
var PLANS = [
	{
		name: "Free",
		price: "$0",
		tagline: "forever, no card",
		features: [
			"All text, code, color, password & productivity tools — unlimited",
			"PDF & Image tools: 3/day as guest · 10/day with a free account",
			"Favorites & recently used (with free account)",
			"100% in-browser — files never leave your device"
		],
		cta: "Get started free",
		to: "/signup"
	},
	{
		name: "Premium",
		price: "$5",
		tagline: "per month",
		features: [
			"Unlimited PDF & Image tool usage",
			"Bulk processing",
			"Tool history & favorites",
			"Priority email support"
		],
		cta: "Upgrade to Premium",
		to: "/signup",
		featured: true
	},
	{
		name: "Pro",
		price: "$50",
		originalPrice: "$100",
		tagline: "one-time · lifetime",
		badge: "Limited time — 50% off",
		features: [
			"Everything in Premium — forever",
			"Unlimited usage across multiple devices",
			"All upcoming tools included at no extra cost",
			"Lifetime updates & priority support",
			"Pay once, own it for life"
		],
		cta: "Claim Pro Lifetime",
		to: "/signup",
		highlight: true
	}
];
function useCountdown() {
	const [now, setNow] = (0, import_react.useState)(0);
	const [target, setTarget] = (0, import_react.useState)(0);
	(0, import_react.useEffect)(() => {
		const key = "pro-lifetime-deal-ends";
		let t = Number(window.localStorage.getItem(key));
		if (!Number.isFinite(t) || t <= Date.now()) {
			t = Date.now() + 168 * 3600 * 1e3;
			window.localStorage.setItem(key, String(t));
		}
		setTarget(t);
		setNow(Date.now());
		const id = setInterval(() => setNow(Date.now()), 1e3);
		return () => clearInterval(id);
	}, []);
	const diff = target && now ? Math.max(0, target - now) : 0;
	return {
		d: Math.floor(diff / 864e5),
		h: Math.floor(diff % 864e5 / 36e5),
		m: Math.floor(diff % 36e5 / 6e4),
		s: Math.floor(diff % 6e4 / 1e3),
		expired: target > 0 && diff === 0,
		ready: target > 0
	};
}
function Countdown() {
	const { d, h, m, s, expired, ready } = useCountdown();
	const cell = (v, l) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "flex min-w-[3.5rem] flex-col items-center rounded-lg bg-slate-900 px-2 py-1.5 text-white shadow dark:bg-black",
		children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
			className: "text-lg font-bold tabular-nums",
			children: String(v).padStart(2, "0")
		}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
			className: "text-[10px] uppercase tracking-wide text-slate-300",
			children: l
		})]
	});
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "mt-6 flex flex-col items-center gap-2 rounded-xl border border-amber-300 bg-amber-50 p-4 dark:border-amber-700/50 dark:bg-amber-950/30",
		children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
			className: "text-sm font-semibold text-amber-800 dark:text-amber-300",
			children: expired ? "Deal ended" : "🔥 Pro lifetime $50 offer ends in"
		}), ready && !expired && /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
			className: "flex gap-2",
			children: [
				cell(d, "days"),
				cell(h, "hrs"),
				cell(m, "min"),
				cell(s, "sec")
			]
		})]
	});
}
var COMPARE_ROWS = [
	{
		feature: "Text / code / color / password / productivity tools",
		guest: "Unlimited",
		free: "Unlimited",
		premium: "Unlimited",
		pro: "Unlimited"
	},
	{
		feature: "PDF & Image tools per day",
		guest: "3",
		free: "10",
		premium: "Unlimited",
		pro: "Unlimited"
	},
	{
		feature: "Favorites & recently used",
		guest: "✓",
		free: "✓",
		premium: "✓",
		pro: "✓"
	},
	{
		feature: "Multi-device use (desktop, laptop, tablet, mobile)",
		guest: "✓",
		free: "✓",
		premium: "✓",
		pro: "✓"
	},
	{
		feature: "Access to core tools library",
		guest: "Limited preview",
		free: "Limited preview",
		premium: "Full library",
		pro: "Full library"
	},
	{
		feature: "Bulk processing",
		guest: "—",
		free: "—",
		premium: "✓",
		pro: "✓"
	},
	{
		feature: "Tool history (cloud-synced)",
		guest: "—",
		free: "—",
		premium: "✓",
		pro: "✓"
	},
	{
		feature: "Priority support",
		guest: "—",
		free: "—",
		premium: "✓",
		pro: "✓"
	},
	{
		feature: "All upcoming tools included",
		guest: "—",
		free: "—",
		premium: "✓",
		pro: "✓"
	},
	{
		feature: "Billing",
		guest: "Free",
		free: "Free",
		premium: "$5 / month",
		pro: "$50 one-time"
	}
];
var FAQS = [
	{
		q: "Are UniversalTools really free?",
		a: "Yes. Text, code, color, password and productivity tools are unlimited for everyone — no account or card required. PDF and image tools have a small daily cap on the free tiers."
	},
	{
		q: "Do I need an account to use the tools?",
		a: "No. You can use tools as a guest right away. Signing up is free and raises your PDF/image daily limit and lets favorites and recent history sync across devices."
	},
	{
		q: "How do I sign up?",
		a: "Click 'Sign up free' on any pricing card. You can create an account with email + password, or continue with Google in one click."
	},
	{
		q: "Can I log in with Google after signing up with email (or vice versa)?",
		a: "Yes. If both methods use the same verified email address, they map to the same account — no duplicates."
	},
	{
		q: "What's the difference between guest and a free account?",
		a: "Guests get 3 PDF/image tool runs per day and can preview the tool library. A free account raises the daily cap to 10, unlocks the full library, and syncs favorites and recently used across devices."
	},
	{
		q: "What does Premium include?",
		a: "$5/month gives unlimited PDF & image processing, bulk operations, cloud-synced tool history, priority support, and every upcoming tool at no extra cost."
	},
	{
		q: "What does the Pro lifetime deal include?",
		a: "One payment of $50 (regularly $100) unlocks everything in Premium — forever. No monthly fee, no renewal, and every future tool is included."
	},
	{
		q: "Is the $50 Pro price permanent?",
		a: "No. The $50 price is a limited-time launch offer (50% off the regular $100). Once the countdown ends, Pro returns to full price."
	},
	{
		q: "How many devices can I use my plan on?",
		a: "All plans — including guest and free — work on desktop, laptop, tablet and mobile. There's no device cap. Just sign in on each device to sync favorites and history."
	},
	{
		q: "Can I cancel Premium anytime?",
		a: "Yes. Premium is billed monthly and you can cancel from your account at any time — you'll keep access until the current period ends."
	},
	{
		q: "Do you offer refunds?",
		a: "Premium can be cancelled at any time. For the Pro lifetime deal, contact support within 7 days of purchase for a full refund."
	},
	{
		q: "Are my files uploaded to a server?",
		a: "No. Every tool runs 100% in your browser — your files never leave your device. Only your account settings, favorites and tool history sync to the cloud."
	},
	{
		q: "What payment methods do you accept?",
		a: "All major credit and debit cards. You'll see the exact options at checkout."
	},
	{
		q: "I forgot my password — what do I do?",
		a: "Go to the sign-in page and click 'Forgot password?'. We'll email you a secure reset link that expires in one hour."
	},
	{
		q: "Can I upgrade from Free to Premium or Pro later?",
		a: "Yes. Upgrade any time from your account — your favorites, history and settings carry over."
	}
];
function Pricing() {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Layout, { children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("section", {
		className: "mx-auto max-w-6xl px-4 py-20 sm:px-6",
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Reveal, { children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "text-center",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h1", {
					className: "text-4xl font-bold text-slate-900 sm:text-5xl dark:text-white",
					style: { fontFamily: "'Space Grotesk', sans-serif" },
					children: "Simple, honest pricing for every toolset"
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
					className: "mt-4 text-lg text-slate-600 dark:text-slate-300",
					children: "Most tools are free forever. PDF & Image tools have daily caps — sign up or go Premium for more."
				})]
			}) }),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
				className: "mt-8 rounded-xl border border-slate-200 bg-white/60 p-4 text-sm text-slate-700 dark:border-slate-800 dark:bg-slate-900/60 dark:text-slate-300",
				children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("strong", { children: "Daily limits apply to PDF & Image tools only:" }), " 3/day as guest · 10/day with a free account · unlimited on Premium & Pro. Every other category (text, code, color, password, productivity) is unlimited for everyone."] })
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Countdown, {}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h2", {
				className: "mt-12 text-center text-2xl font-bold text-slate-900 dark:text-white",
				children: "Choose your plan"
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
				className: "mt-6 grid gap-6 md:grid-cols-3",
				children: PLANS.map((p, i) => {
					const cardBg = p.featured ? "border-blue-500 bg-gradient-to-b from-blue-600 to-blue-700 text-white shadow-2xl shadow-blue-600/30" : p.highlight ? "border-amber-400 bg-gradient-to-b from-amber-50 to-white shadow-2xl shadow-amber-500/20 dark:from-amber-950/40 dark:to-slate-900" : "border-slate-200 bg-white dark:border-slate-800 dark:bg-slate-900";
					const titleColor = p.featured ? "text-white" : "text-slate-900 dark:text-white";
					const taglineColor = p.featured ? "text-blue-100" : "text-slate-500 dark:text-slate-400";
					const featureColor = p.featured ? "text-blue-50" : "text-slate-600 dark:text-slate-300";
					const btnClass = p.featured ? "bg-white text-blue-700 hover:bg-blue-50" : p.highlight ? "bg-amber-500 text-white hover:bg-amber-600" : "bg-blue-600 text-white hover:bg-blue-700";
					return /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Reveal, {
						delay: i * .08,
						children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
							className: `relative flex h-full flex-col rounded-2xl border p-6 ${cardBg}`,
							children: [
								p.featured && /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
									className: "mb-3 inline-flex w-fit rounded-full bg-white/20 px-2.5 py-1 text-xs font-semibold",
									children: "Most popular"
								}),
								p.badge && /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
									className: "mb-3 inline-flex w-fit rounded-full bg-amber-500 px-2.5 py-1 text-xs font-semibold text-white",
									children: p.badge
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h3", {
									className: `text-lg font-bold ${titleColor}`,
									children: p.name
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
									className: "mt-3 flex items-baseline gap-2",
									children: [
										/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
											className: `text-4xl font-bold ${titleColor}`,
											children: p.price
										}),
										p.originalPrice && /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
											className: "text-lg text-slate-400 line-through dark:text-slate-500",
											children: p.originalPrice
										}),
										/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", {
											className: taglineColor,
											children: ["/ ", p.tagline]
										})
									]
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)("ul", {
									className: "mt-6 space-y-2 text-sm",
									children: p.features.map((f) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("li", {
										className: `flex gap-2 ${featureColor}`,
										children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
											"aria-hidden": true,
											children: "✓"
										}), f]
									}, f))
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Link, {
									to: p.to,
									className: `mt-8 block rounded-lg px-4 py-2.5 text-center font-semibold transition ${btnClass}`,
									children: p.cta
								})
							]
						})
					}, p.name);
				})
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Reveal, { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h2", {
				className: "mt-16 text-center text-2xl font-bold text-slate-900 dark:text-white",
				children: "Compare plans at a glance"
			}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
				className: "mt-6 overflow-x-auto rounded-2xl border border-slate-200 bg-white shadow-sm dark:border-slate-800 dark:bg-slate-900",
				children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("table", {
					className: "w-full min-w-[640px] text-left text-sm",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("thead", {
						className: "bg-slate-50 dark:bg-slate-950/50",
						children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("tr", { children: [
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("th", {
								className: "px-4 py-3 font-semibold text-slate-700 dark:text-slate-200",
								children: "Feature"
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("th", {
								className: "px-4 py-3 font-semibold text-slate-700 dark:text-slate-200",
								children: "Guest"
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("th", {
								className: "px-4 py-3 font-semibold text-slate-700 dark:text-slate-200",
								children: "Free"
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("th", {
								className: "px-4 py-3 font-semibold text-blue-700 dark:text-blue-300",
								children: "Premium"
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("th", {
								className: "px-4 py-3 font-semibold text-amber-700 dark:text-amber-400",
								children: "Pro (lifetime)"
							})
						] })
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("tbody", { children: COMPARE_ROWS.map((r) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("tr", {
						className: "border-t border-slate-200 dark:border-slate-800",
						children: [
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("td", {
								className: "px-4 py-3 text-slate-700 dark:text-slate-300",
								children: r.feature
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("td", {
								className: "px-4 py-3 text-slate-600 dark:text-slate-400",
								children: r.guest
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("td", {
								className: "px-4 py-3 text-slate-600 dark:text-slate-400",
								children: r.free
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("td", {
								className: "px-4 py-3 text-blue-700 dark:text-blue-300",
								children: r.premium
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("td", {
								className: "px-4 py-3 text-amber-700 dark:text-amber-400",
								children: r.pro
							})
						]
					}, r.feature)) })]
				})
			})] }),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Reveal, { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h2", {
				className: "mt-16 text-center text-2xl font-bold text-slate-900 dark:text-white",
				children: "Frequently asked questions"
			}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
				className: "mt-6 space-y-3",
				children: FAQS.map((f) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("details", {
					className: "group rounded-xl border border-slate-200 bg-white p-4 open:shadow-sm dark:border-slate-800 dark:bg-slate-900",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("summary", {
						className: "cursor-pointer list-none text-base font-semibold text-slate-900 dark:text-white marker:hidden",
						children: [
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
								className: "mr-2 text-blue-600 group-open:hidden",
								children: "+"
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
								className: "mr-2 text-blue-600 hidden group-open:inline",
								children: "−"
							}),
							f.q
						]
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
						className: "mt-2 text-sm text-slate-600 dark:text-slate-300",
						children: f.a
					})]
				}, f.q))
			})] })
		]
	}) });
}
//#endregion
export { Pricing as component };
