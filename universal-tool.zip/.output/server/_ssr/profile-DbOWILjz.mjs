import { o as __toESM } from "../_runtime.mjs";
import { nt as require_react } from "../_libs/@hookform/resolvers+[...].mjs";
import { g as Link } from "../_libs/@tanstack/react-router+[...].mjs";
import { r as require_jsx_runtime } from "../_libs/react+tanstack__react-query.mjs";
import { r as useAuth } from "./auth-context-DS3dl-5u.mjs";
import { a as deleteAccount, c as updateProfile, i as changePassword, l as uploadAvatar, n as Layout, o as getProfile, s as getUsageStats } from "./Layout-8Jn4q3kq.mjs";
import { t as Swal } from "../_libs/sweetalert2.mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/profile-DbOWILjz.js
var import_react = /* @__PURE__ */ __toESM(require_react());
var import_jsx_runtime = require_jsx_runtime();
function ProfilePage() {
	const { user, role, plan, isAdmin, signOut, refresh } = useAuth();
	const [profile, setProfile] = (0, import_react.useState)(null);
	const [displayName, setDisplayName] = (0, import_react.useState)("");
	const [loading, setLoading] = (0, import_react.useState)(true);
	const [saving, setSaving] = (0, import_react.useState)(false);
	const [uploading, setUploading] = (0, import_react.useState)(false);
	const [usage, setUsage] = (0, import_react.useState)({
		totalToolsUsed: 0,
		todayUsage: 0,
		lastToolUsed: null
	});
	const isSuperAdmin = user?.id === "f0a17059-c9ac-46e1-859c-82bd1487f069";
	(0, import_react.useEffect)(() => {
		loadProfile();
	}, []);
	async function loadProfile() {
		try {
			setLoading(true);
			const [profileData, usageData] = await Promise.all([getProfile(), getUsageStats()]);
			setProfile(profileData);
			setUsage(usageData);
			setDisplayName(profileData.display_name ?? user?.user_metadata?.display_name ?? "");
		} catch (err) {
			Swal.fire({
				icon: "error",
				title: "Unable to load profile",
				text: err.message
			});
		} finally {
			setLoading(false);
		}
	}
	const avatar = (0, import_react.useMemo)(() => {
		if (profile?.avatar_url) return profile.avatar_url;
		return null;
	}, [profile]);
	async function handleSaveProfile() {
		if (!displayName.trim()) {
			Swal.fire({
				icon: "warning",
				title: "Display name required"
			});
			return;
		}
		try {
			setSaving(true);
			await updateProfile(displayName);
			await refresh();
			await loadProfile();
			Swal.fire({
				icon: "success",
				title: "Profile Updated",
				timer: 1500,
				showConfirmButton: false
			});
		} catch (err) {
			Swal.fire({
				icon: "error",
				title: "Update Failed",
				text: err.message
			});
		} finally {
			setSaving(false);
		}
	}
	async function handleAvatar(e) {
		const file = e.target.files?.[0];
		if (!file) return;
		try {
			setUploading(true);
			console.log("1");
			const avatarUrl = await uploadAvatar(file);
			window.dispatchEvent(new Event("avatar-updated"));
			console.log("2");
			setProfile((prev) => prev ? {
				...prev,
				avatar_url: avatarUrl
			} : prev);
			console.log("3");
			await refresh();
			window.dispatchEvent(new Event("avatar-updated"));
			console.log("4");
			Swal.fire({
				icon: "success",
				title: "Avatar Updated",
				timer: 1500,
				showConfirmButton: false
			});
		} catch (err) {
			console.error(err);
			Swal.fire({
				icon: "error",
				title: "Upload Failed",
				text: String(err)
			});
		} finally {
			console.log("5");
			setUploading(false);
		}
	}
	async function handlePassword() {
		const { value: password } = await Swal.fire({
			title: "Change Password",
			html: `
      <div style="text-align:left">

        <div style="position:relative;margin-bottom:12px;">
          <input
            id="new-password"
            type="password"
            class="swal2-input"
            placeholder="New Password"
            style="width:100%;margin:0;padding-right:45px;"
          />
       <button
  id="toggle-new-password"
  type="button"
  style="
    position:absolute;
    right:12px;
    top:50%;
    transform:translateY(-50%);
    border:none;
    background:none;
    cursor:pointer;
    color:#64748b;
  "
  aria-label="Show password"
>
  <svg width="18" height="18" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2">
    <path d="M1 12s4-8 11-8 11 8 11 8-4 8-11 8S1 12 1 12z"/>
    <circle cx="12" cy="12" r="3"/>
  </svg>
</button>
        </div>

        <div style="position:relative;">
          <input
            id="confirm-password"
            type="password"
            class="swal2-input"
            placeholder="Confirm Password"
            style="width:100%;margin:0;padding-right:45px;"
          />
          <button
  id="toggle-confirm-password"
  type="button"
  style="
    position:absolute;
    right:12px;
    top:50%;
    transform:translateY(-50%);
    border:none;
    background:none;
    cursor:pointer;
    color:#64748b;
  "
  aria-label="Show password"
>
  <svg width="18" height="18" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2">
    <path d="M1 12s4-8 11-8 11 8 11 8-4 8-11 8S1 12 1 12z"/>
    <circle cx="12" cy="12" r="3"/>
  </svg>
</button>
        </div>

        <p style="margin-top:12px;font-size:12px;color:#64748b;">
          8–20 characters with uppercase, lowercase, number & special character.
        </p>

      </div>
    `,
			showCancelButton: true,
			confirmButtonText: "Update Password",
			focusConfirm: false,
			didOpen: () => {
				const newPassword = document.getElementById("new-password");
				const confirmPassword = document.getElementById("confirm-password");
				document.getElementById("toggle-new-password")?.addEventListener("click", () => {
					newPassword.type = newPassword.type === "password" ? "text" : "password";
				});
				document.getElementById("toggle-confirm-password")?.addEventListener("click", () => {
					confirmPassword.type = confirmPassword.type === "password" ? "text" : "password";
				});
			},
			preConfirm: () => {
				const password = document.getElementById("new-password").value.trim();
				const confirmPassword = document.getElementById("confirm-password").value.trim();
				if (!/^(?=.*[a-z])(?=.*[A-Z])(?=.*\d)(?=.*[!@#$%^&*(),.?":{}|<>_\-+=/\\[\]]).{8,20}$/.test(password)) {
					Swal.showValidationMessage("Password must be 8–20 characters and include uppercase, lowercase, number and special character.");
					return;
				}
				if (password !== confirmPassword) {
					Swal.showValidationMessage("Passwords do not match.");
					return;
				}
				return password;
			}
		});
		if (!password) return;
		try {
			await changePassword(password);
			await Swal.fire({
				icon: "success",
				title: "Password Changed",
				text: "Your password has been updated successfully."
			});
		} catch (err) {
			await Swal.fire({
				icon: "error",
				title: "Unable to change password",
				text: err.message
			});
		}
	}
	async function handleLogout() {
		if (!(await Swal.fire({
			title: "Logout?",
			text: "You will need to login again.",
			icon: "question",
			showCancelButton: true,
			confirmButtonText: "Logout"
		})).isConfirmed) return;
		await signOut();
	}
	async function handleDeleteAccount() {
		const { value } = await Swal.fire({
			icon: "warning",
			title: "Delete Account",
			html: `
            <p style="margin-bottom:12px">
                This action is permanent and cannot be undone.
            </p>

            <p style="margin-bottom:12px">
                Type <b>DELETE</b> below to continue.
            </p>
        `,
			input: "text",
			inputPlaceholder: "Type DELETE",
			confirmButtonText: "Delete Account",
			confirmButtonColor: "#dc2626",
			showCancelButton: true
		});
		if (value !== "DELETE") return;
		try {
			await deleteAccount();
			await Swal.fire({
				icon: "success",
				title: "Account Deleted",
				text: "Your account has been deleted successfully."
			});
			await signOut();
		} catch (err) {
			Swal.fire({
				icon: "error",
				title: "Delete Failed",
				text: err.message
			});
		}
	}
	if (loading) return /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Layout, { children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("section", {
		className: "mx-auto max-w-5xl px-4 py-10",
		children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
			className: "space-y-4 animate-pulse",
			children: [
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", { className: "h-10 w-64 rounded bg-slate-200 dark:bg-slate-700" }),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", { className: "h-72 rounded-xl bg-slate-200 dark:bg-slate-700" }),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", { className: "h-60 rounded-xl bg-slate-200 dark:bg-slate-700" })
			]
		})
	}) });
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Layout, { children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("section", {
		className: "mx-auto max-w-5xl px-4 py-10",
		children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
			className: "mb-8 flex items-center justify-between",
			children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h1", {
				className: "text-3xl font-bold text-slate-900 dark:text-white",
				style: { fontFamily: "'Space Grotesk', sans-serif" },
				children: "My Profile"
			}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
				className: "mt-2 text-sm text-slate-500",
				children: "Manage your Universal Tools account."
			})] }), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "flex gap-3",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
					onClick: handleLogout,
					className: "rounded-lg border border-red-300 px-4 py-2 text-sm font-medium text-red-600 hover:bg-red-50 dark:border-red-800 dark:hover:bg-red-950",
					children: "Logout"
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Link, {
					to: "/dashboard",
					className: "rounded-lg border border-slate-200 px-4 py-2 text-sm hover:bg-slate-100 dark:border-slate-700 dark:hover:bg-slate-800",
					children: "Back"
				})]
			})]
		}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
			className: "grid gap-6 lg:grid-cols-3",
			children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
				className: "rounded-2xl border border-slate-200 bg-white p-6 shadow-sm dark:border-slate-800 dark:bg-slate-900",
				children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "flex flex-col items-center",
					children: [
						avatar ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("img", {
							src: avatar,
							alt: "Avatar",
							className: "h-28 w-28 rounded-full border-4 border-blue-500 object-cover"
						}) : /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
							className: "flex h-28 w-28 items-center justify-center rounded-full bg-blue-600 text-4xl font-bold text-white",
							children: displayName.charAt(0).toUpperCase()
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("label", {
							className: "mt-4 cursor-pointer rounded-lg bg-blue-600 px-4 py-2 text-sm font-semibold text-white hover:bg-blue-700",
							children: [uploading ? "Uploading..." : "Upload Avatar", /* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
								hidden: true,
								type: "file",
								accept: "image/*",
								onChange: handleAvatar
							})]
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h2", {
							className: "mt-6 text-center text-xl font-bold text-slate-900 dark:text-white",
							children: displayName
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
							className: "mt-2 break-all text-center text-sm text-slate-500",
							children: user?.email
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
							className: "mt-5 flex flex-wrap justify-center gap-2",
							children: [isSuperAdmin ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
								className: "rounded-full bg-blue-400 dark:bg-blue-500 px-2 py-1 text-xs font-bold text-white dark:text-white animate-pulse",
								children: "👑 SUPER ADMIN"
							}) : isAdmin ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
								className: "rounded-full bg-blue-600 px-3 py-1 text-xs font-semibold text-white",
								children: "ADMIN"
							}) : /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
								className: "rounded-full bg-slate-200 px-3 py-1 text-xs font-semibold dark:bg-slate-700",
								children: "USER"
							}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
								className: `rounded-full px-3 py-1 text-xs font-semibold ${plan === "premium" ? "bg-emerald-600 text-white" : "bg-slate-200 dark:bg-slate-700"}`,
								children: plan.toUpperCase()
							})]
						})
					]
				})
			}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "space-y-6 lg:col-span-2",
				children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "rounded-2xl border border-slate-200 bg-white p-6 shadow-sm dark:border-slate-800 dark:bg-slate-900",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h2", {
							className: "text-lg font-semibold text-slate-900 dark:text-white",
							children: "Account Information"
						}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
							className: "mt-6 grid gap-5",
							children: [
								/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("label", {
									className: "text-xs font-semibold uppercase text-slate-500",
									children: ["Name\xA0", /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", { children: `(${displayName.length} / 20)` })]
								}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
									value: displayName,
									placeholder: "Enter your name",
									maxLength: 20,
									onChange: (e) => setDisplayName(e.target.value),
									className: "mt-2 w-full rounded-lg border border-slate-300 bg-white px-4 py-3 outline-none focus:border-blue-500 dark:border-slate-700 dark:bg-slate-800"
								})] }),
								/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("label", {
									className: "text-xs font-semibold uppercase text-slate-500",
									children: "Email"
								}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
									className: "mt-2 rounded-lg border border-slate-200 bg-slate-50 px-4 py-3 break-all dark:border-slate-700 dark:bg-slate-800 cursor-not-allowed",
									children: profile?.email ?? user?.email
								})] }),
								/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
									className: "grid gap-4 md:grid-cols-2",
									children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("label", {
										className: "text-xs font-semibold uppercase text-slate-500",
										children: "Role"
									}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
										className: "mt-2 rounded-lg border border-slate-200 bg-slate-50 px-4 py-3 dark:border-slate-700 dark:bg-slate-800 cursor-not-allowed",
										children: role?.toUpperCase()
									})] }), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("label", {
										className: "text-xs font-semibold uppercase text-slate-500",
										children: "Current Plan"
									}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
										className: "mt-2 rounded-lg border border-slate-200 bg-slate-50 px-4 py-3 dark:border-slate-700 dark:bg-slate-800 cursor-not-allowed",
										children: plan.toUpperCase()
									})] })]
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
									onClick: handleSaveProfile,
									disabled: saving,
									className: "rounded-lg bg-blue-600 px-5 py-3 font-semibold text-white transition hover:bg-blue-700 disabled:opacity-50",
									children: saving ? "Saving..." : "Save Profile"
								})
							]
						})]
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "rounded-2xl border border-slate-200 bg-white p-6 shadow-sm dark:border-slate-800 dark:bg-slate-900",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
							className: "flex items-center justify-between",
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h2", {
								className: "text-lg font-semibold text-slate-900 dark:text-white",
								children: "Subscription"
							}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
								className: "mt-2 text-sm text-slate-500",
								children: "Your current subscription plan."
							})] }), plan !== "premium" && /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Link, {
								to: "/pricing",
								className: "rounded-lg bg-blue-600 px-5 py-2 text-sm font-semibold text-white hover:bg-blue-700",
								children: "Upgrade"
							})]
						}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
							className: "mt-6 grid gap-4 sm:grid-cols-2",
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
								className: "rounded-xl border border-slate-200 p-5 dark:border-slate-700",
								children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
									className: "text-xs uppercase text-slate-500",
									children: "Current Plan"
								}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("h3", {
									className: "mt-2 text-2xl font-bold",
									children: plan === "premium" ? "💎 Premium" : "🆓 Free"
								})]
							}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
								className: "rounded-xl border border-slate-200 p-5 dark:border-slate-700",
								children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
									className: "text-xs uppercase text-slate-500",
									children: "Account Status"
								}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("h3", {
									className: "mt-2 text-2xl font-bold text-emerald-600",
									children: "Active"
								})]
							})]
						})]
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "rounded-2xl border border-slate-200 bg-white p-6 shadow-sm dark:border-slate-800 dark:bg-slate-900",
						children: [
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h2", {
								className: "text-lg font-semibold text-slate-900 dark:text-white",
								children: "Security"
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
								className: "mt-2 text-sm text-slate-500",
								children: "Change your account password securely."
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
								onClick: handlePassword,
								className: "mt-5 rounded-lg border border-slate-300 px-5 py-3 text-sm font-semibold hover:bg-slate-100 dark:border-slate-700 dark:hover:bg-slate-800",
								children: "Change Password"
							})
						]
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "rounded-2xl border border-slate-200 bg-white p-6 shadow-sm dark:border-slate-800 dark:bg-slate-900",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h2", {
							className: "text-lg font-semibold text-slate-900 dark:text-white",
							children: "Usage Information"
						}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
							className: "mt-6 grid gap-4 md:grid-cols-2 xl:grid-cols-4",
							children: [
								/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
									className: "rounded-xl border border-slate-200 p-4 dark:border-slate-700",
									children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
										className: "text-xs uppercase text-slate-500",
										children: "Total Tools Used"
									}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
										className: "mt-2 text-2xl font-bold",
										children: usage.totalToolsUsed
									})]
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
									className: "rounded-xl border border-slate-200 p-4 dark:border-slate-700",
									children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
										className: "text-xs uppercase text-slate-500",
										children: "Today's Usage"
									}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
										className: "mt-2 text-2xl font-bold",
										children: usage.todayUsage
									})]
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
									className: "rounded-xl border border-slate-200 p-4 dark:border-slate-700",
									children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
										className: "text-xs uppercase text-slate-500",
										children: "Last Tool Used"
									}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
										className: "mt-2 break-words text-sm font-semibold",
										children: usage.lastToolUsed ?? "No usage yet"
									})]
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
									className: "rounded-xl border border-slate-200 p-4 dark:border-slate-700",
									children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
										className: "text-xs uppercase text-slate-500",
										children: "Current Plan"
									}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
										className: "mt-2 text-xl font-bold",
										children: plan === "premium" ? "💎 Premium" : "🆓 Free"
									})]
								})
							]
						})]
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "rounded-2xl border border-red-300 bg-red-50 p-6 shadow-sm dark:border-red-900 dark:bg-red-950/20",
						children: [
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h2", {
								className: "text-lg font-bold text-red-600",
								children: "⚠ Danger Zone"
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
								className: "mt-2 text-sm text-slate-600 dark:text-slate-400",
								children: "Permanently delete your account, avatar, profile, subscriptions, usage history and all associated data. This action cannot be undone."
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
								onClick: handleDeleteAccount,
								className: "mt-6 rounded-lg bg-red-600 px-5 py-3 font-semibold text-white hover:bg-red-700",
								children: "Delete Account"
							})
						]
					})
				]
			})]
		})]
	}) });
}
//#endregion
export { ProfilePage as component };
