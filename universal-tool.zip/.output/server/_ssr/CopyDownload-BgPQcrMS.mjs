import { o as __toESM } from "../_runtime.mjs";
import { nt as require_react } from "../_libs/@hookform/resolvers+[...].mjs";
import { r as require_jsx_runtime } from "../_libs/react+tanstack__react-query.mjs";
import { n as toast } from "../_libs/sonner.mjs";
import { t as InlineSpinner } from "./Skeleton-C9Gtenx-.mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/CopyDownload-BgPQcrMS.js
var import_react = /* @__PURE__ */ __toESM(require_react());
var import_jsx_runtime = require_jsx_runtime();
var btnBase = "inline-flex items-center gap-1.5 rounded-lg border border-slate-200 bg-white px-3 py-1.5 text-sm font-medium text-slate-700 transition hover:border-blue-500 hover:text-blue-700 dark:border-slate-700 dark:bg-slate-900 dark:text-slate-200 dark:hover:border-blue-400 disabled:cursor-not-allowed disabled:opacity-50";
function useAnnouncer() {
	const [msg, setMsg] = (0, import_react.useState)("");
	const t = (0, import_react.useRef)(null);
	const announce = (m) => {
		setMsg("");
		if (t.current) window.clearTimeout(t.current);
		t.current = window.setTimeout(() => setMsg(m), 30);
	};
	return {
		announce,
		node: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
			role: "status",
			"aria-live": "polite",
			"aria-atomic": "true",
			className: "sr-only",
			children: msg
		})
	};
}
function CopyButton({ getText, label = "Copy", className = "", busy = false }) {
	const [working, setWorking] = (0, import_react.useState)(false);
	const btnRef = (0, import_react.useRef)(null);
	const { announce, node } = useAnnouncer();
	const disabled = busy || working;
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(import_jsx_runtime.Fragment, { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("button", {
		ref: btnRef,
		type: "button",
		disabled,
		"aria-busy": disabled,
		onClick: async () => {
			const t = getText();
			if (!t) {
				announce("Copy failed: nothing to copy");
				toast.error("Nothing to copy");
				return;
			}
			setWorking(true);
			announce(`Copying ${t.length} characters to clipboard…`);
			try {
				await navigator.clipboard.writeText(t);
				announce(`Copied ${t.length} characters to clipboard`);
				toast.success("Copied to clipboard");
			} catch (err) {
				const reason = err?.message || "clipboard unavailable";
				announce(`Copy failed: ${reason}`);
				toast.error(`Copy failed: ${reason}`);
			} finally {
				setWorking(false);
				requestAnimationFrame(() => btnRef.current?.focus());
			}
		},
		className: `${btnBase} ${className}`,
		"aria-label": label,
		children: [disabled ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)(InlineSpinner, {}) : /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("svg", {
			viewBox: "0 0 24 24",
			className: "h-4 w-4",
			fill: "none",
			stroke: "currentColor",
			strokeWidth: "2",
			"aria-hidden": "true",
			children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("rect", {
				x: "9",
				y: "9",
				width: "13",
				height: "13",
				rx: "2"
			}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("path", { d: "M5 15H4a2 2 0 0 1-2-2V4a2 2 0 0 1 2-2h9a2 2 0 0 1 2 2v1" })]
		}), disabled && working ? "Copying…" : label]
	}), node] });
}
function DownloadButton({ getText, filename, type = "text/plain", label = "Download", className = "", busy = false }) {
	const [working, setWorking] = (0, import_react.useState)(false);
	const btnRef = (0, import_react.useRef)(null);
	const { announce, node } = useAnnouncer();
	const disabled = busy || working;
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(import_jsx_runtime.Fragment, { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("button", {
		ref: btnRef,
		type: "button",
		disabled,
		"aria-busy": disabled,
		onClick: () => {
			const t = getText();
			if (!t) {
				announce("Download failed: nothing to download");
				toast.error("Nothing to download");
				return;
			}
			setWorking(true);
			announce(`Preparing download: ${filename}…`);
			try {
				const blob = new Blob([t], { type });
				const url = URL.createObjectURL(blob);
				const a = document.createElement("a");
				a.href = url;
				a.download = filename;
				announce(`Download in progress: ${filename}`);
				a.click();
				setTimeout(() => URL.revokeObjectURL(url), 1e3);
				announce(`Download completed: ${filename} (${blob.size} bytes)`);
				toast.success(`Downloaded ${filename}`);
			} catch (err) {
				const reason = err?.message || "browser blocked the download";
				announce(`Download failed: ${reason}`);
				toast.error(`Download failed: ${reason}`);
			} finally {
				setTimeout(() => {
					setWorking(false);
					requestAnimationFrame(() => btnRef.current?.focus());
				}, 200);
			}
		},
		className: `${btnBase} ${className}`,
		"aria-label": label,
		children: [disabled ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)(InlineSpinner, {}) : /* @__PURE__ */ (0, import_jsx_runtime.jsx)("svg", {
			viewBox: "0 0 24 24",
			className: "h-4 w-4",
			fill: "none",
			stroke: "currentColor",
			strokeWidth: "2",
			"aria-hidden": "true",
			children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("path", { d: "M21 15v4a2 2 0 0 1-2 2H5a2 2 0 0 1-2-2v-4M7 10l5 5 5-5M12 15V3" })
		}), disabled && working ? "Downloading…" : label]
	}), node] });
}
//#endregion
export { DownloadButton as n, CopyButton as t };
