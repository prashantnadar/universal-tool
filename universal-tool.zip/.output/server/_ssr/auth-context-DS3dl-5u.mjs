import { o as __toESM } from "../_runtime.mjs";
import { nt as require_react } from "../_libs/@hookform/resolvers+[...].mjs";
import { t as supabase } from "./client-CxWkeBjE.mjs";
import { b as useRouter } from "../_libs/@tanstack/react-router+[...].mjs";
import { n as useQueryClient, r as require_jsx_runtime } from "../_libs/react+tanstack__react-query.mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/auth-context-DS3dl-5u.js
var import_react = /* @__PURE__ */ __toESM(require_react());
var import_jsx_runtime = require_jsx_runtime();
var ThemeCtx = (0, import_react.createContext)({
	theme: "light",
	toggle: () => {}
});
function ThemeProvider({ children }) {
	const [theme, setTheme] = (0, import_react.useState)("light");
	(0, import_react.useEffect)(() => {
		const stored = typeof window !== "undefined" && localStorage.getItem("ut-theme");
		setTheme(stored === "dark" ? "dark" : "light");
	}, []);
	(0, import_react.useEffect)(() => {
		const root = document.documentElement;
		if (theme === "dark") root.classList.add("dark");
		else root.classList.remove("dark");
		localStorage.setItem("ut-theme", theme);
	}, [theme]);
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)(ThemeCtx.Provider, {
		value: {
			theme,
			toggle: () => setTheme((t) => t === "dark" ? "light" : "dark")
		},
		children
	});
}
var useTheme = () => (0, import_react.useContext)(ThemeCtx);
var AuthContext = (0, import_react.createContext)(void 0);
async function loadRoleAndPlan(userId) {
	const [{ data: roleRow }, { data: subRow }] = await Promise.all([supabase.from("user_roles").select("role").eq("user_id", userId).order("role", { ascending: true }).limit(1).maybeSingle(), supabase.from("subscriptions").select("plan,status,current_period_end").eq("user_id", userId).maybeSingle()]);
	const role = roleRow?.role ?? "user";
	let plan = "free";
	if (subRow?.plan === "premium" && subRow?.status === "active") {
		if (!subRow.current_period_end || new Date(subRow.current_period_end) > /* @__PURE__ */ new Date()) plan = "premium";
	}
	return {
		role,
		plan
	};
}
function AuthProvider({ children }) {
	const [session, setSession] = (0, import_react.useState)(null);
	const [user, setUser] = (0, import_react.useState)(null);
	const [role, setRole] = (0, import_react.useState)(null);
	const [plan, setPlan] = (0, import_react.useState)("free");
	const [loading, setLoading] = (0, import_react.useState)(true);
	const router = useRouter();
	const queryClient = useQueryClient();
	const applyUser = async (nextUser) => {
		setUser(nextUser);
		if (!nextUser) {
			setRole(null);
			setPlan("free");
			return;
		}
		try {
			const { role: r, plan: p } = await loadRoleAndPlan(nextUser.id);
			setRole(r);
			setPlan(p);
		} catch {
			setRole("user");
			setPlan("free");
		}
	};
	(0, import_react.useEffect)(() => {
		let mounted = true;
		supabase.auth.getSession().then(async ({ data }) => {
			if (!mounted) return;
			setSession(data.session);
			await applyUser(data.session?.user ?? null);
			setLoading(false);
		});
		const { data: sub } = supabase.auth.onAuthStateChange((event, nextSession) => {
			if (event !== "SIGNED_IN" && event !== "SIGNED_OUT" && event !== "USER_UPDATED" && event !== "TOKEN_REFRESHED") return;
			setSession(nextSession);
			(async () => {
				await applyUser(nextSession?.user ?? null);
				router.invalidate();
				if (event !== "SIGNED_OUT") queryClient.invalidateQueries();
			})();
		});
		return () => {
			mounted = false;
			sub.subscription.unsubscribe();
		};
	}, []);
	const signOut = async () => {
		await queryClient.cancelQueries();
		queryClient.clear();
		await supabase.auth.signOut();
		router.navigate({
			to: "/auth",
			replace: true
		});
	};
	const refresh = async () => {
		const { data: { user }, error } = await supabase.auth.getUser();
		if (error) throw error;
		const { data: { session } } = await supabase.auth.getSession();
		setSession(session);
		await applyUser(user ?? null);
	};
	const value = (0, import_react.useMemo)(() => ({
		loading,
		session,
		user,
		role,
		plan,
		isAuthenticated: !!user,
		isAdmin: role === "admin",
		isPremium: plan === "premium" || role === "admin",
		signOut,
		refresh
	}), [
		loading,
		session,
		user,
		role,
		plan
	]);
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)(AuthContext.Provider, {
		value,
		children
	});
}
function useAuth() {
	const ctx = (0, import_react.useContext)(AuthContext);
	if (!ctx) throw new Error("useAuth must be used within AuthProvider");
	return ctx;
}
//#endregion
export { useTheme as i, ThemeProvider as n, useAuth as r, AuthProvider as t };
