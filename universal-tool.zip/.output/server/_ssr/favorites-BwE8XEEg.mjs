import { o as __toESM } from "../_runtime.mjs";
import { nt as require_react } from "../_libs/@hookform/resolvers+[...].mjs";
import { g as Link } from "../_libs/@tanstack/react-router+[...].mjs";
import { r as require_jsx_runtime } from "../_libs/react+tanstack__react-query.mjs";
import { n as Layout, r as TOOLS } from "./Layout-8Jn4q3kq.mjs";
import { t as Reveal } from "./Reveal-CydLpVW7.mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/favorites-BwE8XEEg.js
var import_react = /* @__PURE__ */ __toESM(require_react());
var import_jsx_runtime = require_jsx_runtime();
var KEY = "ut-favorites";
var listeners = /* @__PURE__ */ new Set();
function getFavorites() {
	if (typeof window === "undefined") return [];
	try {
		return JSON.parse(localStorage.getItem(KEY) || "[]");
	} catch {
		return [];
	}
}
function toggleFavorite(id) {
	const cur = getFavorites();
	const next = cur.includes(id) ? cur.filter((x) => x !== id) : [...cur, id];
	localStorage.setItem(KEY, JSON.stringify(next));
	listeners.forEach((l) => l());
	return next.includes(id);
}
function subscribeFavorites(cb) {
	listeners.add(cb);
	return () => listeners.delete(cb);
}
function Favorites() {
	const [ids, setIds] = (0, import_react.useState)([]);
	(0, import_react.useEffect)(() => {
		setIds(getFavorites());
		return subscribeFavorites(() => setIds(getFavorites()));
	}, []);
	const items = ids.map((id) => TOOLS.find((t) => t.id === id)).filter(Boolean);
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Layout, { children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("section", {
		className: "mx-auto max-w-5xl px-4 py-12 sm:px-6",
		children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Reveal, { children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("header", {
			className: "mb-8",
			children: [
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
					className: "text-sm font-semibold uppercase tracking-wider text-amber-600",
					children: "Favorites"
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h1", {
					className: "mt-1 text-3xl font-bold text-slate-900 sm:text-4xl dark:text-white",
					style: { fontFamily: "'Space Grotesk', sans-serif" },
					children: "Your saved tools"
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
					className: "mt-2 text-slate-600 dark:text-slate-400",
					children: "Tap the ⭐ Save button on any tool to add it here."
				})
			]
		}) }), items.length === 0 ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Reveal, { children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
			className: "rounded-2xl border border-dashed border-slate-300 bg-slate-50 p-12 text-center dark:border-slate-700 dark:bg-slate-900",
			children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
				className: "text-slate-600 dark:text-slate-400",
				children: "You haven't saved any tools yet."
			}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Link, {
				to: "/tools/text",
				className: "mt-4 inline-flex items-center rounded-lg bg-blue-600 px-4 py-2 text-sm font-semibold text-white hover:bg-blue-700",
				children: "Browse tools"
			})]
		}) }) : /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
			className: "grid gap-4 sm:grid-cols-2 lg:grid-cols-3",
			children: items.map((t, i) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Reveal, {
				delay: i * .04,
				children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "group h-full rounded-2xl border border-slate-200 bg-white p-5 transition hover:border-blue-300 hover:shadow-lg dark:border-slate-800 dark:bg-slate-900",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "flex items-start justify-between gap-2",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
							className: "inline-flex items-center rounded-md bg-blue-100 px-2 py-0.5 text-xs font-semibold uppercase text-blue-700 dark:bg-blue-950 dark:text-blue-300",
							children: t.category
						}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
							type: "button",
							onClick: () => toggleFavorite(t.id),
							"aria-label": `Remove ${t.name} from favorites`,
							className: "text-slate-400 hover:text-amber-500",
							title: "Remove",
							children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("svg", {
								viewBox: "0 0 24 24",
								className: "h-4 w-4",
								fill: "currentColor",
								"aria-hidden": "true",
								children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("path", { d: "m12 17.27 6.18 3.73-1.64-7.03L22 9.24l-7.19-.61L12 2 9.19 8.63 2 9.24l5.46 4.73L5.82 21z" })
							})
						})]
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Link, {
						to: t.route,
						className: "mt-3 block",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h2", {
							className: "font-semibold text-slate-900 group-hover:text-blue-700 dark:text-white dark:group-hover:text-blue-300",
							children: t.name
						}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
							className: "mt-1 text-sm text-slate-600 dark:text-slate-400",
							children: t.description
						})]
					})]
				})
			}, t.id))
		})]
	}) });
}
//#endregion
export { Favorites as component };
