import { o as __toESM } from "../_runtime.mjs";
import { nt as require_react } from "../_libs/@hookform/resolvers+[...].mjs";
import { r as require_jsx_runtime } from "../_libs/react+tanstack__react-query.mjs";
import { n as Layout, r as TOOLS } from "./Layout-8Jn4q3kq.mjs";
import { t as Reveal } from "./Reveal-CydLpVW7.mjs";
import { a as subscribeUsage, o as trackUse, t as getCounts } from "./usage-tracking-C1qv9W3k.mjs";
import { r as SkeletonLines, t as InlineSpinner } from "./Skeleton-C9Gtenx-.mjs";
import { t as useMeteredCategory } from "./use-metered-category-DtDCo9eW.mjs";
import { i as degrees, n as StandardFonts, r as rgb, t as PDFDocument } from "../_libs/pdf-lib+tslib.mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/tools.pdf-DGN2G7cP.js
var import_react = /* @__PURE__ */ __toESM(require_react());
var import_jsx_runtime = require_jsx_runtime();
var inputCls$1 = "block w-full text-sm text-slate-700 file:mr-3 file:rounded-lg file:border-0 file:bg-blue-600 file:px-3 file:py-2 file:text-sm file:font-semibold file:text-white file:hover:bg-blue-700 dark:text-slate-200";
var btnCls$1 = "mt-3 inline-flex items-center gap-2 rounded-lg bg-blue-600 px-4 py-2 text-sm font-semibold text-white transition hover:bg-blue-700 disabled:opacity-60";
var fieldCls = "w-full rounded-lg border border-slate-200 bg-white px-3 py-2 text-sm dark:border-slate-700 dark:bg-slate-950 dark:text-white";
function ToolShell({ id, title, desc, busy, onCancel, canClear, onClear, className = "", children }) {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Reveal, {
		as: "section",
		className,
		children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("section", {
			id,
			"aria-labelledby": `${id}-title`,
			className: "scroll-mt-32 rounded-2xl border border-slate-200 bg-white p-6 dark:border-slate-800 dark:bg-slate-900",
			children: [
				/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "flex items-start justify-between gap-3",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h3", {
						id: `${id}-title`,
						className: "text-lg font-bold text-slate-900 dark:text-white",
						style: { fontFamily: "'Space Grotesk', sans-serif" },
						children: title
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
						className: "mt-1 text-sm text-slate-600 dark:text-slate-400",
						children: desc
					})] }), canClear && /* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
						type: "button",
						onClick: onClear,
						"aria-label": `Clear ${title}`,
						className: "inline-flex shrink-0 items-center gap-1 rounded-lg border border-slate-200 bg-white px-2.5 py-1 text-xs font-semibold text-slate-600 transition hover:border-rose-300 hover:text-rose-600 dark:border-slate-700 dark:bg-slate-950 dark:text-slate-300",
						children: "Clear"
					})]
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
					className: "mt-4",
					"aria-busy": busy || void 0,
					children
				}),
				busy && /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "mt-4 rounded-lg border border-dashed border-slate-200 bg-slate-50 p-4 dark:border-slate-700 dark:bg-slate-950/40",
					role: "status",
					"aria-live": "polite",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "flex items-center justify-between gap-3",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
							className: "flex items-center gap-2 text-xs font-medium text-slate-500 dark:text-slate-400",
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(InlineSpinner, {}), " Processing…"]
						}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
							type: "button",
							onClick: onCancel,
							"aria-label": `Cancel ${title}`,
							className: "rounded-lg border border-rose-300 bg-white px-3 py-1 text-xs font-semibold text-rose-700 transition hover:bg-rose-50 dark:border-rose-800 dark:bg-slate-900 dark:text-rose-300 dark:hover:bg-rose-950/40",
							children: "Cancel"
						})]
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
						className: "mt-3",
						children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(SkeletonLines, { count: 3 })
					})]
				})
			]
		})
	});
}
function saveBlob(bytes, name, type = "application/pdf") {
	const blob = new Blob([bytes], { type });
	const url = URL.createObjectURL(blob);
	const a = document.createElement("a");
	a.href = url;
	a.download = name;
	a.click();
	setTimeout(() => URL.revokeObjectURL(url), 1e3);
}
function HtmlToPdfCard() {
	const [html, setHtml] = (0, import_react.useState)("<h1 style=\"font-family:Inter,system-ui;color:#1e293b\">Hello 👋</h1>\n<p>Type any HTML here and turn it into a PDF.</p>");
	const [busy, setBusy] = (0, import_react.useState)(false);
	const tokenRef = (0, import_react.useRef)(0);
	const cancel = () => {
		tokenRef.current++;
		setBusy(false);
	};
	const clear = () => setHtml("");
	const convert = async () => {
		trackUse("pdf-html-to-pdf");
		if (!html.trim()) return;
		const tk = ++tokenRef.current;
		setBusy(true);
		try {
			const [{ default: html2canvas }, { jsPDF }] = await Promise.all([import("../_libs/html2canvas.mjs").then((n) => n.t), import("../_libs/jspdf.mjs").then((n) => n.t)]);
			if (tk !== tokenRef.current) return;
			const A4_WIDTH_PX = 794;
			const host = document.createElement("div");
			host.style.cssText = `position:fixed;left:-99999px;top:0;width:${A4_WIDTH_PX}px;padding:40px;background:#ffffff;color:#0f172a;font-family:system-ui,Segoe UI,Roboto,sans-serif;line-height:1.5;`;
			host.innerHTML = html;
			document.body.appendChild(host);
			try {
				const canvas = await html2canvas(host, {
					scale: 2,
					backgroundColor: "#ffffff",
					useCORS: true
				});
				if (tk !== tokenRef.current) return;
				const pdf = new jsPDF({
					unit: "pt",
					format: "a4",
					compress: true
				});
				const pageW = pdf.internal.pageSize.getWidth();
				const pageH = pdf.internal.pageSize.getHeight();
				const imgW = pageW;
				const imgH = canvas.height * imgW / canvas.width;
				if (imgH <= pageH) pdf.addImage(canvas.toDataURL("image/jpeg", .92), "JPEG", 0, 0, imgW, imgH);
				else {
					const pxPerPt = canvas.width / pageW;
					const sliceHeightPx = Math.floor(pageH * pxPerPt);
					let y = 0;
					let first = true;
					while (y < canvas.height) {
						const h = Math.min(sliceHeightPx, canvas.height - y);
						const slice = document.createElement("canvas");
						slice.width = canvas.width;
						slice.height = h;
						const ctx = slice.getContext("2d");
						ctx.fillStyle = "#ffffff";
						ctx.fillRect(0, 0, slice.width, slice.height);
						ctx.drawImage(canvas, 0, y, canvas.width, h, 0, 0, canvas.width, h);
						if (!first) pdf.addPage();
						first = false;
						const outH = h / canvas.width * pageW;
						pdf.addImage(slice.toDataURL("image/jpeg", .9), "JPEG", 0, 0, pageW, outH);
						y += h;
					}
				}
				pdf.save("html.pdf");
			} finally {
				host.remove();
			}
		} catch (e) {
			alert("HTML to PDF failed: " + e.message);
		} finally {
			if (tk === tokenRef.current) setBusy(false);
		}
	};
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(ToolShell, {
		id: "html-to-pdf",
		title: "HTML to PDF",
		desc: "Paste HTML (with inline CSS) and download it as a PDF — rendered right in your browser.",
		busy,
		onCancel: cancel,
		canClear: html.length > 0,
		onClear: clear,
		children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("label", {
			className: "block",
			children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
				className: "sr-only",
				children: "HTML source"
			}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("textarea", {
				value: html,
				onChange: (e) => setHtml(e.target.value),
				rows: 8,
				spellCheck: false,
				"aria-label": "HTML source",
				className: `${fieldCls} font-mono text-xs`,
				placeholder: "<h1>Hello</h1>"
			})]
		}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("button", {
			type: "button",
			onClick: convert,
			disabled: busy || !html.trim(),
			className: btnCls$1,
			children: [
				busy && /* @__PURE__ */ (0, import_jsx_runtime.jsx)(InlineSpinner, {}),
				" ",
				busy ? "Rendering…" : "Convert & download"
			]
		})]
	});
}
function SignPdfCard() {
	const [file, setFile] = (0, import_react.useState)(null);
	const [pageNum, setPageNum] = (0, import_react.useState)(1);
	const [totalPages, setTotalPages] = (0, import_react.useState)(0);
	const [sigWidth, setSigWidth] = (0, import_react.useState)(180);
	const [busy, setBusy] = (0, import_react.useState)(false);
	const [strokes, setStrokes] = (0, import_react.useState)([]);
	const [redoStack, setRedoStack] = (0, import_react.useState)([]);
	const drawing = (0, import_react.useRef)(false);
	const currentStroke = (0, import_react.useRef)([]);
	const canvasRef = (0, import_react.useRef)(null);
	const CW = 600;
	const CH = 180;
	const previewCanvasRef = (0, import_react.useRef)(null);
	const [pagePts, setPagePts] = (0, import_react.useState)(null);
	const [previewSize, setPreviewSize] = (0, import_react.useState)(null);
	const [nx, setNx] = (0, import_react.useState)(.7);
	const [ny, setNy] = (0, import_react.useState)(.85);
	const empty = strokes.length === 0;
	const redrawStrokes = (list) => {
		const c = canvasRef.current;
		if (!c) return;
		const ctx = c.getContext("2d");
		ctx.fillStyle = "#ffffff";
		ctx.fillRect(0, 0, c.width, c.height);
		ctx.strokeStyle = "#0f172a";
		ctx.lineWidth = 2.5;
		ctx.lineCap = "round";
		ctx.lineJoin = "round";
		for (const stroke of list) {
			if (stroke.length < 1) continue;
			ctx.beginPath();
			ctx.moveTo(stroke[0].x, stroke[0].y);
			for (let i = 1; i < stroke.length; i++) ctx.lineTo(stroke[i].x, stroke[i].y);
			if (stroke.length === 1) ctx.lineTo(stroke[0].x + .1, stroke[0].y + .1);
			ctx.stroke();
		}
	};
	(0, import_react.useEffect)(() => {
		redrawStrokes(strokes);
	}, [strokes]);
	const point = (e) => {
		const c = canvasRef.current;
		const r = c.getBoundingClientRect();
		return {
			x: (e.clientX - r.left) * c.width / r.width,
			y: (e.clientY - r.top) * c.height / r.height
		};
	};
	const onDown = (e) => {
		e.preventDefault();
		e.target.setPointerCapture(e.pointerId);
		drawing.current = true;
		currentStroke.current = [point(e)];
	};
	const onMove = (e) => {
		if (!drawing.current) return;
		const p = point(e);
		currentStroke.current.push(p);
		const ctx = canvasRef.current.getContext("2d");
		const arr = currentStroke.current;
		if (arr.length >= 2) {
			const a = arr[arr.length - 2], b = arr[arr.length - 1];
			ctx.strokeStyle = "#0f172a";
			ctx.lineWidth = 2.5;
			ctx.lineCap = "round";
			ctx.lineJoin = "round";
			ctx.beginPath();
			ctx.moveTo(a.x, a.y);
			ctx.lineTo(b.x, b.y);
			ctx.stroke();
		}
	};
	const onUp = () => {
		if (!drawing.current) return;
		drawing.current = false;
		const stroke = currentStroke.current;
		currentStroke.current = [];
		if (stroke.length > 0) {
			setStrokes((prev) => [...prev, stroke]);
			setRedoStack([]);
		}
	};
	const undo = () => {
		if (strokes.length === 0) return;
		const next = strokes.slice(0, -1);
		const popped = strokes[strokes.length - 1];
		setStrokes(next);
		setRedoStack((r) => [...r, popped]);
	};
	const redoAction = () => {
		if (redoStack.length === 0) return;
		const last = redoStack[redoStack.length - 1];
		setRedoStack(redoStack.slice(0, -1));
		setStrokes((s) => [...s, last]);
	};
	const clearPad = () => {
		setStrokes([]);
		setRedoStack([]);
	};
	(0, import_react.useEffect)(() => {
		const onKey = (e) => {
			const target = e.target;
			if (target && (target.tagName === "INPUT" || target.tagName === "TEXTAREA" || target.tagName === "SELECT")) return;
			if ((e.ctrlKey || e.metaKey) && e.key.toLowerCase() === "z") {
				e.preventDefault();
				if (e.shiftKey) redoAction();
				else undo();
			} else if ((e.ctrlKey || e.metaKey) && e.key.toLowerCase() === "y") {
				e.preventDefault();
				redoAction();
			}
		};
		window.addEventListener("keydown", onKey);
		return () => window.removeEventListener("keydown", onKey);
	}, [strokes, redoStack]);
	(0, import_react.useEffect)(() => {
		if (!file) {
			setTotalPages(0);
			setPagePts(null);
			return;
		}
		(async () => {
			try {
				const buf = await file.arrayBuffer();
				const doc = await PDFDocument.load(buf, { ignoreEncryption: true });
				setTotalPages(doc.getPageCount());
				setPageNum(1);
			} catch {
				setTotalPages(0);
			}
		})();
	}, [file]);
	(0, import_react.useEffect)(() => {
		if (!file || totalPages === 0) return;
		let cancelled = false;
		(async () => {
			try {
				const pdfjs = await import("../_libs/pdfjs-dist.mjs").then((n) => n.t);
				const worker = await import("./pdf.worker.min-Be_rUMwQ.mjs");
				pdfjs.GlobalWorkerOptions.workerSrc = worker.default;
				const buf = await file.arrayBuffer();
				const pdf = await pdfjs.getDocument({ data: buf }).promise;
				if (cancelled) return;
				const page = await pdf.getPage(Math.min(pageNum, pdf.numPages));
				const vp0 = page.getViewport({ scale: 1 });
				const scale = Math.min(640 / vp0.width, 2);
				const vp = page.getViewport({ scale });
				const c = previewCanvasRef.current;
				if (!c) return;
				c.width = vp.width;
				c.height = vp.height;
				setPagePts({
					w: vp0.width,
					h: vp0.height
				});
				setPreviewSize({
					w: vp.width,
					h: vp.height
				});
				const ctx = c.getContext("2d");
				ctx.fillStyle = "#ffffff";
				ctx.fillRect(0, 0, c.width, c.height);
				await page.render({
					canvasContext: ctx,
					viewport: vp,
					canvas: c
				}).promise;
				if (cancelled) return;
			} catch {}
		})();
		return () => {
			cancelled = true;
		};
	}, [
		file,
		pageNum,
		totalPages
	]);
	const [sigThumb, setSigThumb] = (0, import_react.useState)("");
	(0, import_react.useEffect)(() => {
		if (empty) {
			setSigThumb("");
			return;
		}
		const c = canvasRef.current;
		if (!c) return;
		setSigThumb(c.toDataURL("image/png"));
	}, [strokes, empty]);
	const dragContainerRef = (0, import_react.useRef)(null);
	const dragging = (0, import_react.useRef)(false);
	const dragOffset = (0, import_react.useRef)({
		dx: 0,
		dy: 0
	});
	const computeOverlaySize = () => {
		if (!pagePts || !previewSize) return {
			w: 0,
			h: 0
		};
		const renderedWidth = dragContainerRef.current?.getBoundingClientRect().width || previewSize.w;
		const w = sigWidth / pagePts.w * renderedWidth;
		return {
			w,
			h: w * (CH / CW)
		};
	};
	const updateFromClient = (clientX, clientY) => {
		const container = dragContainerRef.current;
		if (!container || !previewSize) return;
		const rect = container.getBoundingClientRect();
		const { w: oW, h: oH } = computeOverlaySize();
		const rawX = clientX - rect.left - dragOffset.current.dx;
		const rawY = clientY - rect.top - dragOffset.current.dy;
		const clampedX = Math.max(0, Math.min(rect.width - oW, rawX));
		const clampedY = Math.max(0, Math.min(rect.height - oH, rawY));
		setNx(clampedX / rect.width);
		setNy(clampedY / rect.height);
	};
	const onOverlayDown = (e) => {
		if (!previewSize) return;
		e.preventDefault();
		e.stopPropagation();
		e.currentTarget.setPointerCapture(e.pointerId);
		dragging.current = true;
		const rect = e.currentTarget.getBoundingClientRect();
		dragOffset.current = {
			dx: e.clientX - rect.left,
			dy: e.clientY - rect.top
		};
	};
	const onOverlayMove = (e) => {
		if (!dragging.current) return;
		e.preventDefault();
		updateFromClient(e.clientX, e.clientY);
	};
	const onOverlayUp = (e) => {
		if (!dragging.current) return;
		dragging.current = false;
		try {
			e.currentTarget.releasePointerCapture(e.pointerId);
		} catch {}
	};
	const onPreviewClick = (e) => {
		if (!previewSize || empty) return;
		const container = dragContainerRef.current;
		if (!container) return;
		container.getBoundingClientRect();
		const { w: oW, h: oH } = computeOverlaySize();
		dragOffset.current = {
			dx: oW / 2,
			dy: oH / 2
		};
		updateFromClient(e.clientX, e.clientY);
	};
	const onOverlayKey = (e) => {
		if (!previewSize) return;
		const step = e.shiftKey ? .05 : .01;
		let dx = 0, dy = 0;
		if (e.key === "ArrowLeft") dx = -step;
		else if (e.key === "ArrowRight") dx = step;
		else if (e.key === "ArrowUp") dy = -step;
		else if (e.key === "ArrowDown") dy = step;
		else return;
		e.preventDefault();
		setNx((v) => Math.max(0, Math.min(1, v + dx)));
		setNy((v) => Math.max(0, Math.min(1, v + dy)));
	};
	const clearAll = () => {
		setFile(null);
		setTotalPages(0);
		setPagePts(null);
		setPreviewSize(null);
		clearPad();
		const el = document.getElementById("sign-pdf-in");
		if (el) el.value = "";
	};
	const cancelRun = () => setBusy(false);
	const apply = async () => {
		trackUse("pdf-sign");
		if (!file) return alert("Choose a PDF first");
		if (empty) return alert("Please draw your signature");
		setBusy(true);
		try {
			const src = canvasRef.current;
			const data = src.getContext("2d").getImageData(0, 0, src.width, src.height);
			const out = document.createElement("canvas");
			out.width = src.width;
			out.height = src.height;
			const octx = out.getContext("2d");
			octx.putImageData(data, 0, 0);
			const od = octx.getImageData(0, 0, out.width, out.height);
			for (let i = 0; i < od.data.length; i += 4) {
				const r = od.data[i], g = od.data[i + 1], b = od.data[i + 2];
				if (r > 240 && g > 240 && b > 240) od.data[i + 3] = 0;
			}
			octx.putImageData(od, 0, 0);
			const pngUrl = out.toDataURL("image/png");
			const pngBytes = Uint8Array.from(atob(pngUrl.split(",")[1]), (c) => c.charCodeAt(0));
			const doc = await PDFDocument.load(await file.arrayBuffer(), { ignoreEncryption: true });
			const png = await doc.embedPng(pngBytes);
			const pageIdx = Math.min(Math.max(1, pageNum), doc.getPageCount()) - 1;
			const page = doc.getPage(pageIdx);
			const { width, height } = page.getSize();
			const drawW = Math.min(sigWidth, width - 20);
			const drawH = CH / CW * drawW;
			const x = Math.max(0, Math.min(width - drawW, nx * width));
			const yTop = ny * height;
			const y = Math.max(0, Math.min(height - drawH, height - yTop - drawH));
			page.drawImage(png, {
				x,
				y,
				width: drawW,
				height: drawH
			});
			saveBlob(await doc.save(), "signed.pdf");
		} catch (e) {
			alert("Sign failed: " + e.message);
		} finally {
			setBusy(false);
		}
	};
	const renderedPreviewW = dragContainerRef.current?.getBoundingClientRect().width || previewSize?.w || 0;
	const renderedPreviewH = dragContainerRef.current?.getBoundingClientRect().height || previewSize?.h || 0;
	const overlayW = pagePts && previewSize ? sigWidth / pagePts.w * renderedPreviewW : 0;
	const overlayH = overlayW * (CH / CW);
	const overlayLeft = renderedPreviewW ? Math.min(nx * renderedPreviewW, Math.max(0, renderedPreviewW - overlayW)) : 0;
	const overlayTop = renderedPreviewH ? Math.min(ny * renderedPreviewH, Math.max(0, renderedPreviewH - overlayH)) : 0;
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(ToolShell, {
		id: "sign",
		title: "Sign PDF",
		desc: "Draw your signature, then drag it onto any page — everything happens in your browser.",
		busy,
		onCancel: cancelRun,
		canClear: !!file || !empty,
		onClear: clearAll,
		className: "lg:col-span-2",
		children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
			id: "sign-pdf-in",
			type: "file",
			accept: "application/pdf",
			onChange: (e) => setFile(e.target.files?.[0] ?? null),
			"aria-label": "PDF to sign",
			className: inputCls$1
		}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
			className: "mt-4 grid gap-5 xl:grid-cols-[minmax(280px,420px)_minmax(0,1fr)]",
			children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "space-y-4 rounded-xl border border-slate-200 bg-slate-50 p-4 dark:border-slate-700 dark:bg-slate-950/40",
				children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
							className: "mb-2 flex flex-wrap items-center justify-between gap-2",
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
								id: "sign-pad-label",
								className: "text-xs font-semibold text-slate-700 dark:text-slate-300",
								children: "Draw your signature"
							}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
								role: "toolbar",
								"aria-label": "Signature editing actions",
								"aria-controls": "sign-pad-canvas",
								className: "flex items-center gap-2",
								children: [
									/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("button", {
										type: "button",
										onClick: undo,
										disabled: strokes.length === 0,
										className: "rounded-md border border-slate-200 bg-white px-2 py-1 text-xs font-semibold text-slate-700 hover:border-blue-400 hover:text-blue-700 focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-blue-500 disabled:cursor-not-allowed disabled:opacity-40 dark:border-slate-700 dark:bg-slate-950 dark:text-slate-200",
										"aria-label": `Undo last stroke (Ctrl+Z). ${strokes.length} stroke${strokes.length === 1 ? "" : "s"} on canvas.`,
										"aria-keyshortcuts": "Control+Z Meta+Z",
										title: "Undo (Ctrl+Z)",
										children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
											"aria-hidden": "true",
											children: "↶"
										}), " Undo"]
									}),
									/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("button", {
										type: "button",
										onClick: redoAction,
										disabled: redoStack.length === 0,
										className: "rounded-md border border-slate-200 bg-white px-2 py-1 text-xs font-semibold text-slate-700 hover:border-blue-400 hover:text-blue-700 focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-blue-500 disabled:cursor-not-allowed disabled:opacity-40 dark:border-slate-700 dark:bg-slate-950 dark:text-slate-200",
										"aria-label": `Redo stroke (Ctrl+Shift+Z). ${redoStack.length} stroke${redoStack.length === 1 ? "" : "s"} available.`,
										"aria-keyshortcuts": "Control+Shift+Z Meta+Shift+Z",
										title: "Redo (Ctrl+Shift+Z)",
										children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
											"aria-hidden": "true",
											children: "↷"
										}), " Redo"]
									}),
									/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("button", {
										type: "button",
										onClick: clearPad,
										disabled: empty,
										className: "rounded-md border border-slate-200 bg-white px-2 py-1 text-xs font-semibold text-rose-600 hover:border-rose-400 focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-rose-500 disabled:cursor-not-allowed disabled:opacity-40 dark:border-slate-700 dark:bg-slate-950",
										"aria-label": "Clear signature canvas — remove all strokes",
										children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
											"aria-hidden": "true",
											children: "✕"
										}), " Clear"]
									})
								]
							})]
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("canvas", {
							id: "sign-pad-canvas",
							ref: canvasRef,
							width: CW,
							height: CH,
							role: "img",
							tabIndex: 0,
							"aria-labelledby": "sign-pad-label",
							"aria-describedby": "sign-pad-hint",
							onPointerDown: onDown,
							onPointerMove: onMove,
							onPointerUp: onUp,
							onPointerCancel: onUp,
							className: "w-full touch-none rounded-lg border border-dashed border-slate-300 bg-white focus-visible:border-blue-500 focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-blue-500 dark:border-slate-600",
							style: { aspectRatio: `${CW} / ${CH}` }
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
							id: "sign-pad-hint",
							className: "mt-1 text-[11px] text-slate-500",
							children: "Tip: Ctrl/⌘+Z to undo, Ctrl/⌘+Shift+Z to redo. Draw with mouse, pen, or finger."
						})
					] }),
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "grid gap-3 sm:grid-cols-2 xl:grid-cols-1",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("label", {
							className: "text-xs font-medium text-slate-700 dark:text-slate-300",
							children: [
								"Page",
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
									type: "number",
									min: 1,
									max: totalPages || 1,
									value: pageNum,
									onChange: (e) => setPageNum(Math.max(1, Math.min(totalPages || 1, parseInt(e.target.value || "1", 10)))),
									className: `${fieldCls} mt-1`,
									"aria-label": "Page number to sign"
								}),
								totalPages > 0 && /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", {
									className: "mt-0.5 block text-[10px] text-slate-500",
									children: ["of ", totalPages]
								})
							]
						}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("label", {
							className: "text-xs font-medium text-slate-700 dark:text-slate-300",
							children: ["Signature width (pt)", /* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
								type: "number",
								min: 40,
								max: 500,
								value: sigWidth,
								onChange: (e) => setSigWidth(parseInt(e.target.value || "180", 10)),
								className: `${fieldCls} mt-1`,
								"aria-label": "Signature width in points"
							})]
						})]
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("button", {
						type: "button",
						onClick: apply,
						disabled: busy || !file || empty,
						className: btnCls$1,
						children: [
							busy && /* @__PURE__ */ (0, import_jsx_runtime.jsx)(InlineSpinner, {}),
							" ",
							busy ? "Signing…" : "Sign & download"
						]
					})
				]
			}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "min-w-0 rounded-xl border border-slate-200 bg-white p-4 dark:border-slate-700 dark:bg-slate-950",
				children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "mb-2 flex flex-wrap items-center justify-between gap-2",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
							id: "sign-drop-label",
							className: "text-xs font-semibold text-slate-700 dark:text-slate-300",
							children: "Drag signature onto PDF page"
						}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
							className: "rounded-full bg-blue-50 px-2 py-1 text-[10px] font-semibold text-blue-700 dark:bg-blue-950/50 dark:text-blue-300",
							children: "Box = final signature space"
						})]
					}),
					file && /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						id: "sign-drop-hint",
						role: "note",
						className: "mb-2 flex flex-wrap items-center gap-2 rounded-lg border border-blue-200 bg-blue-50/70 px-3 py-2 text-[11px] font-medium text-blue-900 dark:border-blue-900/40 dark:bg-blue-950/30 dark:text-blue-200",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("svg", {
							viewBox: "0 0 24 24",
							className: "h-4 w-4 shrink-0",
							fill: "none",
							stroke: "currentColor",
							strokeWidth: "2",
							"aria-hidden": "true",
							children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("path", { d: "M12 5v14M5 12h14" })
						}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", { children: [
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("strong", {
								className: "font-semibold",
								children: "Drag"
							}),
							" the blue box, ",
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("strong", {
								className: "font-semibold",
								children: "click"
							}),
							" anywhere on the page to snap it there, or ",
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("strong", {
								className: "font-semibold",
								children: "focus"
							}),
							" the box and use ",
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("kbd", {
								className: "rounded border border-blue-300 bg-white px-1 py-[1px] font-mono text-[10px] dark:border-blue-800 dark:bg-slate-900",
								children: "Arrow"
							}),
							" keys (hold ",
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("kbd", {
								className: "rounded border border-blue-300 bg-white px-1 py-[1px] font-mono text-[10px] dark:border-blue-800 dark:bg-slate-900",
								children: "Shift"
							}),
							" to move faster)."
						] })]
					}),
					file ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
						className: "overflow-auto rounded-lg border border-slate-200 bg-slate-100 p-3 dark:border-slate-700 dark:bg-slate-900",
						children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
							ref: dragContainerRef,
							role: "application",
							"aria-labelledby": "sign-drop-label",
							"aria-describedby": "sign-drop-hint",
							className: "relative mx-auto max-w-full overflow-hidden rounded bg-white shadow-sm",
							style: { width: previewSize ? `${previewSize.w}px` : void 0 },
							onClick: onPreviewClick,
							onPointerMove: onOverlayMove,
							onPointerUp: onOverlayUp,
							onPointerCancel: onOverlayUp,
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("canvas", {
								ref: previewCanvasRef,
								className: "block h-auto w-full",
								"aria-label": `Preview of page ${pageNum}`
							}), previewSize && /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
								role: sigThumb ? "button" : void 0,
								tabIndex: sigThumb ? 0 : -1,
								"aria-label": sigThumb ? `Signature placement box on page ${pageNum}. Drag or use arrow keys to reposition. Hold Shift for larger steps.` : "Signature placement box (draw a signature first to enable).",
								"aria-describedby": "sign-drop-hint",
								"aria-grabbed": sigThumb ? false : void 0,
								"aria-keyshortcuts": sigThumb ? "ArrowLeft ArrowRight ArrowUp ArrowDown Shift+ArrowLeft Shift+ArrowRight Shift+ArrowUp Shift+ArrowDown" : void 0,
								onPointerDown: sigThumb ? onOverlayDown : void 0,
								onPointerMove: sigThumb ? onOverlayMove : void 0,
								onPointerUp: sigThumb ? onOverlayUp : void 0,
								onPointerCancel: sigThumb ? onOverlayUp : void 0,
								onKeyDown: sigThumb ? onOverlayKey : void 0,
								onClick: (e) => e.stopPropagation(),
								className: `absolute touch-none overflow-hidden rounded border-2 border-dashed border-blue-600 bg-blue-50/25 shadow-[0_0_0_9999px_rgba(37,99,235,0.04)] outline-none ring-blue-400 focus-visible:ring-2 ${sigThumb ? "cursor-grab active:cursor-grabbing" : "pointer-events-none"}`,
								style: {
									left: `${overlayLeft}px`,
									top: `${overlayTop}px`,
									width: `${overlayW}px`,
									height: `${overlayH}px`
								},
								children: [
									/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
										className: "pointer-events-none absolute inset-1 rounded border border-emerald-500/80",
										"aria-hidden": "true"
									}),
									/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
										className: "pointer-events-none absolute left-1/2 top-0 h-full border-l border-dashed border-blue-500/60",
										"aria-hidden": "true"
									}),
									/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
										className: "pointer-events-none absolute left-0 top-1/2 w-full border-t border-dashed border-blue-500/60",
										"aria-hidden": "true"
									}),
									sigThumb ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("img", {
										src: sigThumb,
										alt: "",
										className: "pointer-events-none relative z-10 h-full w-full object-contain"
									}) : /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
										className: "pointer-events-none absolute inset-0 grid place-items-center px-2 text-center text-[10px] font-semibold text-blue-700",
										children: "Draw signature first"
									})
								]
							})]
						})
					}) : /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
						className: "grid min-h-72 place-items-center rounded-lg border border-dashed border-slate-300 bg-slate-50 p-6 text-center text-sm text-slate-500 dark:border-slate-700 dark:bg-slate-900/40 dark:text-slate-400",
						children: "Upload a PDF to preview the page and place your signature."
					})
				]
			})]
		})]
	});
}
function ComparePdfCard() {
	const [fileA, setFileA] = (0, import_react.useState)(null);
	const [fileB, setFileB] = (0, import_react.useState)(null);
	const [pages, setPages] = (0, import_react.useState)([]);
	const [busy, setBusy] = (0, import_react.useState)(false);
	const tokenRef = (0, import_react.useRef)(0);
	const cancelRun = () => {
		tokenRef.current++;
		setBusy(false);
	};
	const clearAll = () => {
		setFileA(null);
		setFileB(null);
		setPages([]);
		["cmp-a", "cmp-b"].forEach((id) => {
			const el = document.getElementById(id);
			if (el) el.value = "";
		});
	};
	const renderPage = async (pdfjs, buf, page, scale = 1.4) => {
		const doc = await pdfjs.getDocument({ data: buf }).promise;
		if (page < 1 || page > doc.numPages) return null;
		const p = await doc.getPage(page);
		const vp = p.getViewport({ scale });
		const canvas = document.createElement("canvas");
		canvas.width = vp.width;
		canvas.height = vp.height;
		const ctx = canvas.getContext("2d");
		ctx.fillStyle = "#ffffff";
		ctx.fillRect(0, 0, canvas.width, canvas.height);
		await p.render({
			canvasContext: ctx,
			viewport: vp,
			canvas
		}).promise;
		return canvas;
	};
	const diffCanvas = (a, b) => {
		const w = Math.max(a.width, b.width);
		const h = Math.max(a.height, b.height);
		const A = document.createElement("canvas");
		A.width = w;
		A.height = h;
		const B = document.createElement("canvas");
		B.width = w;
		B.height = h;
		const ac = A.getContext("2d");
		const bc = B.getContext("2d");
		ac.fillStyle = "#ffffff";
		ac.fillRect(0, 0, w, h);
		ac.drawImage(a, 0, 0);
		bc.fillStyle = "#ffffff";
		bc.fillRect(0, 0, w, h);
		bc.drawImage(b, 0, 0);
		const ad = ac.getImageData(0, 0, w, h);
		const bd = bc.getImageData(0, 0, w, h);
		const out = ac.createImageData(w, h);
		let changed = 0;
		for (let i = 0; i < ad.data.length; i += 4) {
			const dr = Math.abs(ad.data[i] - bd.data[i]);
			const dg = Math.abs(ad.data[i + 1] - bd.data[i + 1]);
			const db = Math.abs(ad.data[i + 2] - bd.data[i + 2]);
			const delta = dr + dg + db;
			const soft = 220 + (.299 * ad.data[i] + .587 * ad.data[i + 1] + .114 * ad.data[i + 2] - 220) * .35;
			out.data[i] = soft;
			out.data[i + 1] = soft;
			out.data[i + 2] = soft;
			out.data[i + 3] = 255;
			if (delta > 30) {
				out.data[i] = 239;
				out.data[i + 1] = 68;
				out.data[i + 2] = 68;
				out.data[i + 3] = 255;
				changed++;
			}
		}
		const O = document.createElement("canvas");
		O.width = w;
		O.height = h;
		O.getContext("2d").putImageData(out, 0, 0);
		return {
			canvas: O,
			changed,
			total: w * h
		};
	};
	const compare = async () => {
		trackUse("pdf-compare");
		if (!fileA || !fileB) return alert("Choose two PDFs to compare");
		const tk = ++tokenRef.current;
		setBusy(true);
		setPages([]);
		try {
			const pdfjs = await import("../_libs/pdfjs-dist.mjs").then((n) => n.t);
			const worker = await import("./pdf.worker.min-Be_rUMwQ.mjs");
			pdfjs.GlobalWorkerOptions.workerSrc = worker.default;
			const [bufA, bufB] = await Promise.all([fileA.arrayBuffer(), fileB.arrayBuffer()]);
			const docA = await pdfjs.getDocument({ data: bufA.slice(0) }).promise;
			const docB = await pdfjs.getDocument({ data: bufB.slice(0) }).promise;
			const pageCount = Math.max(docA.numPages, docB.numPages);
			const results = [];
			for (let i = 1; i <= pageCount; i++) {
				if (tk !== tokenRef.current) return;
				const [ca, cb] = await Promise.all([renderPage(pdfjs, bufA.slice(0), i), renderPage(pdfjs, bufB.slice(0), i)]);
				let diffUrl;
				let changed = 0;
				if (ca && cb) {
					const d = diffCanvas(ca, cb);
					diffUrl = d.canvas.toDataURL("image/png");
					changed = Math.round(d.changed / d.total * 1e4) / 100;
				} else if (ca && !cb) changed = 100;
				else if (!ca && cb) changed = 100;
				results.push({
					a: ca?.toDataURL("image/png"),
					b: cb?.toDataURL("image/png"),
					diff: diffUrl,
					changed
				});
				setPages([...results]);
			}
		} catch (e) {
			alert("Compare failed: " + e.message);
		} finally {
			if (tk === tokenRef.current) setBusy(false);
		}
	};
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(ToolShell, {
		id: "compare",
		title: "Compare PDF",
		desc: "Render both PDFs side-by-side and highlight visual differences in red — page by page.",
		busy,
		onCancel: cancelRun,
		canClear: !!fileA || !!fileB || pages.length > 0,
		onClear: clearAll,
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "grid gap-3 sm:grid-cols-2",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("label", {
					className: "text-xs font-medium text-slate-700 dark:text-slate-300",
					children: ["PDF A", /* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
						id: "cmp-a",
						type: "file",
						accept: "application/pdf",
						onChange: (e) => setFileA(e.target.files?.[0] ?? null),
						className: `${inputCls$1} mt-1`,
						"aria-label": "First PDF"
					})]
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("label", {
					className: "text-xs font-medium text-slate-700 dark:text-slate-300",
					children: ["PDF B", /* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
						id: "cmp-b",
						type: "file",
						accept: "application/pdf",
						onChange: (e) => setFileB(e.target.files?.[0] ?? null),
						className: `${inputCls$1} mt-1`,
						"aria-label": "Second PDF"
					})]
				})]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("button", {
				type: "button",
				onClick: compare,
				disabled: busy || !fileA || !fileB,
				className: btnCls$1,
				children: [
					busy && /* @__PURE__ */ (0, import_jsx_runtime.jsx)(InlineSpinner, {}),
					" ",
					busy ? "Comparing…" : "Compare"
				]
			}),
			pages.length > 0 && /* @__PURE__ */ (0, import_jsx_runtime.jsx)("ol", {
				className: "mt-5 space-y-6",
				"aria-label": "Comparison results",
				children: pages.map((p, i) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("li", {
					className: "rounded-xl border border-slate-200 bg-slate-50 p-3 dark:border-slate-800 dark:bg-slate-950/50",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "mb-2 flex items-center justify-between",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
							className: "text-xs font-bold text-slate-700 dark:text-slate-200",
							children: ["Page ", i + 1]
						}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
							className: `rounded-full px-2 py-0.5 text-[10px] font-bold uppercase tracking-wider ${p.changed > .05 ? "bg-rose-100 text-rose-700 dark:bg-rose-950/60 dark:text-rose-300" : "bg-emerald-100 text-emerald-700 dark:bg-emerald-950/60 dark:text-emerald-300"}`,
							children: p.changed > .05 ? `${p.changed}% changed` : "Identical"
						})]
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "grid gap-2 sm:grid-cols-3",
						children: [
							/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("figure", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("figcaption", {
								className: "mb-1 text-[10px] font-semibold uppercase text-slate-500",
								children: "A"
							}), p.a ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("img", {
								src: p.a,
								alt: `PDF A page ${i + 1}`,
								className: "w-full rounded border border-slate-200",
								loading: "lazy"
							}) : /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
								className: "rounded border border-dashed border-slate-300 p-4 text-center text-[10px] text-slate-500",
								children: "missing"
							})] }),
							/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("figure", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("figcaption", {
								className: "mb-1 text-[10px] font-semibold uppercase text-slate-500",
								children: "B"
							}), p.b ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("img", {
								src: p.b,
								alt: `PDF B page ${i + 1}`,
								className: "w-full rounded border border-slate-200",
								loading: "lazy"
							}) : /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
								className: "rounded border border-dashed border-slate-300 p-4 text-center text-[10px] text-slate-500",
								children: "missing"
							})] }),
							/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("figure", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("figcaption", {
								className: "mb-1 text-[10px] font-semibold uppercase text-slate-500",
								children: "Diff"
							}), p.diff ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("img", {
								src: p.diff,
								alt: `Difference on page ${i + 1}`,
								className: "w-full rounded border border-slate-200",
								loading: "lazy"
							}) : /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
								className: "rounded border border-dashed border-slate-300 p-4 text-center text-[10px] text-slate-500",
								children: "—"
							})] })
						]
					})]
				}, i))
			})
		]
	});
}
function WordToPdfCard() {
	const [file, setFile] = (0, import_react.useState)(null);
	const [busy, setBusy] = (0, import_react.useState)(false);
	const tokenRef = (0, import_react.useRef)(0);
	const cancel = () => {
		tokenRef.current++;
		setBusy(false);
	};
	const clear = () => {
		setFile(null);
		const el = document.getElementById("w2p-in");
		if (el) el.value = "";
	};
	const convert = async () => {
		if (!file) return;
		trackUse("pdf-word-to-pdf");
		const tk = ++tokenRef.current;
		setBusy(true);
		try {
			const [{ default: mammoth }, { default: html2canvas }, { jsPDF }] = await Promise.all([
				import("../_libs/mammoth+[...].mjs").then((n) => /* @__PURE__ */ __toESM(n.t())),
				import("../_libs/html2canvas.mjs").then((n) => n.t),
				import("../_libs/jspdf.mjs").then((n) => n.t)
			]);
			if (tk !== tokenRef.current) return;
			const buf = await file.arrayBuffer();
			const { value: htmlBody } = await mammoth.convertToHtml({ arrayBuffer: buf });
			if (tk !== tokenRef.current) return;
			const host = document.createElement("div");
			host.style.cssText = "position:fixed;left:-99999px;top:0;width:794px;padding:48px;background:#fff;color:#0f172a;font-family:Georgia,serif;line-height:1.55;font-size:14px;";
			host.innerHTML = htmlBody;
			document.body.appendChild(host);
			try {
				const canvas = await html2canvas(host, {
					scale: 2,
					backgroundColor: "#ffffff"
				});
				if (tk !== tokenRef.current) return;
				const pdf = new jsPDF({
					unit: "pt",
					format: "a4",
					compress: true
				});
				const pageW = pdf.internal.pageSize.getWidth();
				const pageH = pdf.internal.pageSize.getHeight();
				const pxPerPt = canvas.width / pageW;
				const sliceHeightPx = Math.floor(pageH * pxPerPt);
				let y = 0, first = true;
				while (y < canvas.height) {
					const h = Math.min(sliceHeightPx, canvas.height - y);
					const slice = document.createElement("canvas");
					slice.width = canvas.width;
					slice.height = h;
					const ctx = slice.getContext("2d");
					ctx.fillStyle = "#fff";
					ctx.fillRect(0, 0, slice.width, slice.height);
					ctx.drawImage(canvas, 0, y, canvas.width, h, 0, 0, canvas.width, h);
					if (!first) pdf.addPage();
					first = false;
					pdf.addImage(slice.toDataURL("image/jpeg", .9), "JPEG", 0, 0, pageW, h / canvas.width * pageW);
					y += h;
				}
				pdf.save(file.name.replace(/\.docx?$/i, "") + ".pdf");
			} finally {
				host.remove();
			}
		} catch (e) {
			alert("Word to PDF failed: " + e.message);
		} finally {
			if (tk === tokenRef.current) setBusy(false);
		}
	};
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(ToolShell, {
		id: "word-to-pdf",
		title: "Word to PDF",
		desc: "Convert .docx documents to PDF. Text and basic formatting are preserved; complex layouts, images and shapes may be approximated.",
		busy,
		onCancel: cancel,
		canClear: !!file,
		onClear: clear,
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
				id: "w2p-in",
				type: "file",
				accept: ".docx,application/vnd.openxmlformats-officedocument.wordprocessingml.document",
				onChange: (e) => setFile(e.target.files?.[0] ?? null),
				className: inputCls$1
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
				className: "mt-2 text-xs text-slate-500 dark:text-slate-400",
				children: "Note: only .docx is supported. Legacy .doc files need to be saved as .docx first."
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("button", {
				type: "button",
				onClick: convert,
				disabled: busy || !file,
				className: btnCls$1,
				children: [
					busy && /* @__PURE__ */ (0, import_jsx_runtime.jsx)(InlineSpinner, {}),
					" ",
					busy ? "Converting…" : "Convert to PDF"
				]
			})
		]
	});
}
function ExcelToPdfCard() {
	const [file, setFile] = (0, import_react.useState)(null);
	const [busy, setBusy] = (0, import_react.useState)(false);
	const tokenRef = (0, import_react.useRef)(0);
	const cancel = () => {
		tokenRef.current++;
		setBusy(false);
	};
	const clear = () => {
		setFile(null);
		const el = document.getElementById("x2p-in");
		if (el) el.value = "";
	};
	const convert = async () => {
		if (!file) return;
		trackUse("pdf-excel-to-pdf");
		const tk = ++tokenRef.current;
		setBusy(true);
		try {
			const [XLSX, { default: html2canvas }, { jsPDF }] = await Promise.all([
				import("../_libs/xlsx.mjs").then((n) => n.t),
				import("../_libs/html2canvas.mjs").then((n) => n.t),
				import("../_libs/jspdf.mjs").then((n) => n.t)
			]);
			if (tk !== tokenRef.current) return;
			const buf = await file.arrayBuffer();
			const wb = XLSX.read(buf, { type: "array" });
			const pdf = new jsPDF({
				unit: "pt",
				format: "a4",
				orientation: "landscape",
				compress: true
			});
			const pageW = pdf.internal.pageSize.getWidth();
			const pageH = pdf.internal.pageSize.getHeight();
			let firstSheet = true;
			for (const name of wb.SheetNames) {
				if (tk !== tokenRef.current) return;
				const ws = wb.Sheets[name];
				const html = XLSX.utils.sheet_to_html(ws, { editable: false });
				const host = document.createElement("div");
				host.style.cssText = "position:fixed;left:-99999px;top:0;width:1400px;padding:24px;background:#fff;color:#0f172a;font-family:system-ui,sans-serif;font-size:12px;";
				host.innerHTML = `<h2 style="margin:0 0 12px;font-family:system-ui">${name}</h2>` + html;
				host.querySelectorAll("table").forEach((t) => {
					t.style.cssText = "border-collapse:collapse;width:100%;";
				});
				host.querySelectorAll("td,th").forEach((c) => {
					c.style.cssText = "border:1px solid #cbd5e1;padding:4px 6px;";
				});
				document.body.appendChild(host);
				try {
					const canvas = await html2canvas(host, {
						scale: 2,
						backgroundColor: "#ffffff"
					});
					if (tk !== tokenRef.current) return;
					if (!firstSheet) pdf.addPage();
					firstSheet = false;
					const pxPerPt = canvas.width / pageW;
					const sliceHeightPx = Math.floor(pageH * pxPerPt);
					let y = 0, firstSlice = true;
					while (y < canvas.height) {
						const h = Math.min(sliceHeightPx, canvas.height - y);
						const slice = document.createElement("canvas");
						slice.width = canvas.width;
						slice.height = h;
						const ctx = slice.getContext("2d");
						ctx.fillStyle = "#fff";
						ctx.fillRect(0, 0, slice.width, slice.height);
						ctx.drawImage(canvas, 0, y, canvas.width, h, 0, 0, canvas.width, h);
						if (!firstSlice) pdf.addPage();
						firstSlice = false;
						pdf.addImage(slice.toDataURL("image/jpeg", .9), "JPEG", 0, 0, pageW, h / canvas.width * pageW);
						y += h;
					}
				} finally {
					host.remove();
				}
			}
			pdf.save(file.name.replace(/\.xlsx?$/i, "") + ".pdf");
		} catch (e) {
			alert("Excel to PDF failed: " + e.message);
		} finally {
			if (tk === tokenRef.current) setBusy(false);
		}
	};
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(ToolShell, {
		id: "excel-to-pdf",
		title: "Excel to PDF",
		desc: "Convert .xlsx and .xls spreadsheets to PDF (one sheet per section). Formulas are evaluated; charts and images are not exported.",
		busy,
		onCancel: cancel,
		canClear: !!file,
		onClear: clear,
		children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
			id: "x2p-in",
			type: "file",
			accept: ".xlsx,.xls,.csv,application/vnd.ms-excel,application/vnd.openxmlformats-officedocument.spreadsheetml.sheet",
			onChange: (e) => setFile(e.target.files?.[0] ?? null),
			className: inputCls$1
		}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("button", {
			type: "button",
			onClick: convert,
			disabled: busy || !file,
			className: btnCls$1,
			children: [
				busy && /* @__PURE__ */ (0, import_jsx_runtime.jsx)(InlineSpinner, {}),
				" ",
				busy ? "Converting…" : "Convert to PDF"
			]
		})]
	});
}
function PdfToWordCard() {
	const [file, setFile] = (0, import_react.useState)(null);
	const [busy, setBusy] = (0, import_react.useState)(false);
	const tokenRef = (0, import_react.useRef)(0);
	const cancel = () => {
		tokenRef.current++;
		setBusy(false);
	};
	const clear = () => {
		setFile(null);
		const el = document.getElementById("p2w-in");
		if (el) el.value = "";
	};
	const convert = async () => {
		if (!file) return;
		trackUse("pdf-to-word");
		const tk = ++tokenRef.current;
		setBusy(true);
		try {
			const [pdfjs, worker, docxLib] = await Promise.all([
				import("../_libs/pdfjs-dist.mjs").then((n) => n.t),
				import("./pdf.worker.min-Be_rUMwQ.mjs"),
				import("../_libs/docx.mjs").then((n) => n.t)
			]);
			pdfjs.GlobalWorkerOptions.workerSrc = worker.default;
			const buf = await file.arrayBuffer();
			const pdf = await pdfjs.getDocument({ data: buf }).promise;
			if (tk !== tokenRef.current) return;
			const { Document, Packer, Paragraph, TextRun, PageBreak } = docxLib;
			const children = [];
			for (let i = 1; i <= pdf.numPages; i++) {
				if (tk !== tokenRef.current) return;
				const content = await (await pdf.getPage(i)).getTextContent();
				const rowMap = /* @__PURE__ */ new Map();
				for (const it of content.items) {
					const y = Math.round((it.transform?.[5] || 0) / 2) * 2;
					const x = it.transform?.[4] || 0;
					const s = String(it.str || "");
					if (!s) continue;
					if (!rowMap.has(y)) rowMap.set(y, []);
					rowMap.get(y).push({
						x,
						s
					});
				}
				const rows = Array.from(rowMap.entries()).sort((a, b) => b[0] - a[0]).map(([, cells]) => cells.sort((a, b) => a.x - b.x).map((c) => c.s).join(" ").trim()).filter((line) => line.length > 0);
				for (const line of rows) children.push(new Paragraph({ children: [new TextRun(line)] }));
				if (i < pdf.numPages) children.push(new Paragraph({ children: [new PageBreak()] }));
			}
			const doc = new Document({ sections: [{ children }] });
			saveBlob(await Packer.toBlob(doc), file.name.replace(/\.pdf$/i, "") + ".docx", "application/vnd.openxmlformats-officedocument.wordprocessingml.document");
		} catch (e) {
			alert("PDF to Word failed: " + e.message);
		} finally {
			if (tk === tokenRef.current) setBusy(false);
		}
	};
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(ToolShell, {
		id: "pdf-to-word",
		title: "PDF to Word",
		desc: "Extract editable text from each PDF page and place it into a Word document — the result is selectable, searchable and editable.",
		busy,
		onCancel: cancel,
		canClear: !!file,
		onClear: clear,
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
				id: "p2w-in",
				type: "file",
				accept: "application/pdf",
				onChange: (e) => setFile(e.target.files?.[0] ?? null),
				className: inputCls$1
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
				className: "mt-2 text-xs text-slate-500 dark:text-slate-400",
				children: "Text is extracted directly from the PDF, so images and complex visual layout are not preserved — but the output is fully editable."
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("button", {
				type: "button",
				onClick: convert,
				disabled: busy || !file,
				className: btnCls$1,
				children: [
					busy && /* @__PURE__ */ (0, import_jsx_runtime.jsx)(InlineSpinner, {}),
					" ",
					busy ? "Converting…" : "Convert to Word"
				]
			})
		]
	});
}
function PdfToExcelCard() {
	const [file, setFile] = (0, import_react.useState)(null);
	const [busy, setBusy] = (0, import_react.useState)(false);
	const tokenRef = (0, import_react.useRef)(0);
	const cancel = () => {
		tokenRef.current++;
		setBusy(false);
	};
	const clear = () => {
		setFile(null);
		const el = document.getElementById("p2x-in");
		if (el) el.value = "";
	};
	const convert = async () => {
		if (!file) return;
		trackUse("pdf-to-excel");
		const tk = ++tokenRef.current;
		setBusy(true);
		try {
			const [pdfjs, worker, XLSX] = await Promise.all([
				import("../_libs/pdfjs-dist.mjs").then((n) => n.t),
				import("./pdf.worker.min-Be_rUMwQ.mjs"),
				import("../_libs/xlsx.mjs").then((n) => n.t)
			]);
			pdfjs.GlobalWorkerOptions.workerSrc = worker.default;
			const buf = await file.arrayBuffer();
			const pdf = await pdfjs.getDocument({ data: buf }).promise;
			const wb = XLSX.utils.book_new();
			for (let i = 1; i <= pdf.numPages; i++) {
				if (tk !== tokenRef.current) return;
				const content = await (await pdf.getPage(i)).getTextContent();
				const rowMap = /* @__PURE__ */ new Map();
				for (const it of content.items) {
					const y = Math.round((it.transform?.[5] || 0) / 2) * 2;
					const x = it.transform?.[4] || 0;
					const s = String(it.str || "");
					if (!s.trim()) continue;
					if (!rowMap.has(y)) rowMap.set(y, []);
					rowMap.get(y).push({
						x,
						s
					});
				}
				const rows = Array.from(rowMap.entries()).sort((a, b) => b[0] - a[0]).map(([, cells]) => cells.sort((a, b) => a.x - b.x).map((c) => c.s));
				const ws = XLSX.utils.aoa_to_sheet(rows.length ? rows : [[""]]);
				XLSX.utils.book_append_sheet(wb, ws, `Page ${i}`.slice(0, 31));
			}
			saveBlob(XLSX.write(wb, {
				type: "array",
				bookType: "xlsx"
			}), file.name.replace(/\.pdf$/i, "") + ".xlsx", "application/vnd.openxmlformats-officedocument.spreadsheetml.sheet");
		} catch (e) {
			alert("PDF to Excel failed: " + e.message);
		} finally {
			if (tk === tokenRef.current) setBusy(false);
		}
	};
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(ToolShell, {
		id: "pdf-to-excel",
		title: "PDF to Excel",
		desc: "Extract text from every page into an .xlsx workbook (one sheet per page). Best for text-heavy PDFs — true table detection needs a server.",
		busy,
		onCancel: cancel,
		canClear: !!file,
		onClear: clear,
		children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
			id: "p2x-in",
			type: "file",
			accept: "application/pdf",
			onChange: (e) => setFile(e.target.files?.[0] ?? null),
			className: inputCls$1
		}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("button", {
			type: "button",
			onClick: convert,
			disabled: busy || !file,
			className: btnCls$1,
			children: [
				busy && /* @__PURE__ */ (0, import_jsx_runtime.jsx)(InlineSpinner, {}),
				" ",
				busy ? "Converting…" : "Convert to Excel"
			]
		})]
	});
}
function RedactPdfCard() {
	const [file, setFile] = (0, import_react.useState)(null);
	const [boxes, setBoxes] = (0, import_react.useState)([{
		page: 1,
		x: 50,
		y: 50,
		w: 200,
		h: 30
	}]);
	const [busy, setBusy] = (0, import_react.useState)(false);
	const tokenRef = (0, import_react.useRef)(0);
	const cancel = () => {
		tokenRef.current++;
		setBusy(false);
	};
	const clear = () => {
		setFile(null);
		setBoxes([{
			page: 1,
			x: 50,
			y: 50,
			w: 200,
			h: 30
		}]);
		const el = document.getElementById("rd-in");
		if (el) el.value = "";
	};
	const updateBox = (i, patch) => setBoxes((prev) => prev.map((b, idx) => idx === i ? {
		...b,
		...patch
	} : b));
	const addBox = () => setBoxes((prev) => [...prev, {
		page: 1,
		x: 50,
		y: 50,
		w: 200,
		h: 30
	}]);
	const removeBox = (i) => setBoxes((prev) => prev.filter((_, idx) => idx !== i));
	const run = async () => {
		if (!file) return;
		trackUse("pdf-redact");
		const tk = ++tokenRef.current;
		setBusy(true);
		try {
			const buf = await file.arrayBuffer();
			const pdfDoc = await PDFDocument.load(buf);
			if (tk !== tokenRef.current) return;
			const pages = pdfDoc.getPages();
			for (const b of boxes) {
				const page = pages[Math.max(1, Math.min(pages.length, b.page)) - 1];
				const ph = page.getHeight();
				page.drawRectangle({
					x: b.x,
					y: ph - b.y - b.h,
					width: b.w,
					height: b.h,
					color: rgb(0, 0, 0),
					opacity: 1
				});
			}
			saveBlob(await pdfDoc.save(), file.name.replace(/\.pdf$/i, "") + "-redacted.pdf");
		} catch (e) {
			alert("Redact failed: " + e.message);
		} finally {
			if (tk === tokenRef.current) setBusy(false);
		}
	};
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(ToolShell, {
		id: "redact",
		title: "Redact PDF",
		desc: "Cover sensitive regions with opaque black rectangles. Coordinates are in points (72 pt = 1 inch), measured from the top-left of the page.",
		busy,
		onCancel: cancel,
		canClear: !!file || boxes.length > 1,
		onClear: clear,
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
				id: "rd-in",
				type: "file",
				accept: "application/pdf",
				onChange: (e) => setFile(e.target.files?.[0] ?? null),
				className: inputCls$1
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "mt-3 space-y-2",
				children: [boxes.map((b, i) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "grid grid-cols-2 gap-2 rounded-lg border border-slate-200 p-2 sm:grid-cols-6 dark:border-slate-700",
					children: [
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("label", {
							className: "text-xs",
							children: ["Page", /* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
								type: "number",
								min: 1,
								value: b.page,
								onChange: (e) => updateBox(i, { page: parseInt(e.target.value || "1", 10) }),
								className: fieldCls
							})]
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("label", {
							className: "text-xs",
							children: ["X", /* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
								type: "number",
								value: b.x,
								onChange: (e) => updateBox(i, { x: parseFloat(e.target.value || "0") }),
								className: fieldCls
							})]
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("label", {
							className: "text-xs",
							children: ["Y", /* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
								type: "number",
								value: b.y,
								onChange: (e) => updateBox(i, { y: parseFloat(e.target.value || "0") }),
								className: fieldCls
							})]
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("label", {
							className: "text-xs",
							children: ["Width", /* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
								type: "number",
								value: b.w,
								onChange: (e) => updateBox(i, { w: parseFloat(e.target.value || "0") }),
								className: fieldCls
							})]
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("label", {
							className: "text-xs",
							children: ["Height", /* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
								type: "number",
								value: b.h,
								onChange: (e) => updateBox(i, { h: parseFloat(e.target.value || "0") }),
								className: fieldCls
							})]
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
							type: "button",
							onClick: () => removeBox(i),
							disabled: boxes.length <= 1,
							className: "self-end rounded-lg border border-rose-300 bg-white px-2 py-1 text-xs font-semibold text-rose-700 disabled:opacity-50 dark:bg-slate-950",
							children: "Remove"
						})
					]
				}, i)), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
					type: "button",
					onClick: addBox,
					className: "rounded-lg border border-slate-300 bg-white px-3 py-1 text-xs font-semibold text-slate-700 dark:border-slate-700 dark:bg-slate-900 dark:text-slate-200",
					children: "+ Add region"
				})]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
				className: "mt-2 text-xs text-slate-500 dark:text-slate-400",
				children: "Note: this visually covers the region. For guaranteed removal of the underlying text stream, use a server-side redaction tool."
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("button", {
				type: "button",
				onClick: run,
				disabled: busy || !file,
				className: btnCls$1,
				children: [
					busy && /* @__PURE__ */ (0, import_jsx_runtime.jsx)(InlineSpinner, {}),
					" ",
					busy ? "Redacting…" : "Redact & download"
				]
			})
		]
	});
}
function makeDownloader(setStatus) {
	return function download(bytes, name) {
		try {
			setStatus(`Preparing download: ${name}…`);
			const blob = new Blob([bytes], { type: "application/pdf" });
			const url = URL.createObjectURL(blob);
			const a = document.createElement("a");
			a.href = url;
			a.download = name;
			setStatus(`Download in progress: ${name}`);
			a.click();
			setTimeout(() => URL.revokeObjectURL(url), 1e3);
			setStatus(`Download completed: ${name} (${blob.size} bytes)`);
		} catch (err) {
			setStatus(`Download failed: ${err?.message || "browser blocked the download"}`);
			throw err;
		}
	};
}
function Card({ id, title, desc, busy, onCancel, onClear, canClear, children }) {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Reveal, {
		as: "section",
		children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("section", {
			id,
			className: "scroll-mt-32 rounded-2xl border border-slate-200 bg-white p-6 dark:border-slate-800 dark:bg-slate-900",
			children: [
				/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "flex items-start justify-between gap-3",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h2", {
						className: "text-lg font-bold text-slate-900 dark:text-white",
						style: { fontFamily: "'Space Grotesk', sans-serif" },
						children: title
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
						className: "mt-1 text-sm text-slate-600 dark:text-slate-400",
						children: desc
					})] }), onClear && canClear && /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("button", {
						type: "button",
						onClick: onClear,
						"aria-label": `Clear ${title}`,
						className: "inline-flex shrink-0 items-center gap-1 rounded-lg border border-slate-200 bg-white px-2.5 py-1 text-xs font-semibold text-slate-600 transition hover:border-rose-300 hover:text-rose-600 dark:border-slate-700 dark:bg-slate-950 dark:text-slate-300",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("svg", {
							viewBox: "0 0 24 24",
							className: "h-3.5 w-3.5",
							fill: "none",
							stroke: "currentColor",
							strokeWidth: "2",
							"aria-hidden": "true",
							children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("path", { d: "M18 6 6 18M6 6l12 12" })
						}), "Clear"]
					})]
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
					className: "mt-4",
					"aria-busy": busy ? true : void 0,
					children
				}),
				busy && /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "mt-4 rounded-lg border border-dashed border-slate-200 bg-slate-50 p-4 dark:border-slate-700 dark:bg-slate-950/40",
					role: "status",
					"aria-live": "polite",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "flex items-center justify-between gap-3",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
							className: "flex items-center gap-2 text-xs font-medium text-slate-500 dark:text-slate-400",
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(InlineSpinner, {}), " Processing PDF…"]
						}), onCancel && /* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
							type: "button",
							onClick: onCancel,
							"aria-label": `Cancel ${title}`,
							className: "rounded-lg border border-rose-300 bg-white px-3 py-1 text-xs font-semibold text-rose-700 transition hover:bg-rose-50 dark:border-rose-800 dark:bg-slate-900 dark:text-rose-300 dark:hover:bg-rose-950/40",
							children: "Cancel"
						})]
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
						className: "mt-3",
						children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(SkeletonLines, { count: 3 })
					})]
				})
			]
		})
	});
}
function BtnLabel({ busy, idle, working }) {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", {
		className: "inline-flex items-center gap-2",
		children: [busy && /* @__PURE__ */ (0, import_jsx_runtime.jsx)(InlineSpinner, {}), busy ? working : idle]
	});
}
function PremiumBadge() {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", {
		className: "inline-flex items-center gap-1 rounded-full bg-gradient-to-r from-amber-400 to-orange-500 px-2 py-0.5 text-[10px] font-bold uppercase tracking-wider text-white shadow-sm",
		"aria-label": "Premium feature",
		children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("svg", {
			viewBox: "0 0 24 24",
			className: "h-3 w-3",
			fill: "currentColor",
			"aria-hidden": "true",
			children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("path", { d: "M12 2l3.09 6.26L22 9.27l-5 4.87 1.18 6.88L12 17.77l-6.18 3.25L7 14.14 2 9.27l6.91-1.01L12 2z" })
		}), "Pro"]
	});
}
function PremiumCard({ id, title, desc, icon }) {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Reveal, {
		as: "section",
		children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("section", {
			id,
			className: "scroll-mt-32 rounded-2xl border border-slate-200 bg-gradient-to-br from-white to-amber-50/40 p-6 dark:border-slate-800 dark:from-slate-900 dark:to-amber-950/20",
			"aria-labelledby": `${id}-title`,
			children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
				className: "flex items-start justify-between gap-3",
				children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "flex items-start gap-3",
					children: [icon && /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
						className: "mt-0.5 text-amber-600",
						"aria-hidden": "true",
						children: icon
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "flex items-center gap-2",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h3", {
							id: `${id}-title`,
							className: "text-lg font-bold text-slate-900 dark:text-white",
							style: { fontFamily: "'Space Grotesk', sans-serif" },
							children: title
						}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(PremiumBadge, {})]
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
						className: "mt-1 text-sm text-slate-600 dark:text-slate-400",
						children: desc
					})] })]
				})
			}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("button", {
				type: "button",
				disabled: true,
				"aria-disabled": "true",
				title: "Premium feature — available with Pro",
				className: "mt-4 inline-flex cursor-not-allowed items-center gap-2 rounded-lg bg-slate-200 px-4 py-2 text-sm font-semibold text-slate-500 dark:bg-slate-800 dark:text-slate-400",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("svg", {
					viewBox: "0 0 24 24",
					className: "h-4 w-4",
					fill: "none",
					stroke: "currentColor",
					strokeWidth: "2",
					"aria-hidden": "true",
					children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("path", { d: "M12 15v2m-6 4h12a2 2 0 002-2v-6a2 2 0 00-2-2H6a2 2 0 00-2 2v6a2 2 0 002 2zm10-10V7a4 4 0 00-8 0v4h8z" })
				}), "Unlock with Pro"]
			})]
		})
	});
}
function ComingSoonCard({ id, title, desc }) {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Reveal, {
		as: "section",
		children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("section", {
			id,
			className: "scroll-mt-32 rounded-2xl border border-dashed border-slate-300 bg-slate-50/60 p-6 dark:border-slate-700 dark:bg-slate-900/40",
			"aria-labelledby": `${id}-title`,
			children: [
				/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "flex items-center gap-2",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h3", {
						id: `${id}-title`,
						className: "text-lg font-bold text-slate-900 dark:text-white",
						style: { fontFamily: "'Space Grotesk', sans-serif" },
						children: title
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
						className: "inline-flex items-center rounded-full bg-slate-200 px-2 py-0.5 text-[10px] font-bold uppercase tracking-wider text-slate-700 dark:bg-slate-800 dark:text-slate-300",
						children: "Coming soon"
					})]
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
					className: "mt-1 text-sm text-slate-600 dark:text-slate-400",
					children: desc
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
					className: "mt-3 text-xs text-slate-500 dark:text-slate-500",
					children: "Free when it launches. We're building this in-browser so your files never leave your device."
				})
			]
		})
	});
}
function MostUsedPdfTools() {
	const [top, setTop] = (0, import_react.useState)([]);
	(0, import_react.useEffect)(() => {
		const compute = () => {
			const counts = getCounts();
			const ranked = TOOLS.filter((t) => t.category === "pdf").map((meta) => ({
				id: meta.id,
				count: counts[meta.id] || 0,
				meta
			})).filter((t) => t.count > 0).sort((a, b) => b.count - a.count).slice(0, 3);
			setTop(ranked);
		};
		compute();
		return subscribeUsage(compute);
	}, []);
	if (top.length === 0) return null;
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Reveal, {
		as: "section",
		children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("section", {
			"aria-labelledby": "most-used-pdf",
			className: "mb-8 rounded-2xl border border-blue-100 bg-gradient-to-br from-blue-50 to-white p-6 dark:border-blue-900/40 dark:from-blue-950/30 dark:to-slate-900",
			children: [
				/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "flex items-center gap-2",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("svg", {
						viewBox: "0 0 24 24",
						className: "h-5 w-5 text-blue-600",
						fill: "none",
						stroke: "currentColor",
						strokeWidth: "2",
						"aria-hidden": "true",
						children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("path", { d: "M13 2 3 14h9l-1 8 10-12h-9l1-8z" })
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("h2", {
						id: "most-used-pdf",
						className: "text-lg font-bold text-slate-900 dark:text-white",
						style: { fontFamily: "'Space Grotesk', sans-serif" },
						children: "Most used in PDF tools"
					})]
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
					className: "mt-1 text-sm text-slate-600 dark:text-slate-400",
					children: "Your top PDF tools based on real usage."
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("ol", {
					className: "mt-4 grid gap-3 sm:grid-cols-2 lg:grid-cols-3",
					role: "list",
					children: top.map((t, i) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)("li", { children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("a", {
						href: t.meta.route,
						"aria-label": `${t.meta.name} — used ${t.count} time${t.count === 1 ? "" : "s"}`,
						className: "group flex h-full flex-col rounded-xl border border-slate-200 bg-white p-4 transition hover:-translate-y-0.5 hover:border-blue-400 hover:shadow-md focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-blue-500 dark:border-slate-800 dark:bg-slate-950",
						children: [
							/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
								className: "flex items-center justify-between",
								children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", {
									className: "inline-flex h-7 w-7 items-center justify-center rounded-full bg-blue-600 text-xs font-bold text-white",
									children: ["#", i + 1]
								}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", {
									className: "text-xs font-semibold text-slate-500 dark:text-slate-400",
									"aria-hidden": "true",
									children: [
										t.count,
										" use",
										t.count === 1 ? "" : "s"
									]
								})]
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h3", {
								className: "mt-3 text-sm font-bold text-slate-900 group-hover:text-blue-700 dark:text-white",
								children: t.meta.name
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
								className: "mt-1 text-xs text-slate-600 dark:text-slate-400",
								children: t.meta.description
							})
						]
					}) }, t.id))
				})
			]
		})
	});
}
var inputCls = "block w-full text-sm text-slate-700 file:mr-3 file:rounded-lg file:border-0 file:bg-blue-600 file:px-3 file:py-2 file:text-sm file:font-semibold file:text-white file:hover:bg-blue-700 dark:text-slate-200";
var btnCls = "mt-3 inline-flex items-center rounded-lg bg-blue-600 px-4 py-2 text-sm font-semibold text-white transition hover:bg-blue-700 disabled:opacity-60";
function SectionHeader({ id, kicker, title, desc }) {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		id,
		className: "col-span-full mt-2 scroll-mt-32",
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
				className: "text-xs font-bold uppercase tracking-widest text-blue-600",
				children: kicker
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h2", {
				className: "mt-1 text-2xl font-bold text-slate-900 dark:text-white",
				style: { fontFamily: "'Space Grotesk', sans-serif" },
				children: title
			}),
			desc && /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
				className: "mt-1 text-sm text-slate-600 dark:text-slate-400",
				children: desc
			})
		]
	});
}
function PdfTools() {
	const { banner, guardClick } = useMeteredCategory();
	(0, import_react.useEffect)(() => {
		trackUse("pdf-merge");
	}, []);
	const [mergeFiles, setMergeFiles] = (0, import_react.useState)([]);
	const [busy, setBusy] = (0, import_react.useState)(null);
	const [status, setStatus] = (0, import_react.useState)("");
	const cancelTokenRef = (0, import_react.useRef)(0);
	const lastTriggerRef = (0, import_react.useRef)(null);
	(0, import_react.useEffect)(() => () => {
		cancelTokenRef.current++;
	}, []);
	const cancelRun = () => {
		cancelTokenRef.current++;
		setBusy(null);
		setStatus("Canceled");
		requestAnimationFrame(() => lastTriggerRef.current?.focus());
	};
	const download = makeDownloader(setStatus);
	const rememberTrigger = (e) => {
		const t = e.target.closest("button");
		if (t) lastTriggerRef.current = t;
	};
	const [splitFile, setSplitFile] = (0, import_react.useState)(null);
	const [pwFile, setPwFile] = (0, import_react.useState)(null);
	const [pw, setPw] = (0, import_react.useState)("");
	const [rotFile, setRotFile] = (0, import_react.useState)(null);
	const [rotDeg, setRotDeg] = (0, import_react.useState)(90);
	const [reFile, setReFile] = (0, import_react.useState)(null);
	const [reOrder, setReOrder] = (0, import_react.useState)("");
	const [cpFile, setCpFile] = (0, import_react.useState)(null);
	const [rmFile, setRmFile] = (0, import_react.useState)(null);
	const [rmPages, setRmPages] = (0, import_react.useState)("");
	const [exFile, setExFile] = (0, import_react.useState)(null);
	const [exPages, setExPages] = (0, import_react.useState)("");
	const [imgFiles, setImgFiles] = (0, import_react.useState)([]);
	const [p2jFile, setP2jFile] = (0, import_react.useState)(null);
	const [pnFile, setPnFile] = (0, import_react.useState)(null);
	const [wmFile, setWmFile] = (0, import_react.useState)(null);
	const [wmText, setWmText] = (0, import_react.useState)("CONFIDENTIAL");
	const [crFile, setCrFile] = (0, import_react.useState)(null);
	const [crMargin, setCrMargin] = (0, import_react.useState)(36);
	const [unFile, setUnFile] = (0, import_react.useState)(null);
	const [unPw, setUnPw] = (0, import_react.useState)("");
	const doMerge = async () => {
		trackUse("pdf-merge");
		if (mergeFiles.length < 2) return alert("Choose at least 2 PDFs");
		const tk = ++cancelTokenRef.current;
		setBusy("merge");
		setStatus("Processing started");
		try {
			const out = await PDFDocument.create();
			for (const f of mergeFiles) {
				const src = await PDFDocument.load(await f.arrayBuffer());
				(await out.copyPages(src, src.getPageIndices())).forEach((p) => out.addPage(p));
			}
			download(await out.save(), "merged.pdf");
		} catch (err) {
			if (tk === cancelTokenRef.current) setStatus("Operation failed");
			throw err;
		} finally {
			if (tk === cancelTokenRef.current) {
				setBusy(null);
				setStatus((s) => s === "Canceled" || s.startsWith("Download") ? s : "Operation complete");
			}
			requestAnimationFrame(() => lastTriggerRef.current?.focus());
		}
	};
	const doSplit = async () => {
		trackUse("pdf-split");
		if (!splitFile) return;
		const tk = ++cancelTokenRef.current;
		setBusy("split");
		setStatus("Processing started");
		try {
			const src = await PDFDocument.load(await splitFile.arrayBuffer());
			for (let i = 0; i < src.getPageCount(); i++) {
				const out = await PDFDocument.create();
				const [p] = await out.copyPages(src, [i]);
				out.addPage(p);
				download(await out.save(), `page-${i + 1}.pdf`);
			}
		} catch (err) {
			if (tk === cancelTokenRef.current) setStatus("Operation failed");
			throw err;
		} finally {
			if (tk === cancelTokenRef.current) {
				setBusy(null);
				setStatus((s) => s === "Canceled" || s.startsWith("Download") ? s : "Operation complete");
			}
			requestAnimationFrame(() => lastTriggerRef.current?.focus());
		}
	};
	const doRotate = async () => {
		trackUse("pdf-rotate");
		if (!rotFile) return;
		const tk = ++cancelTokenRef.current;
		setBusy("rot");
		setStatus("Processing started");
		try {
			const src = await PDFDocument.load(await rotFile.arrayBuffer());
			src.getPages().forEach((p) => p.setRotation(degrees(rotDeg)));
			download(await src.save(), `rotated-${rotDeg}.pdf`);
		} catch (err) {
			if (tk === cancelTokenRef.current) setStatus("Operation failed");
			throw err;
		} finally {
			if (tk === cancelTokenRef.current) {
				setBusy(null);
				setStatus((s) => s === "Canceled" || s.startsWith("Download") ? s : "Operation complete");
			}
			requestAnimationFrame(() => lastTriggerRef.current?.focus());
		}
	};
	const doReorder = async () => {
		trackUse("pdf-reorder");
		if (!reFile || !reOrder.trim()) return;
		const tk = ++cancelTokenRef.current;
		setBusy("re");
		setStatus("Processing started");
		try {
			const src = await PDFDocument.load(await reFile.arrayBuffer());
			const total = src.getPageCount();
			const order = reOrder.split(",").map((s) => parseInt(s.trim(), 10) - 1).filter((n) => n >= 0 && n < total);
			if (!order.length) return alert("Invalid order");
			const out = await PDFDocument.create();
			(await out.copyPages(src, order)).forEach((p) => out.addPage(p));
			download(await out.save(), "reordered.pdf");
		} catch (err) {
			if (tk === cancelTokenRef.current) setStatus("Operation failed");
			throw err;
		} finally {
			if (tk === cancelTokenRef.current) {
				setBusy(null);
				setStatus((s) => s === "Canceled" || s.startsWith("Download") ? s : "Operation complete");
			}
			requestAnimationFrame(() => lastTriggerRef.current?.focus());
		}
	};
	const doCompress = async () => {
		trackUse("pdf-compress");
		if (!cpFile) return;
		const tk = ++cancelTokenRef.current;
		setBusy("cp");
		setStatus("Processing started");
		try {
			const bytes = await (await PDFDocument.load(await cpFile.arrayBuffer())).save({ useObjectStreams: true });
			download(bytes, "compressed.pdf");
		} catch (err) {
			if (tk === cancelTokenRef.current) setStatus("Operation failed");
			throw err;
		} finally {
			if (tk === cancelTokenRef.current) {
				setBusy(null);
				setStatus((s) => s === "Canceled" || s.startsWith("Download") ? s : "Operation complete");
			}
			requestAnimationFrame(() => lastTriggerRef.current?.focus());
		}
	};
	const parsePageList = (input, total) => {
		const out = /* @__PURE__ */ new Set();
		input.split(",").map((s) => s.trim()).filter(Boolean).forEach((part) => {
			const m = part.match(/^(\d+)\s*-\s*(\d+)$/);
			if (m) {
				const a = Math.max(1, parseInt(m[1], 10));
				const b = Math.min(total, parseInt(m[2], 10));
				for (let i = a; i <= b; i++) out.add(i - 1);
			} else {
				const n = parseInt(part, 10);
				if (n >= 1 && n <= total) out.add(n - 1);
			}
		});
		return [...out].sort((a, b) => a - b);
	};
	const doRemove = async () => {
		trackUse("pdf-remove-pages");
		if (!rmFile || !rmPages.trim()) return;
		const tk = ++cancelTokenRef.current;
		setBusy("rm");
		setStatus("Processing started");
		try {
			const src = await PDFDocument.load(await rmFile.arrayBuffer());
			const total = src.getPageCount();
			const remove = new Set(parsePageList(rmPages, total));
			if (!remove.size) return alert("No valid pages");
			const keep = Array.from({ length: total }, (_, i) => i).filter((i) => !remove.has(i));
			if (!keep.length) return alert("Cannot remove every page");
			const out = await PDFDocument.create();
			(await out.copyPages(src, keep)).forEach((p) => out.addPage(p));
			download(await out.save(), "pages-removed.pdf");
		} catch (err) {
			if (tk === cancelTokenRef.current) setStatus("Operation failed");
			throw err;
		} finally {
			if (tk === cancelTokenRef.current) {
				setBusy(null);
				setStatus((s) => s === "Canceled" || s.startsWith("Download") ? s : "Operation complete");
			}
			requestAnimationFrame(() => lastTriggerRef.current?.focus());
		}
	};
	const doExtract = async () => {
		trackUse("pdf-extract-pages");
		if (!exFile || !exPages.trim()) return;
		const tk = ++cancelTokenRef.current;
		setBusy("ex");
		setStatus("Processing started");
		try {
			const src = await PDFDocument.load(await exFile.arrayBuffer());
			const total = src.getPageCount();
			const idx = parsePageList(exPages, total);
			if (!idx.length) return alert("No valid pages");
			const out = await PDFDocument.create();
			(await out.copyPages(src, idx)).forEach((p) => out.addPage(p));
			download(await out.save(), "extracted.pdf");
		} catch (err) {
			if (tk === cancelTokenRef.current) setStatus("Operation failed");
			throw err;
		} finally {
			if (tk === cancelTokenRef.current) {
				setBusy(null);
				setStatus((s) => s === "Canceled" || s.startsWith("Download") ? s : "Operation complete");
			}
			requestAnimationFrame(() => lastTriggerRef.current?.focus());
		}
	};
	const doImagesToPdf = async () => {
		trackUse("pdf-jpg-to-pdf");
		if (!imgFiles.length) return;
		const tk = ++cancelTokenRef.current;
		setBusy("img");
		setStatus("Processing started");
		try {
			const out = await PDFDocument.create();
			for (const f of imgFiles) {
				const bytes = new Uint8Array(await f.arrayBuffer());
				const img = f.type.includes("png") || f.name.toLowerCase().endsWith(".png") ? await out.embedPng(bytes) : await out.embedJpg(bytes);
				out.addPage([img.width, img.height]).drawImage(img, {
					x: 0,
					y: 0,
					width: img.width,
					height: img.height
				});
			}
			download(await out.save(), "images.pdf");
		} catch (e) {
			if (tk === cancelTokenRef.current) setStatus("Operation failed");
			alert("Image conversion failed. Use standard JPG or PNG files.");
		} finally {
			if (tk === cancelTokenRef.current) {
				setBusy(null);
				setStatus((s) => s === "Canceled" || s.startsWith("Download") ? s : "Operation complete");
			}
			requestAnimationFrame(() => lastTriggerRef.current?.focus());
		}
	};
	const doPdfToJpg = async () => {
		trackUse("pdf-to-jpg");
		if (!p2jFile) return;
		const tk = ++cancelTokenRef.current;
		setBusy("p2j");
		setStatus("Processing started");
		try {
			const pdfjs = await import("../_libs/pdfjs-dist.mjs").then((n) => n.t);
			const worker = await import("./pdf.worker.min-Be_rUMwQ.mjs");
			pdfjs.GlobalWorkerOptions.workerSrc = worker.default;
			const data = await p2jFile.arrayBuffer();
			const doc = await pdfjs.getDocument({ data }).promise;
			for (let i = 1; i <= doc.numPages; i++) {
				const page = await doc.getPage(i);
				const viewport = page.getViewport({ scale: 2 });
				const canvas = document.createElement("canvas");
				canvas.width = viewport.width;
				canvas.height = viewport.height;
				const ctx = canvas.getContext("2d");
				await page.render({
					canvasContext: ctx,
					viewport,
					canvas
				}).promise;
				const url = canvas.toDataURL("image/jpeg", .92);
				const name = `page-${i}.jpg`;
				setStatus(`Download in progress: ${name} (page ${i} of ${doc.numPages})`);
				const a = document.createElement("a");
				a.href = url;
				a.download = name;
				a.click();
				setStatus(`Download completed: ${name}`);
			}
		} catch (e) {
			if (tk === cancelTokenRef.current) setStatus("Operation failed");
			alert("Render failed: " + e.message);
		} finally {
			if (tk === cancelTokenRef.current) {
				setBusy(null);
				setStatus((s) => s === "Canceled" || s.startsWith("Download") ? s : "Operation complete");
			}
			requestAnimationFrame(() => lastTriggerRef.current?.focus());
		}
	};
	const doPageNumbers = async () => {
		trackUse("pdf-page-numbers");
		if (!pnFile) return;
		const tk = ++cancelTokenRef.current;
		setBusy("pn");
		setStatus("Processing started");
		try {
			const src = await PDFDocument.load(await pnFile.arrayBuffer());
			const font = await src.embedFont(StandardFonts.Helvetica);
			const pages = src.getPages();
			pages.forEach((p, i) => {
				const { width } = p.getSize();
				const text = `${i + 1} / ${pages.length}`;
				const size = 10;
				const tw = font.widthOfTextAtSize(text, size);
				p.drawText(text, {
					x: width / 2 - tw / 2,
					y: 18,
					size,
					font,
					color: rgb(.3, .3, .3)
				});
			});
			download(await src.save(), "numbered.pdf");
		} catch (err) {
			if (tk === cancelTokenRef.current) setStatus("Operation failed");
			throw err;
		} finally {
			if (tk === cancelTokenRef.current) {
				setBusy(null);
				setStatus((s) => s === "Canceled" || s.startsWith("Download") ? s : "Operation complete");
			}
			requestAnimationFrame(() => lastTriggerRef.current?.focus());
		}
	};
	const doWatermark = async () => {
		trackUse("pdf-watermark");
		if (!wmFile || !wmText.trim()) return;
		const tk = ++cancelTokenRef.current;
		setBusy("wm");
		setStatus("Processing started");
		try {
			const src = await PDFDocument.load(await wmFile.arrayBuffer());
			const font = await src.embedFont(StandardFonts.HelveticaBold);
			src.getPages().forEach((p) => {
				const { width, height } = p.getSize();
				const size = Math.min(width, height) / 8;
				const tw = font.widthOfTextAtSize(wmText, size);
				p.drawText(wmText, {
					x: width / 2 - tw / 2,
					y: height / 2 - size / 2,
					size,
					font,
					color: rgb(.85, .1, .1),
					opacity: .25,
					rotate: degrees(-30)
				});
			});
			download(await src.save(), "watermarked.pdf");
		} catch (err) {
			if (tk === cancelTokenRef.current) setStatus("Operation failed");
			throw err;
		} finally {
			if (tk === cancelTokenRef.current) {
				setBusy(null);
				setStatus((s) => s === "Canceled" || s.startsWith("Download") ? s : "Operation complete");
			}
			requestAnimationFrame(() => lastTriggerRef.current?.focus());
		}
	};
	const doCrop = async () => {
		trackUse("pdf-crop");
		if (!crFile) return;
		const tk = ++cancelTokenRef.current;
		setBusy("cr");
		setStatus("Processing started");
		try {
			const src = await PDFDocument.load(await crFile.arrayBuffer());
			src.getPages().forEach((p) => {
				const { width, height } = p.getSize();
				const m = Math.max(0, Math.min(crMargin, Math.min(width, height) / 2 - 10));
				p.setCropBox(m, m, width - 2 * m, height - 2 * m);
			});
			download(await src.save(), "cropped.pdf");
		} catch (err) {
			if (tk === cancelTokenRef.current) setStatus("Operation failed");
			throw err;
		} finally {
			if (tk === cancelTokenRef.current) {
				setBusy(null);
				setStatus((s) => s === "Canceled" || s.startsWith("Download") ? s : "Operation complete");
			}
			requestAnimationFrame(() => lastTriggerRef.current?.focus());
		}
	};
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Layout, { children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("section", {
		className: "mx-auto max-w-5xl px-4 py-12 sm:px-6",
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Reveal, { children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("header", {
				className: "mb-8",
				children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
						className: "text-sm font-semibold uppercase tracking-wider text-blue-600",
						children: "PDF tools"
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h1", {
						className: "mt-1 text-3xl font-bold text-slate-900 sm:text-4xl dark:text-white",
						style: { fontFamily: "'Space Grotesk', sans-serif" },
						children: "Edit PDFs without uploading"
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
						className: "mt-2 text-slate-600 dark:text-slate-400",
						children: "Everything runs in your browser. Files never leave your device."
					})
				]
			}) }),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)(MostUsedPdfTools, {}),
			banner,
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
				role: "status",
				"aria-live": "polite",
				className: "sr-only",
				children: status
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "grid gap-5 lg:grid-cols-2",
				onClickCapture: (e) => {
					guardClick(e);
					if (!e.defaultPrevented) rememberTrigger(e);
				},
				children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(SectionHeader, {
						id: "organize",
						kicker: "Organize",
						title: "Organize PDF",
						desc: "Merge, split, rearrange and clean up pages."
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Card, {
						busy: busy === "merge",
						onCancel: cancelRun,
						onClear: () => {
							setMergeFiles([]);
							const el = document.getElementById("pdf-merge-in");
							if (el) el.value = "";
						},
						canClear: mergeFiles.length > 0,
						id: "merge",
						toolId: "pdf-merge",
						title: "Merge PDFs",
						desc: "Combine multiple PDFs into one.",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
							id: "pdf-merge-in",
							type: "file",
							accept: "application/pdf",
							multiple: true,
							onChange: (e) => setMergeFiles(Array.from(e.target.files ?? [])),
							className: inputCls
						}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
							onClick: doMerge,
							disabled: busy !== null,
							className: btnCls,
							children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(BtnLabel, {
								busy: busy === "merge",
								idle: "Merge & download",
								working: "Merging…"
							})
						})]
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Card, {
						busy: busy === "split",
						onCancel: cancelRun,
						onClear: () => {
							setSplitFile(null);
							const el = document.getElementById("pdf-split-in");
							if (el) el.value = "";
						},
						canClear: !!splitFile,
						id: "split",
						toolId: "pdf-split",
						title: "Split PDF",
						desc: "Split a PDF into one file per page.",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
							id: "pdf-split-in",
							type: "file",
							accept: "application/pdf",
							onChange: (e) => setSplitFile(e.target.files?.[0] ?? null),
							className: inputCls
						}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
							onClick: doSplit,
							disabled: busy !== null,
							className: btnCls,
							children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(BtnLabel, {
								busy: busy === "split",
								idle: "Split",
								working: "Splitting…"
							})
						})]
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Card, {
						onClear: () => {
							setRotFile(null);
							const el = document.getElementById("pdf-rot-in");
							if (el) el.value = "";
						},
						canClear: !!rotFile,
						id: "rotate",
						toolId: "pdf-rotate",
						title: "Rotate PDF",
						desc: "Rotate every page.",
						children: [
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
								id: "pdf-rot-in",
								type: "file",
								accept: "application/pdf",
								onChange: (e) => setRotFile(e.target.files?.[0] ?? null),
								className: inputCls
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
								className: "mt-3 flex gap-2",
								children: [
									90,
									180,
									270
								].map((d) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("button", {
									onClick: () => setRotDeg(d),
									className: `rounded-lg border px-3 py-1.5 text-sm ${rotDeg === d ? "border-blue-500 bg-blue-50 text-blue-700 dark:bg-blue-950/60 dark:text-blue-300" : "border-slate-200 dark:border-slate-700"}`,
									children: [d, "°"]
								}, d))
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
								onClick: doRotate,
								disabled: busy !== null,
								className: btnCls,
								children: "Rotate"
							})
						]
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Card, {
						onClear: () => {
							setReFile(null);
							setReOrder("");
							const el = document.getElementById("pdf-re-in");
							if (el) el.value = "";
						},
						canClear: !!reFile || !!reOrder,
						id: "reorder",
						toolId: "pdf-reorder",
						title: "Reorder Pages",
						desc: "Enter the page order as comma-separated numbers (e.g. 3,1,2).",
						children: [
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
								id: "pdf-re-in",
								type: "file",
								accept: "application/pdf",
								onChange: (e) => setReFile(e.target.files?.[0] ?? null),
								className: inputCls
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
								value: reOrder,
								onChange: (e) => setReOrder(e.target.value),
								placeholder: "3,1,2",
								className: "mt-3 w-full rounded-lg border border-slate-200 bg-white px-3 py-2 text-sm dark:border-slate-700 dark:bg-slate-950 dark:text-white"
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
								onClick: doReorder,
								disabled: busy !== null,
								className: btnCls,
								children: "Reorder"
							})
						]
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Card, {
						busy: busy === "rm",
						onCancel: cancelRun,
						onClear: () => {
							setRmFile(null);
							setRmPages("");
							const el = document.getElementById("pdf-rm-in");
							if (el) el.value = "";
						},
						canClear: !!rmFile || !!rmPages,
						id: "remove-pages",
						toolId: "pdf-remove-pages",
						title: "Remove Pages",
						desc: "Delete specific pages. Use commas and ranges, e.g. 2,4-6.",
						children: [
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
								id: "pdf-rm-in",
								type: "file",
								accept: "application/pdf",
								onChange: (e) => setRmFile(e.target.files?.[0] ?? null),
								className: inputCls
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
								value: rmPages,
								onChange: (e) => setRmPages(e.target.value),
								placeholder: "2,4-6",
								className: "mt-3 w-full rounded-lg border border-slate-200 bg-white px-3 py-2 text-sm dark:border-slate-700 dark:bg-slate-950 dark:text-white"
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
								onClick: doRemove,
								disabled: busy !== null,
								className: btnCls,
								children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(BtnLabel, {
									busy: busy === "rm",
									idle: "Remove pages",
									working: "Removing…"
								})
							})
						]
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Card, {
						busy: busy === "ex",
						onCancel: cancelRun,
						onClear: () => {
							setExFile(null);
							setExPages("");
							const el = document.getElementById("pdf-ex-in");
							if (el) el.value = "";
						},
						canClear: !!exFile || !!exPages,
						id: "extract-pages",
						toolId: "pdf-extract-pages",
						title: "Extract Pages",
						desc: "Save selected pages as a new PDF.",
						children: [
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
								id: "pdf-ex-in",
								type: "file",
								accept: "application/pdf",
								onChange: (e) => setExFile(e.target.files?.[0] ?? null),
								className: inputCls
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
								value: exPages,
								onChange: (e) => setExPages(e.target.value),
								placeholder: "1,3-5",
								className: "mt-3 w-full rounded-lg border border-slate-200 bg-white px-3 py-2 text-sm dark:border-slate-700 dark:bg-slate-950 dark:text-white"
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
								onClick: doExtract,
								disabled: busy !== null,
								className: btnCls,
								children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(BtnLabel, {
									busy: busy === "ex",
									idle: "Extract",
									working: "Extracting…"
								})
							})
						]
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Card, {
						onClear: () => {
							setCpFile(null);
							const el = document.getElementById("pdf-cp-in");
							if (el) el.value = "";
						},
						canClear: !!cpFile,
						id: "compress",
						toolId: "pdf-compress",
						title: "Compress PDF",
						desc: "Basic recompression using object streams.",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
							id: "pdf-cp-in",
							type: "file",
							accept: "application/pdf",
							onChange: (e) => setCpFile(e.target.files?.[0] ?? null),
							className: inputCls
						}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
							onClick: doCompress,
							disabled: busy !== null,
							className: btnCls,
							children: "Compress"
						})]
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Card, {
						busy: busy === "pn",
						onCancel: cancelRun,
						onClear: () => {
							setPnFile(null);
							const el = document.getElementById("pdf-pn-in");
							if (el) el.value = "";
						},
						canClear: !!pnFile,
						id: "page-numbers",
						toolId: "pdf-page-numbers",
						title: "Add Page Numbers",
						desc: "Add centered footer page numbers to every page.",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
							id: "pdf-pn-in",
							type: "file",
							accept: "application/pdf",
							onChange: (e) => setPnFile(e.target.files?.[0] ?? null),
							className: inputCls
						}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
							onClick: doPageNumbers,
							disabled: busy !== null,
							className: btnCls,
							children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(BtnLabel, {
								busy: busy === "pn",
								idle: "Add numbers",
								working: "Adding…"
							})
						})]
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Card, {
						busy: busy === "wm",
						onCancel: cancelRun,
						onClear: () => {
							setWmFile(null);
							const el = document.getElementById("pdf-wm-in");
							if (el) el.value = "";
						},
						canClear: !!wmFile,
						id: "watermark",
						toolId: "pdf-watermark",
						title: "Add Watermark",
						desc: "Stamp a diagonal text watermark on every page.",
						children: [
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
								id: "pdf-wm-in",
								type: "file",
								accept: "application/pdf",
								onChange: (e) => setWmFile(e.target.files?.[0] ?? null),
								className: inputCls
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
								value: wmText,
								onChange: (e) => setWmText(e.target.value),
								placeholder: "CONFIDENTIAL",
								className: "mt-3 w-full rounded-lg border border-slate-200 bg-white px-3 py-2 text-sm dark:border-slate-700 dark:bg-slate-950 dark:text-white"
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
								onClick: doWatermark,
								disabled: busy !== null,
								className: btnCls,
								children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(BtnLabel, {
									busy: busy === "wm",
									idle: "Add watermark",
									working: "Stamping…"
								})
							})
						]
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Card, {
						busy: busy === "cr",
						onCancel: cancelRun,
						onClear: () => {
							setCrFile(null);
							const el = document.getElementById("pdf-cr-in");
							if (el) el.value = "";
						},
						canClear: !!crFile,
						id: "crop",
						toolId: "pdf-crop",
						title: "Crop PDF",
						desc: "Trim margins from every page (in points; 72pt = 1 inch).",
						children: [
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
								id: "pdf-cr-in",
								type: "file",
								accept: "application/pdf",
								onChange: (e) => setCrFile(e.target.files?.[0] ?? null),
								className: inputCls
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
								type: "number",
								min: 0,
								value: crMargin,
								onChange: (e) => setCrMargin(parseInt(e.target.value || "0", 10)),
								placeholder: "36",
								className: "mt-3 w-full rounded-lg border border-slate-200 bg-white px-3 py-2 text-sm dark:border-slate-700 dark:bg-slate-950 dark:text-white"
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
								onClick: doCrop,
								disabled: busy !== null,
								className: btnCls,
								children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(BtnLabel, {
									busy: busy === "cr",
									idle: "Crop",
									working: "Cropping…"
								})
							})
						]
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(SectionHeader, {
						id: "convert-to-pdf",
						kicker: "Convert to PDF",
						title: "Convert to PDF",
						desc: "Turn images and Office documents into PDF files."
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Card, {
						busy: busy === "img",
						onCancel: cancelRun,
						onClear: () => {
							setImgFiles([]);
							const el = document.getElementById("pdf-img-in");
							if (el) el.value = "";
						},
						canClear: imgFiles.length > 0,
						id: "jpg-to-pdf",
						toolId: "pdf-jpg-to-pdf",
						title: "JPG / PNG to PDF",
						desc: "Combine images into a single PDF.",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
							id: "pdf-img-in",
							type: "file",
							accept: "image/jpeg,image/png",
							multiple: true,
							onChange: (e) => setImgFiles(Array.from(e.target.files ?? [])),
							className: inputCls
						}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
							onClick: doImagesToPdf,
							disabled: busy !== null,
							className: btnCls,
							children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(BtnLabel, {
								busy: busy === "img",
								idle: "Build PDF",
								working: "Converting…"
							})
						})]
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(WordToPdfCard, {}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(ExcelToPdfCard, {}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(ComingSoonCard, {
						id: "powerpoint-to-pdf",
						title: "PowerPoint to PDF",
						desc: "Convert .pptx presentations into a PDF. Requires a server for accurate slide rendering — coming soon."
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(HtmlToPdfCard, {}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(SectionHeader, {
						id: "convert-from-pdf",
						kicker: "Convert from PDF",
						title: "Convert from PDF",
						desc: "Export a PDF to images or editable Office formats."
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Card, {
						busy: busy === "p2j",
						onCancel: cancelRun,
						onClear: () => {
							setP2jFile(null);
							const el = document.getElementById("pdf-p2j-in");
							if (el) el.value = "";
						},
						canClear: !!p2jFile,
						id: "pdf-to-jpg",
						toolId: "pdf-to-jpg",
						title: "PDF to JPG",
						desc: "Export each page as a high-quality JPG image.",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
							id: "pdf-p2j-in",
							type: "file",
							accept: "application/pdf",
							onChange: (e) => setP2jFile(e.target.files?.[0] ?? null),
							className: inputCls
						}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
							onClick: doPdfToJpg,
							disabled: busy !== null,
							className: btnCls,
							children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(BtnLabel, {
								busy: busy === "p2j",
								idle: "Convert",
								working: "Rendering…"
							})
						})]
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(PdfToWordCard, {}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(PdfToExcelCard, {}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(ComingSoonCard, {
						id: "pdf-to-powerpoint",
						title: "PDF to PowerPoint",
						desc: "Turn a PDF into an editable .pptx presentation. Needs a server for real slide reconstruction — coming soon."
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(ComingSoonCard, {
						id: "pdf-to-pdfa",
						title: "PDF to PDF/A",
						desc: "Convert to the ISO PDF/A archival standard. Requires font-embedding validation and ICC profiles that only a server can produce — coming soon."
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(SectionHeader, {
						id: "security",
						kicker: "Security & Review",
						title: "Security & Review",
						desc: "Protect, sign, redact and compare PDFs."
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(PremiumCard, {
						id: "protect",
						title: "Protect PDF",
						desc: "Add a strong password and encryption to a PDF."
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(PremiumCard, {
						id: "unlock",
						title: "Unlock PDF",
						desc: "Remove a password from a PDF you own."
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(SignPdfCard, {}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(RedactPdfCard, {}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(ComparePdfCard, {})
				]
			})
		]
	}) });
}
//#endregion
export { PdfTools as component };
