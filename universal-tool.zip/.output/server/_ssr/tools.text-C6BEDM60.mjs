import { o as __toESM } from "../_runtime.mjs";
import { nt as require_react } from "../_libs/@hookform/resolvers+[...].mjs";
import { r as require_jsx_runtime } from "../_libs/react+tanstack__react-query.mjs";
import { n as Layout } from "./Layout-8Jn4q3kq.mjs";
import { t as Reveal } from "./Reveal-CydLpVW7.mjs";
import { o as trackUse } from "./usage-tracking-C1qv9W3k.mjs";
import { r as SkeletonLines } from "./Skeleton-C9Gtenx-.mjs";
import { n as DownloadButton, t as CopyButton } from "./CopyDownload-BgPQcrMS.mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/tools.text-C6BEDM60.js
var import_react = /* @__PURE__ */ __toESM(require_react());
var import_jsx_runtime = require_jsx_runtime();
function titleCase(s) {
	return s.toLowerCase().replace(/\b\w/g, (c) => c.toUpperCase());
}
function sentenceCase(s) {
	return s.toLowerCase().replace(/(^|[.!?]\s+)([a-z])/g, (_, p, c) => p + c.toUpperCase());
}
function safeBtoa(s) {
	try {
		return btoa(unescape(encodeURIComponent(s)));
	} catch {
		return "";
	}
}
function safeAtob(s) {
	try {
		return decodeURIComponent(escape(atob(s)));
	} catch {
		return "Invalid base64";
	}
}
function safeUrlDecode(s) {
	try {
		return decodeURIComponent(s);
	} catch {
		return s;
	}
}
function slugify(s) {
	return s.toLowerCase().trim().replace(/[^\w\s-]/g, "").replace(/[\s_-]+/g, "-").replace(/^-+|-+$/g, "");
}
function Section({ id, title, children }) {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Reveal, {
		as: "section",
		children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("section", {
			id,
			className: "scroll-mt-32 rounded-2xl border border-slate-200 bg-white p-6 shadow-sm dark:border-slate-800 dark:bg-slate-900",
			children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
				className: "flex items-start justify-between gap-3",
				children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("h2", {
					className: "text-xl font-bold text-slate-900 dark:text-white",
					style: { fontFamily: "'Space Grotesk', sans-serif" },
					children: title
				})
			}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
				className: "mt-4",
				children
			})]
		})
	});
}
function Btn({ children, ...p }) {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
		...p,
		className: `rounded-lg border border-slate-200 bg-white px-3 py-1.5 text-sm font-medium text-slate-700 transition hover:border-blue-500 hover:text-blue-700 dark:border-slate-700 dark:bg-slate-950 dark:text-slate-200 dark:hover:border-blue-400 ${p.className ?? ""}`,
		children
	});
}
function rot13(s) {
	return s.replace(/[a-zA-Z]/g, (c) => {
		const base = c <= "Z" ? 65 : 97;
		return String.fromCharCode((c.charCodeAt(0) - base + 13) % 26 + base);
	});
}
function textToBinary(s) {
	return Array.from(s).map((c) => c.charCodeAt(0).toString(2).padStart(8, "0")).join(" ");
}
function binaryToText(s) {
	return s.trim().split(/\s+/).map((b) => String.fromCharCode(parseInt(b, 2))).join("");
}
function lineDiff(a, b) {
	const A = a.split("\n"), B = b.split("\n");
	const max = Math.max(A.length, B.length);
	const out = [];
	for (let i = 0; i < max; i++) if (A[i] === B[i]) out.push({
		sign: "=",
		line: A[i] ?? ""
	});
	else {
		if (A[i] !== void 0) out.push({
			sign: "-",
			line: A[i]
		});
		if (B[i] !== void 0) out.push({
			sign: "+",
			line: B[i]
		});
	}
	return out;
}
function WordFrequency({ text }) {
	const top = (0, import_react.useMemo)(() => {
		const map = /* @__PURE__ */ new Map();
		text.toLowerCase().split(/[^a-z0-9']+/i).filter(Boolean).forEach((w) => map.set(w, (map.get(w) ?? 0) + 1));
		return [...map.entries()].sort((a, b) => b[1] - a[1]).slice(0, 20);
	}, [text]);
	if (!top.length) return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
		className: "text-sm text-slate-500",
		children: "No words yet."
	});
	const max = top[0][1];
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("ul", {
		className: "space-y-1.5",
		children: top.map(([w, n]) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("li", {
			className: "flex items-center gap-3 text-sm",
			children: [
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
					className: "w-32 truncate font-mono text-slate-700 dark:text-slate-200",
					children: w
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
					className: "relative h-2 flex-1 overflow-hidden rounded-full bg-slate-100 dark:bg-slate-800",
					children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
						className: "absolute inset-y-0 left-0 rounded-full bg-blue-500",
						style: { width: `${n / max * 100}%` }
					})
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
					className: "w-10 text-right text-xs font-semibold text-slate-500",
					children: n
				})
			]
		}, w))
	});
}
function TextTools() {
	const [text, setText] = (0, import_react.useState)("Type or paste text here. The Universal Text Toolkit gives you instant counts, transforms, cleaning utilities, and encoders — all in one place.");
	const [findStr, setFindStr] = (0, import_react.useState)("");
	const [replStr, setReplStr] = (0, import_react.useState)("");
	const [useRe, setUseRe] = (0, import_react.useState)(false);
	const [repN, setRepN] = (0, import_react.useState)(3);
	const [diffB, setDiffB] = (0, import_react.useState)("");
	const [computing, setComputing] = (0, import_react.useState)(false);
	const [status, setStatus] = (0, import_react.useState)("");
	(0, import_react.useEffect)(() => {
		trackUse("word-count");
	}, []);
	const cancelTokenRef = (0, import_react.useRef)(0);
	(0, import_react.useEffect)(() => {
		const ac = new AbortController();
		const myToken = ++cancelTokenRef.current;
		setComputing(true);
		const t = setTimeout(() => {
			if (ac.signal.aborted || myToken !== cancelTokenRef.current) return;
			setComputing(false);
			setStatus("Results updated");
		}, 200);
		return () => {
			ac.abort();
			clearTimeout(t);
		};
	}, [text, diffB]);
	(0, import_react.useEffect)(() => {
		return () => {
			cancelTokenRef.current++;
		};
	}, []);
	const cancelCompute = () => {
		cancelTokenRef.current++;
		setComputing(false);
		setStatus("Canceled");
		requestAnimationFrame(() => document.getElementById("ta")?.focus());
	};
	const stats = (0, import_react.useMemo)(() => {
		const t = text;
		const words = t.trim() ? t.trim().split(/\s+/).length : 0;
		const chars = t.length;
		const charsNoSpace = t.replace(/\s/g, "").length;
		const sentences = t.split(/[.!?]+\s/).filter(Boolean).length;
		const paragraphs = t.split(/\n\s*\n/).filter((p) => p.trim()).length;
		const totalSec = Math.round(words / 220 * 60);
		return {
			words,
			chars,
			charsNoSpace,
			sentences,
			paragraphs,
			readTime: totalSec < 60 ? `${totalSec}s` : `${Math.floor(totalSec / 60)}m ${totalSec % 60}s`
		};
	}, [text]);
	const apply = (id, fn) => {
		setText((t) => fn(t));
		trackUse(id);
		setStatus("Applied");
	};
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Layout, { children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("section", {
		className: "mx-auto max-w-5xl px-4 py-12 sm:px-6",
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Reveal, { children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("header", {
				className: "mb-8",
				children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
						className: "text-sm font-semibold uppercase tracking-wider text-blue-600",
						children: "Text tools"
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h1", {
						className: "mt-1 text-3xl font-bold text-slate-900 sm:text-4xl dark:text-white",
						style: { fontFamily: "'Space Grotesk', sans-serif" },
						children: "The all-in-one text workbench"
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
						className: "mt-2 text-slate-600 dark:text-slate-400",
						children: "Edit once. Count, transform, clean and encode — instantly."
					})
				]
			}) }),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Reveal, {
				delay: .05,
				children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "relative",
					children: [
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("label", {
							htmlFor: "ta",
							className: "sr-only",
							children: "Editor"
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("textarea", {
							id: "ta",
							value: text,
							onChange: (e) => setText(e.target.value),
							rows: 10,
							className: "w-full rounded-2xl border border-slate-200 bg-white p-4 pr-24 font-mono text-sm leading-relaxed text-slate-900 outline-none focus:border-blue-500 focus:ring-4 focus:ring-blue-500/15 dark:border-slate-800 dark:bg-slate-900 dark:text-slate-100",
							placeholder: "Paste your text…"
						}),
						text && /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("button", {
							type: "button",
							onClick: () => {
								setText("");
								requestAnimationFrame(() => document.getElementById("ta")?.focus());
							},
							"aria-label": "Clear text",
							className: "absolute right-3 top-3 inline-flex items-center gap-1 rounded-lg border border-slate-200 bg-white/90 px-2.5 py-1 text-xs font-semibold text-slate-600 shadow-sm transition hover:border-rose-300 hover:text-rose-600 dark:border-slate-700 dark:bg-slate-950/80 dark:text-slate-300",
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("svg", {
								viewBox: "0 0 24 24",
								className: "h-3.5 w-3.5",
								fill: "none",
								stroke: "currentColor",
								strokeWidth: "2",
								"aria-hidden": "true",
								children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("path", { d: "M18 6 6 18M6 6l12 12" })
							}), "Clear"]
						})
					]
				})
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "mt-3 flex items-center justify-between gap-3",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
					role: "status",
					"aria-live": "polite",
					className: "text-xs text-slate-500 dark:text-slate-400",
					children: computing ? "Recomputing results…" : status
				}), computing && /* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
					type: "button",
					onClick: cancelCompute,
					"aria-label": "Cancel current text processing",
					className: "rounded-lg border border-rose-300 bg-white px-3 py-1 text-xs font-semibold text-rose-700 transition hover:bg-rose-50 dark:border-rose-800 dark:bg-slate-900 dark:text-rose-300 dark:hover:bg-rose-950/40",
					children: "Cancel"
				})]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "mt-8 grid gap-6",
				children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Section, {
						id: "word-count",
						toolId: "word-count",
						title: "Counts & reading time",
						children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
							"aria-live": "polite",
							"aria-atomic": "false",
							children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
								className: "grid grid-cols-2 gap-3 sm:grid-cols-3 lg:grid-cols-6",
								children: [
									["Words", stats.words],
									["Characters", stats.chars],
									["No spaces", stats.charsNoSpace],
									["Sentences", stats.sentences],
									["Paragraphs", stats.paragraphs],
									["Read time", stats.readTime]
								].map(([k, v]) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
									className: "rounded-xl bg-blue-50 p-3 text-center dark:bg-blue-950/40",
									children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
										className: "text-2xl font-bold tabular-nums text-blue-700 dark:text-blue-300",
										children: v
									}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
										className: "text-xs font-medium text-slate-600 dark:text-slate-400",
										children: k
									})]
								}, k))
							})
						})
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Section, {
						id: "transform",
						toolId: "uppercase",
						title: "Transform",
						children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
							className: "flex flex-wrap gap-2",
							children: [
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Btn, {
									onClick: () => apply("uppercase", (t) => t.toUpperCase()),
									children: "UPPERCASE"
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Btn, {
									onClick: () => apply("lowercase", (t) => t.toLowerCase()),
									children: "lowercase"
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Btn, {
									onClick: () => apply("title-case", titleCase),
									children: "Title Case"
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Btn, {
									onClick: () => apply("sentence-case", sentenceCase),
									children: "Sentence case"
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Btn, {
									onClick: () => apply("reverse", (t) => t.split("").reverse().join("")),
									children: "Reverse"
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Btn, {
									onClick: () => apply("reverse", (t) => t.split("").map((c) => c === c.toUpperCase() ? c.toLowerCase() : c.toUpperCase()).join("")),
									children: "iNVERT cASE"
								})
							]
						})
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Section, {
						id: "clean",
						toolId: "trim-spaces",
						title: "Clean",
						children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
							className: "flex flex-wrap gap-2",
							children: [
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Btn, {
									onClick: () => apply("trim-spaces", (t) => t.replace(/[ \t]+/g, " ").replace(/ +\n/g, "\n").trim()),
									children: "Remove extra spaces"
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Btn, {
									onClick: () => apply("remove-special", (t) => t.replace(/[^\w\s]|_/g, "")),
									children: "Remove special chars"
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Btn, {
									onClick: () => apply("remove-numbers", (t) => t.replace(/\d+/g, "")),
									children: "Remove numbers"
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Btn, {
									onClick: () => apply("remove-lines", (t) => t.replace(/^\s*$(?:\r\n?|\n)/gm, "")),
									children: "Remove empty lines"
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Btn, {
									onClick: () => apply("trim-spaces", (t) => t.replace(/\s+/g, "")),
									children: "Strip all whitespace"
								})
							]
						})
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Section, {
						id: "encode",
						toolId: "base64-encode",
						title: "Encode / Decode",
						children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
							className: "flex flex-wrap gap-2",
							children: [
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Btn, {
									onClick: () => apply("base64-encode", safeBtoa),
									children: "Base64 encode"
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Btn, {
									onClick: () => apply("base64-decode", safeAtob),
									children: "Base64 decode"
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Btn, {
									onClick: () => apply("url-encode", encodeURIComponent),
									children: "URL encode"
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Btn, {
									onClick: () => apply("url-encode", safeUrlDecode),
									children: "URL decode"
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Btn, {
									onClick: () => apply("slugify", slugify),
									children: "Slugify"
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Btn, {
									onClick: () => apply("rot13", rot13),
									children: "ROT13"
								})
							]
						})
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Section, {
						id: "find-replace",
						toolId: "find-replace",
						title: "Find & Replace",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
							className: "grid gap-3 sm:grid-cols-[1fr_1fr_auto]",
							children: [
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
									value: findStr,
									onChange: (e) => setFindStr(e.target.value),
									placeholder: "Find",
									className: "rounded-lg border border-slate-200 bg-white px-3 py-2 text-sm dark:border-slate-700 dark:bg-slate-950 dark:text-white"
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
									value: replStr,
									onChange: (e) => setReplStr(e.target.value),
									placeholder: "Replace with",
									className: "rounded-lg border border-slate-200 bg-white px-3 py-2 text-sm dark:border-slate-700 dark:bg-slate-950 dark:text-white"
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("label", {
									className: "flex items-center gap-2 text-sm text-slate-600 dark:text-slate-400",
									children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
										type: "checkbox",
										checked: useRe,
										onChange: (e) => setUseRe(e.target.checked)
									}), " Regex"]
								})
							]
						}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
							className: "mt-3 flex flex-wrap gap-2",
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Btn, {
								onClick: () => apply("find-replace", (t) => {
									if (!findStr) return t;
									try {
										const pattern = useRe ? new RegExp(findStr, "g") : new RegExp(findStr.replace(/[.*+?^${}()|[\]\\]/g, "\\$&"), "g");
										return t.replace(pattern, replStr);
									} catch {
										return t;
									}
								}),
								children: "Replace all"
							}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Btn, {
								onClick: () => apply("html-strip", (t) => t.replace(/<[^>]*>/g, "")),
								children: "Strip HTML"
							})]
						})]
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Section, {
						id: "repeat",
						toolId: "text-repeat",
						title: "Repeat Text",
						children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
							className: "flex flex-wrap items-center gap-3",
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("label", {
								className: "text-sm text-slate-600 dark:text-slate-400",
								children: ["Times ", /* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
									type: "number",
									min: 1,
									max: 1e3,
									value: repN,
									onChange: (e) => setRepN(Math.max(1, parseInt(e.target.value || "1", 10))),
									className: "ml-2 w-20 rounded border border-slate-200 px-2 py-1 dark:border-slate-700 dark:bg-slate-950"
								})]
							}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Btn, {
								onClick: () => apply("text-repeat", (t) => Array(repN).fill(t).join("\n")),
								children: "Repeat"
							})]
						})
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Section, {
						id: "binary",
						toolId: "binary-convert",
						title: "Text ↔ Binary",
						children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
							className: "flex flex-wrap gap-2",
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Btn, {
								onClick: () => apply("binary-convert", textToBinary),
								children: "Text → Binary"
							}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Btn, {
								onClick: () => apply("binary-convert", binaryToText),
								children: "Binary → Text"
							})]
						})
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Section, {
						id: "frequency",
						toolId: "word-frequency",
						title: "Word Frequency",
						children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
							"aria-busy": computing,
							"aria-live": "polite",
							children: computing ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)(SkeletonLines, { count: 5 }) : /* @__PURE__ */ (0, import_jsx_runtime.jsx)(WordFrequency, { text })
						})
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Section, {
						id: "diff",
						toolId: "text-diff",
						title: "Compare Two Texts",
						children: [
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
								className: "mb-2 text-xs text-slate-500 dark:text-slate-400",
								children: "Top text above is \"A\". Paste \"B\" below."
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("textarea", {
								value: diffB,
								onChange: (e) => setDiffB(e.target.value),
								rows: 5,
								placeholder: "Paste second text…",
								className: "w-full rounded-lg border border-slate-200 bg-white p-3 font-mono text-xs dark:border-slate-700 dark:bg-slate-950 dark:text-white"
							}),
							diffB && /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
								"aria-busy": computing,
								"aria-live": "polite",
								className: "mt-3",
								children: computing ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)(SkeletonLines, { count: 6 }) : /* @__PURE__ */ (0, import_jsx_runtime.jsx)("pre", {
									className: "max-h-72 overflow-auto rounded-lg border border-slate-200 bg-slate-50 p-3 font-mono text-xs dark:border-slate-700 dark:bg-slate-950",
									children: lineDiff(text, diffB).map((d, i) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
										className: d.sign === "+" ? "text-emerald-600 dark:text-emerald-400" : d.sign === "-" ? "text-rose-600 dark:text-rose-400" : "text-slate-500",
										children: [
											d.sign,
											" ",
											d.line
										]
									}, i))
								})
							})
						]
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Section, {
						id: "lines",
						toolId: "sort-lines",
						title: "Lines",
						children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
							className: "flex flex-wrap gap-2",
							children: [
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Btn, {
									onClick: () => apply("sort-lines", (t) => t.split("\n").sort((a, b) => a.localeCompare(b)).join("\n")),
									children: "Sort A→Z"
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Btn, {
									onClick: () => apply("sort-lines", (t) => t.split("\n").sort((a, b) => b.localeCompare(a)).join("\n")),
									children: "Sort Z→A"
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Btn, {
									onClick: () => apply("dedupe", (t) => Array.from(new Set(t.split("\n"))).join("\n")),
									children: "Deduplicate"
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Btn, {
									onClick: () => apply("sort-lines", (t) => t.split("\n").reverse().join("\n")),
									children: "Reverse lines"
								})
							]
						})
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "flex flex-wrap gap-2 rounded-2xl border border-slate-200 bg-white p-4 dark:border-slate-800 dark:bg-slate-900",
						children: [
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)(CopyButton, {
								getText: () => text,
								label: "Copy output",
								busy: computing
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)(DownloadButton, {
								getText: () => text,
								filename: "text.txt",
								label: "Download .txt",
								busy: computing
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Btn, {
								onClick: () => setText(""),
								children: "Clear"
							})
						]
					})
				]
			})
		]
	}) });
}
//#endregion
export { TextTools as component };
