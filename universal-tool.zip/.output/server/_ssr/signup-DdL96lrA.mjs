//#region node_modules/.nitro/vite/services/ssr/assets/signup-DdL96lrA.js
var SplitComponent = () => null;
//#endregion
export { SplitComponent as component };
