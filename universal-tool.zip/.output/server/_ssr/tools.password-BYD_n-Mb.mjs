import { o as __toESM } from "../_runtime.mjs";
import { nt as require_react } from "../_libs/@hookform/resolvers+[...].mjs";
import { r as require_jsx_runtime } from "../_libs/react+tanstack__react-query.mjs";
import { n as Layout } from "./Layout-8Jn4q3kq.mjs";
import { t as Reveal } from "./Reveal-CydLpVW7.mjs";
import { o as trackUse } from "./usage-tracking-C1qv9W3k.mjs";
import { n as DownloadButton, t as CopyButton } from "./CopyDownload-BgPQcrMS.mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/tools.password-BYD_n-Mb.js
var import_react = /* @__PURE__ */ __toESM(require_react());
var import_jsx_runtime = require_jsx_runtime();
function Card({ id, toolId, title, desc, children }) {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Reveal, {
		as: "section",
		children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("section", {
			id,
			className: "scroll-mt-32 rounded-2xl border border-slate-200 bg-white p-6 dark:border-slate-800 dark:bg-slate-900",
			children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
				className: "flex items-start justify-between gap-3",
				children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h2", {
					className: "text-lg font-bold text-slate-900 dark:text-white",
					style: { fontFamily: "'Space Grotesk', sans-serif" },
					children: title
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
					className: "mt-1 text-sm text-slate-600 dark:text-slate-400",
					children: desc
				})] })
			}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
				className: "mt-4",
				children
			})]
		})
	});
}
var runBtn = "inline-flex items-center rounded-lg bg-blue-600 px-4 py-2 text-sm font-semibold text-white transition hover:bg-blue-700";
var UPPER = "ABCDEFGHJKLMNPQRSTUVWXYZ";
var LOWER = "abcdefghijkmnpqrstuvwxyz";
var NUMS = "23456789";
var SYMS = "!@#$%^&*()-_=+[]{};:,.<>?/";
var AMBIG = "Il1O0";
function randPick(pool) {
	const a = /* @__PURE__ */ new Uint32Array(1);
	crypto.getRandomValues(a);
	return pool[a[0] % pool.length];
}
function scorePassword(pw) {
	if (!pw) return {
		score: 0,
		label: "Empty",
		hint: "Type a password to test",
		pct: 0,
		color: "bg-slate-300"
	};
	let s = 0;
	if (pw.length >= 8) s++;
	if (pw.length >= 12) s++;
	if (pw.length >= 16) s++;
	if (/[a-z]/.test(pw) && /[A-Z]/.test(pw)) s++;
	if (/\d/.test(pw)) s++;
	if (/[^A-Za-z0-9]/.test(pw)) s++;
	if (/(.)\1\1/.test(pw)) s = Math.max(0, s - 1);
	const out = [
		{
			label: "Very weak",
			color: "bg-red-500",
			pct: 15,
			hint: "Use at least 12 chars with mixed types."
		},
		{
			label: "Weak",
			color: "bg-orange-500",
			pct: 30,
			hint: "Add numbers and symbols."
		},
		{
			label: "Fair",
			color: "bg-amber-500",
			pct: 50,
			hint: "Lengthen it further."
		},
		{
			label: "Good",
			color: "bg-lime-500",
			pct: 70,
			hint: "Looking solid."
		},
		{
			label: "Strong",
			color: "bg-emerald-500",
			pct: 85,
			hint: "Great password."
		},
		{
			label: "Very strong",
			color: "bg-emerald-600",
			pct: 95,
			hint: "Excellent."
		},
		{
			label: "Excellent",
			color: "bg-blue-600",
			pct: 100,
			hint: "Top tier."
		}
	][Math.min(s, 6)];
	return {
		score: s,
		...out
	};
}
function PasswordTools() {
	const [length, setLength] = (0, import_react.useState)(20);
	const [upper, setUpper] = (0, import_react.useState)(true);
	const [lower, setLower] = (0, import_react.useState)(true);
	const [nums, setNums] = (0, import_react.useState)(true);
	const [syms, setSyms] = (0, import_react.useState)(true);
	const [excludeAmbig, setExcludeAmbig] = (0, import_react.useState)(true);
	const [customText, setCustomText] = (0, import_react.useState)("");
	const [customMode, setCustomMode] = (0, import_react.useState)("insert");
	const [generated, setGenerated] = (0, import_react.useState)("");
	const generate = () => {
		let pool = "";
		if (upper) pool += UPPER;
		if (lower) pool += LOWER;
		if (nums) pool += NUMS;
		if (syms) pool += SYMS;
		if (!excludeAmbig) pool += AMBIG;
		if (customMode === "pool" && customText) pool += customText;
		if (!pool) {
			setGenerated("");
			return;
		}
		if (customMode === "insert" && customText) {
			const remaining = Math.max(0, length - customText.length);
			let filler = "";
			for (let i = 0; i < remaining; i++) filler += randPick(pool);
			const idxArr = /* @__PURE__ */ new Uint32Array(1);
			crypto.getRandomValues(idxArr);
			const pos = filler.length ? idxArr[0] % (filler.length + 1) : 0;
			setGenerated(filler.slice(0, pos) + customText + filler.slice(pos));
		} else {
			let out = "";
			for (let i = 0; i < length; i++) out += randPick(pool);
			setGenerated(out);
		}
		trackUse("pw-generate");
	};
	const [tested, setTested] = (0, import_react.useState)("");
	const strength = (0, import_react.useMemo)(() => scorePassword(tested), [tested]);
	const WORDS = [
		"apple",
		"river",
		"shadow",
		"lantern",
		"ember",
		"harbor",
		"violet",
		"summit",
		"willow",
		"comet",
		"orchid",
		"quartz",
		"ranger",
		"silver",
		"marble",
		"thunder",
		"winter",
		"garnet",
		"valley",
		"echo"
	];
	const [wordCount, setWordCount] = (0, import_react.useState)(5);
	const [sep, setSep] = (0, import_react.useState)("-");
	const [phrase, setPhrase] = (0, import_react.useState)("");
	const makePhrase = () => {
		const out = [];
		for (let i = 0; i < wordCount; i++) out.push(randPick(WORDS.join(",")) ? WORDS[Math.floor(crypto.getRandomValues(/* @__PURE__ */ new Uint32Array(1))[0] / 4294967296 * WORDS.length)] : WORDS[0]);
		setPhrase(out.join(sep));
		trackUse("pw-passphrase");
	};
	const [pinLen, setPinLen] = (0, import_react.useState)(6);
	const [pin, setPin] = (0, import_react.useState)("");
	const makePin = () => {
		let s = "";
		for (let i = 0; i < pinLen; i++) s += randPick("0123456789");
		setPin(s);
		trackUse("pw-pin");
	};
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Layout, { children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("section", {
		className: "mx-auto max-w-5xl px-4 py-12 sm:px-6",
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Reveal, { children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("header", {
				className: "mb-8",
				children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
						className: "text-sm font-semibold uppercase tracking-wider text-blue-600",
						children: "Password tools"
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h1", {
						className: "mt-1 text-3xl font-bold text-slate-900 sm:text-4xl dark:text-white",
						style: { fontFamily: "'Space Grotesk', sans-serif" },
						children: "Strong passwords, in your browser"
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
						className: "mt-2 text-slate-600 dark:text-slate-400",
						children: "Generated locally with the Web Crypto API. Nothing is sent anywhere."
					})
				]
			}) }),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "grid gap-5 lg:grid-cols-2",
				children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Card, {
						id: "generate",
						toolId: "pw-generate",
						title: "Password Generator",
						desc: "Custom length and character mix.",
						children: [
							/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("label", {
								className: "block text-sm font-medium text-slate-700 dark:text-slate-200",
								children: ["Length: ", length]
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
								type: "range",
								min: 6,
								max: 64,
								value: length,
								onChange: (e) => setLength(+e.target.value),
								className: "mt-2 w-full accent-blue-600",
								"aria-label": "length"
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
								className: "mt-3 grid grid-cols-2 gap-2 text-sm",
								children: [
									/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("label", {
										className: "flex items-center gap-2",
										children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
											type: "checkbox",
											checked: upper,
											onChange: (e) => setUpper(e.target.checked)
										}), " Uppercase"]
									}),
									/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("label", {
										className: "flex items-center gap-2",
										children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
											type: "checkbox",
											checked: lower,
											onChange: (e) => setLower(e.target.checked)
										}), " Lowercase"]
									}),
									/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("label", {
										className: "flex items-center gap-2",
										children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
											type: "checkbox",
											checked: nums,
											onChange: (e) => setNums(e.target.checked)
										}), " Numbers"]
									}),
									/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("label", {
										className: "flex items-center gap-2",
										children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
											type: "checkbox",
											checked: syms,
											onChange: (e) => setSyms(e.target.checked)
										}), " Symbols"]
									}),
									/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("label", {
										className: "col-span-2 flex items-center gap-2",
										children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
											type: "checkbox",
											checked: excludeAmbig,
											onChange: (e) => setExcludeAmbig(e.target.checked)
										}), " Exclude ambiguous (Il1O0)"]
									})
								]
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
								className: "mt-3 rounded-lg border border-slate-200 p-3 dark:border-slate-700",
								children: [
									/* @__PURE__ */ (0, import_jsx_runtime.jsx)("label", {
										className: "block text-sm font-medium text-slate-700 dark:text-slate-200",
										children: "Custom text (optional)"
									}),
									/* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
										type: "text",
										value: customText,
										onChange: (e) => setCustomText(e.target.value),
										placeholder: "e.g. your name, brand, keyword",
										"aria-label": "custom text to include in password",
										className: "mt-1 w-full rounded-lg border border-slate-200 bg-white px-3 py-2 text-sm dark:border-slate-700 dark:bg-slate-950 dark:text-white"
									}),
									/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
										className: "mt-2 flex flex-wrap gap-3 text-xs text-slate-600 dark:text-slate-300",
										children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("label", {
											className: "flex items-center gap-1.5",
											children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
												type: "radio",
												name: "custom-mode",
												checked: customMode === "insert",
												onChange: () => setCustomMode("insert")
											}), " Insert text as-is"]
										}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("label", {
											className: "flex items-center gap-1.5",
											children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
												type: "radio",
												name: "custom-mode",
												checked: customMode === "pool",
												onChange: () => setCustomMode("pool")
											}), " Add characters to pool"]
										})]
									})
								]
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
								className: "mt-3 flex flex-wrap gap-2",
								children: [
									/* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
										onClick: generate,
										className: runBtn,
										children: "Generate"
									}),
									/* @__PURE__ */ (0, import_jsx_runtime.jsx)(CopyButton, { getText: () => generated }),
									/* @__PURE__ */ (0, import_jsx_runtime.jsx)(DownloadButton, {
										getText: () => generated,
										filename: "password.txt"
									})
								]
							}),
							generated && /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
								className: "mt-3 break-all rounded-lg bg-slate-950 p-3 font-mono text-sm text-emerald-300",
								children: generated
							})
						]
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Card, {
						id: "strength",
						toolId: "pw-strength",
						title: "Password Strength Meter",
						desc: "Audit a password's strength.",
						children: [
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
								type: "text",
								value: tested,
								onChange: (e) => {
									setTested(e.target.value);
									if (e.target.value) trackUse("pw-strength");
								},
								placeholder: "Type or paste a password…",
								"aria-label": "password to test",
								className: "w-full rounded-lg border border-slate-200 bg-white px-3 py-2 font-mono text-sm dark:border-slate-700 dark:bg-slate-950 dark:text-white"
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
								className: "mt-3 h-2.5 w-full overflow-hidden rounded-full bg-slate-200 dark:bg-slate-800",
								children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
									className: `h-full transition-all ${strength.color}`,
									style: { width: `${strength.pct}%` },
									"aria-label": `strength: ${strength.label}`
								})
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
								className: "mt-2 flex items-center justify-between text-sm",
								children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
									className: "font-semibold text-slate-900 dark:text-white",
									children: strength.label
								}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", {
									className: "text-slate-500",
									children: [tested.length, " chars"]
								})]
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
								className: "mt-1 text-xs text-slate-500",
								children: strength.hint
							})
						]
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Card, {
						id: "passphrase",
						toolId: "pw-passphrase",
						title: "Passphrase Generator",
						desc: "Memorable word-based passwords.",
						children: [
							/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
								className: "flex items-center gap-3",
								children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("label", {
									className: "text-sm",
									children: ["Words ", /* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
										type: "number",
										min: 3,
										max: 12,
										value: wordCount,
										onChange: (e) => setWordCount(+e.target.value),
										className: "ml-1 w-20 rounded border border-slate-200 px-2 py-1 dark:border-slate-700 dark:bg-slate-950 dark:text-white"
									})]
								}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("label", {
									className: "text-sm",
									children: ["Separator ", /* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
										value: sep,
										onChange: (e) => setSep(e.target.value),
										maxLength: 3,
										className: "ml-1 w-16 rounded border border-slate-200 px-2 py-1 dark:border-slate-700 dark:bg-slate-950 dark:text-white"
									})]
								})]
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
								className: "mt-3 flex flex-wrap gap-2",
								children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
									onClick: makePhrase,
									className: runBtn,
									children: "Generate"
								}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(CopyButton, { getText: () => phrase })]
							}),
							phrase && /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
								className: "mt-3 break-all rounded-lg bg-slate-950 p-3 font-mono text-sm text-cyan-300",
								children: phrase
							})
						]
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Card, {
						id: "pin",
						toolId: "pw-pin",
						title: "PIN Generator",
						desc: "Numeric PIN codes (4–12 digits).",
						children: [
							/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("label", {
								className: "text-sm",
								children: ["Digits ", /* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
									type: "number",
									min: 4,
									max: 12,
									value: pinLen,
									onChange: (e) => setPinLen(+e.target.value),
									className: "ml-1 w-20 rounded border border-slate-200 px-2 py-1 dark:border-slate-700 dark:bg-slate-950 dark:text-white"
								})]
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
								className: "mt-3 flex flex-wrap gap-2",
								children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
									onClick: makePin,
									className: runBtn,
									children: "Generate"
								}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(CopyButton, { getText: () => pin })]
							}),
							pin && /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
								className: "mt-3 rounded-lg bg-slate-950 p-3 text-center font-mono text-2xl tracking-[0.5em] text-amber-300",
								children: pin
							})
						]
					})
				]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Reveal, { children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("section", {
				className: "mt-10 rounded-2xl border border-dashed border-slate-300 bg-slate-50/60 p-6 dark:border-slate-700 dark:bg-slate-900/40",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "flex items-center justify-between gap-3",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h2", {
						className: "text-lg font-bold text-slate-900 dark:text-white",
						style: { fontFamily: "'Space Grotesk', sans-serif" },
						children: "More password tools"
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
						className: "mt-1 text-sm text-slate-600 dark:text-slate-400",
						children: "We're actively expanding this category."
					})] }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
						className: "rounded-full bg-amber-100 px-3 py-1 text-xs font-semibold text-amber-800 dark:bg-amber-950/50 dark:text-amber-300",
						children: "Coming soon"
					})]
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("ul", {
					className: "mt-4 grid gap-2 sm:grid-cols-2",
					children: [
						{
							name: "Password Vault",
							desc: "Save & organize passwords locally, encrypted with a master key."
						},
						{
							name: "Breach Checker",
							desc: "Check if a password has appeared in known data breaches (k-anonymous)."
						},
						{
							name: "TOTP / 2FA Generator",
							desc: "Generate rolling 6-digit codes from a secret."
						},
						{
							name: "Wi‑Fi QR Code",
							desc: "Create a scannable QR code for your Wi‑Fi credentials."
						}
					].map((f) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("li", {
						className: "flex items-start justify-between gap-3 rounded-xl border border-slate-200 bg-white p-3 dark:border-slate-800 dark:bg-slate-950",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
							className: "text-sm font-semibold text-slate-900 dark:text-white",
							children: f.name
						}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
							className: "mt-0.5 text-xs text-slate-500 dark:text-slate-400",
							children: f.desc
						})] }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
							className: "whitespace-nowrap rounded-full bg-slate-100 px-2 py-0.5 text-[10px] font-semibold uppercase tracking-wide text-slate-600 dark:bg-slate-800 dark:text-slate-300",
							children: "Soon"
						})]
					}, f.name))
				})]
			}) })
		]
	}) });
}
//#endregion
export { PasswordTools as component };
