import { o as __toESM } from "../_runtime.mjs";
import { nt as require_react } from "../_libs/@hookform/resolvers+[...].mjs";
import { t as createClient } from "../_libs/supabase__supabase-js.mjs";
import { t as supabase } from "./client-CxWkeBjE.mjs";
import { M as redirect, b as useRouter, c as HeadContent, d as createRouter, f as Outlet, g as Link, h as createRootRouteWithContext, m as createFileRoute, p as lazyRouteComponent, s as Scripts } from "../_libs/@tanstack/react-router+[...].mjs";
import { r as require_jsx_runtime, t as QueryClientProvider } from "../_libs/react+tanstack__react-query.mjs";
import { t as QueryClient } from "../_libs/tanstack__query-core.mjs";
import { n as ThemeProvider, t as AuthProvider } from "./auth-context-DS3dl-5u.mjs";
import { t as Toaster } from "../_libs/sonner.mjs";
import { n as string, t as object } from "../_libs/zod.mjs";
import processModule from "node:process";
//#region node_modules/.nitro/vite/services/ssr/assets/router-B2WLoMLl.js
var import_react = /* @__PURE__ */ __toESM(require_react());
var import_jsx_runtime = require_jsx_runtime();
var styles_default = "/assets/styles-Cp4xpSVq.css";
function reportLovableError(error, context = {}) {
	if (typeof window === "undefined") return;
	window.__lovableEvents?.captureException?.(error, {
		source: "react_error_boundary",
		route: window.location.pathname,
		...context
	}, {
		mechanism: "react_error_boundary",
		handled: false,
		severity: "error"
	});
}
var Toaster$1 = ({ ...props }) => {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Toaster, {
		className: "toaster group",
		toastOptions: { classNames: {
			toast: "group toast group-[.toaster]:bg-background group-[.toaster]:text-foreground group-[.toaster]:border-border group-[.toaster]:shadow-lg",
			description: "group-[.toast]:text-muted-foreground",
			actionButton: "group-[.toast]:bg-primary group-[.toast]:text-primary-foreground",
			cancelButton: "group-[.toast]:bg-muted group-[.toast]:text-muted-foreground"
		} },
		...props
	});
};
function NotFound() {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("main", {
		role: "main",
		"aria-labelledby": "nf-title",
		className: "relative flex min-h-screen items-center justify-center overflow-hidden bg-gradient-to-br from-slate-50 via-white to-blue-50 px-4 py-16 dark:from-slate-950 dark:via-slate-950 dark:to-blue-950/40",
		children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
			"aria-hidden": "true",
			className: "pointer-events-none absolute inset-0",
			children: [
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", { className: "absolute -top-24 -left-24 h-72 w-72 animate-pulse rounded-full bg-blue-400/20 blur-3xl dark:bg-blue-500/20" }),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
					className: "absolute -bottom-24 -right-24 h-80 w-80 animate-pulse rounded-full bg-fuchsia-400/20 blur-3xl dark:bg-fuchsia-500/20",
					style: { animationDelay: "1s" }
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
					className: "absolute left-1/2 top-1/3 h-56 w-56 -translate-x-1/2 animate-pulse rounded-full bg-emerald-300/20 blur-3xl dark:bg-emerald-500/10",
					style: { animationDelay: "2s" }
				})
			]
		}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("section", {
			className: "relative z-10 mx-auto max-w-2xl text-center",
			children: [
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
					className: "text-xs font-semibold uppercase tracking-[0.25em] text-blue-600 dark:text-blue-400",
					children: "Error 404"
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("h1", {
					id: "nf-title",
					className: "mt-4 select-none bg-gradient-to-br from-slate-900 via-blue-600 to-fuchsia-600 bg-clip-text text-[7rem] font-black leading-none text-transparent sm:text-[10rem] dark:from-white dark:via-blue-300 dark:to-fuchsia-300",
					style: { fontFamily: "'Space Grotesk', sans-serif" },
					children: [
						"4",
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
							className: "inline-block animate-spin",
							style: { animationDuration: "6s" },
							children: "0"
						}),
						"4"
					]
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h2", {
					className: "mt-2 text-2xl font-bold text-slate-900 sm:text-3xl dark:text-white",
					children: "This tool went exploring without us."
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
					className: "mx-auto mt-3 max-w-lg text-base text-slate-600 dark:text-slate-400",
					children: "The page you’re looking for doesn’t exist, was moved, or maybe never did. Let’s get you back to something useful."
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "mt-8 flex flex-wrap items-center justify-center gap-3",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Link, {
						to: "/",
						"aria-label": "Return to homepage",
						className: "inline-flex items-center gap-2 rounded-xl bg-blue-600 px-5 py-3 text-sm font-semibold text-white shadow-lg shadow-blue-600/30 transition-transform hover:scale-[1.03] hover:bg-blue-700 focus:outline-none focus-visible:ring-2 focus-visible:ring-blue-500 focus-visible:ring-offset-2",
						children: "← Back to home"
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Link, {
						to: "/tools/text",
						className: "inline-flex items-center gap-2 rounded-xl border border-slate-200 bg-white px-5 py-3 text-sm font-semibold text-slate-900 transition hover:border-slate-300 hover:bg-slate-50 dark:border-slate-700 dark:bg-slate-900 dark:text-white dark:hover:bg-slate-800",
						children: "Browse tools"
					})]
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("nav", {
					"aria-label": "Popular destinations",
					className: "mt-10",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
						className: "text-xs font-semibold uppercase tracking-widest text-slate-400 dark:text-slate-500",
						children: "Popular"
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("ul", {
						className: "mt-3 flex flex-wrap justify-center gap-2",
						children: [
							{
								to: "/tools/text",
								label: "Text tools"
							},
							{
								to: "/tools/pdf",
								label: "PDF tools"
							},
							{
								to: "/tools/image",
								label: "Image tools"
							},
							{
								to: "/tools/code",
								label: "Code tools"
							},
							{
								to: "/tools/password",
								label: "Password tools"
							}
						].map((l) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)("li", { children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Link, {
							to: l.to,
							className: "rounded-full border border-slate-200 bg-white/70 px-3 py-1.5 text-xs font-medium text-slate-700 backdrop-blur transition hover:border-blue-400 hover:text-blue-700 dark:border-slate-700 dark:bg-slate-900/60 dark:text-slate-300 dark:hover:border-blue-500 dark:hover:text-blue-300",
							children: l.label
						}) }, l.to))
					})]
				})
			]
		})]
	});
}
function NotFoundComponent() {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)(NotFound, {});
}
function ErrorComponent({ error, reset }) {
	console.error(error);
	const router = useRouter();
	(0, import_react.useEffect)(() => {
		reportLovableError(error, { boundary: "tanstack_root_error_component" });
	}, [error]);
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
		className: "flex min-h-screen items-center justify-center bg-white px-4 dark:bg-slate-950",
		children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
			className: "max-w-md text-center",
			children: [
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h1", {
					className: "text-xl font-semibold text-slate-900 dark:text-white",
					children: "This page didn't load"
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
					className: "mt-2 text-sm text-slate-600 dark:text-slate-400",
					children: "Something went wrong on our end."
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "mt-6 flex flex-wrap justify-center gap-2",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
						onClick: () => {
							router.invalidate();
							reset();
						},
						className: "rounded-lg bg-blue-600 px-4 py-2 text-sm font-semibold text-white hover:bg-blue-700",
						children: "Try again"
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("a", {
						href: "/",
						className: "rounded-lg border border-slate-200 px-4 py-2 text-sm font-medium text-slate-900 dark:border-slate-700 dark:text-white",
						children: "Go home"
					})]
				})
			]
		})
	});
}
var Route$27 = createRootRouteWithContext()({
	head: () => ({
		meta: [
			{ charSet: "utf-8" },
			{
				name: "viewport",
				content: "width=device-width, initial-scale=1"
			},
			{ title: "UniversalTools — All-in-one Text, PDF & Image Tools" },
			{
				name: "description",
				content: "30+ free online tools for text, PDF and image — word counter, PDF merger, image resizer and more. Fast, private, runs in your browser."
			},
			{
				name: "author",
				content: "UniversalTools"
			},
			{
				name: "keywords",
				content: "online tools, text tools, pdf tools, image tools, word counter, merge pdf, resize image, free tools"
			},
			{
				name: "theme-color",
				content: "#2563eb"
			},
			{
				property: "og:site_name",
				content: "UniversalTools"
			},
			{
				property: "og:title",
				content: "UniversalTools — All-in-one Text, PDF & Image Tools"
			},
			{
				property: "og:description",
				content: "30+ free online tools for text, PDF and image — word counter, PDF merger, image resizer and more. Fast, private, runs in your browser."
			},
			{
				property: "og:type",
				content: "website"
			},
			{
				name: "twitter:card",
				content: "summary_large_image"
			},
			{
				name: "twitter:title",
				content: "UniversalTools — All-in-one Text, PDF & Image Tools"
			},
			{
				name: "twitter:description",
				content: "30+ free online tools for text, PDF and image — word counter, PDF merger, image resizer and more. Fast, private, runs in your browser."
			}
		],
		links: [
			{
				rel: "stylesheet",
				href: styles_default
			},
			{
				rel: "icon",
				type: "image/png",
				href: "/favicon.png"
			},
			{
				rel: "apple-touch-icon",
				href: "/favicon.png"
			}
		],
		scripts: [
			{
				src: "https://googletagmanager.com",
				async: true
			},
			{ children: `
          window.dataLayer = window.dataLayer || [];
          function gtag(){dataLayer.push(arguments);}
          gtag('js', new Date());
          gtag('config', 'G-9FXMNKTXKF');
        ` },
			{
				type: "application/ld+json",
				children: JSON.stringify({
					"@context": "https://schema.org",
					"@type": "WebSite",
					name: "UniversalTools",
					description: "30+ free online tools for text, PDF and image."
				})
			}
		]
	}),
	shellComponent: RootShell,
	component: RootComponent,
	notFoundComponent: NotFoundComponent,
	errorComponent: ErrorComponent
});
function RootShell({ children }) {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("html", {
		lang: "en",
		suppressHydrationWarning: true,
		children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("head", { children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(HeadContent, {}) }), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("body", { children: [children, /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Scripts, {})] })]
	});
}
function RootComponent() {
	const { queryClient } = Route$27.useRouteContext();
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)(QueryClientProvider, {
		client: queryClient,
		children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(ThemeProvider, { children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(AuthProvider, { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Outlet, {}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Toaster$1, {
			position: "top-right",
			richColors: true
		})] }) })
	});
}
var $$splitComponentImporter$23 = () => import("./why-choose-us-z36evoqD.mjs");
var Route$26 = createFileRoute("/why-choose-us")({
	head: () => ({
		meta: [
			{ title: "Why Choose UniversalTools" },
			{
				name: "description",
				content: "Privacy-first, no uploads, lightning fast and free — see why UniversalTools beats single-purpose websites."
			},
			{
				property: "og:title",
				content: "Why Choose UniversalTools"
			},
			{
				property: "og:url",
				content: "/why-choose-us"
			}
		],
		links: [{
			rel: "canonical",
			href: "/why-choose-us"
		}]
	}),
	component: lazyRouteComponent($$splitComponentImporter$23, "component")
});
var $$splitComponentImporter$22 = () => import("./terms-1KngXBKB.mjs");
var Route$25 = createFileRoute("/terms")({
	head: () => ({
		meta: [
			{ title: "Terms & Conditions | UniversalTools" },
			{
				name: "description",
				content: "Read the terms and conditions for using UniversalTools' free online text, PDF, image, code and password tools."
			},
			{
				property: "og:title",
				content: "Terms & Conditions — UniversalTools"
			},
			{
				property: "og:url",
				content: "/terms"
			}
		],
		links: [{
			rel: "canonical",
			href: "/terms"
		}]
	}),
	component: lazyRouteComponent($$splitComponentImporter$22, "component")
});
var BASE_URL = "https://universaltools.in";
var entries = [
	{
		path: "/",
		changefreq: "weekly",
		priority: "1.0"
	},
	{
		path: "/tools/text",
		changefreq: "weekly",
		priority: "0.9"
	},
	{
		path: "/tools/pdf",
		changefreq: "weekly",
		priority: "0.9"
	},
	{
		path: "/tools/image",
		changefreq: "weekly",
		priority: "0.9"
	},
	{
		path: "/tools/code",
		changefreq: "weekly",
		priority: "0.9"
	},
	{
		path: "/tools/color",
		changefreq: "weekly",
		priority: "0.9"
	},
	{
		path: "/tools/password",
		changefreq: "weekly",
		priority: "0.9"
	},
	{
		path: "/tools/productivity",
		changefreq: "weekly",
		priority: "0.9"
	},
	{
		path: "/tools/productivity#timer",
		changefreq: "monthly",
		priority: "0.7"
	},
	{
		path: "/tools/productivity#todo",
		changefreq: "monthly",
		priority: "0.7"
	},
	{
		path: "/tools/productivity#calculator",
		changefreq: "monthly",
		priority: "0.7"
	},
	{
		path: "/tools/productivity#currency",
		changefreq: "monthly",
		priority: "0.7"
	},
	{
		path: "/tools/productivity#timezone",
		changefreq: "monthly",
		priority: "0.7"
	},
	{
		path: "/tools/productivity#unit",
		changefreq: "monthly",
		priority: "0.6"
	},
	{
		path: "/tools/productivity#length",
		changefreq: "monthly",
		priority: "0.7"
	},
	{
		path: "/tools/productivity#mass",
		changefreq: "monthly",
		priority: "0.7"
	},
	{
		path: "/tools/productivity#area",
		changefreq: "monthly",
		priority: "0.7"
	},
	{
		path: "/tools/productivity#time",
		changefreq: "monthly",
		priority: "0.7"
	},
	{
		path: "/tools/productivity#data",
		changefreq: "monthly",
		priority: "0.7"
	},
	{
		path: "/tools/productivity#temperature",
		changefreq: "monthly",
		priority: "0.7"
	},
	{
		path: "/tools/productivity#finance",
		changefreq: "monthly",
		priority: "0.8"
	},
	{
		path: "/tools/productivity#date-diff",
		changefreq: "monthly",
		priority: "0.7"
	},
	{
		path: "/tools/productivity#discount",
		changefreq: "monthly",
		priority: "0.7"
	},
	{
		path: "/tools/productivity#bmi",
		changefreq: "monthly",
		priority: "0.7"
	},
	{
		path: "/tools/productivity#gst",
		changefreq: "monthly",
		priority: "0.8"
	},
	{
		path: "/tools/productivity#volume",
		changefreq: "monthly",
		priority: "0.7"
	},
	{
		path: "/tools/productivity#speed",
		changefreq: "monthly",
		priority: "0.7"
	},
	{
		path: "/tools/productivity#numeral",
		changefreq: "monthly",
		priority: "0.7"
	},
	{
		path: "/about",
		changefreq: "monthly",
		priority: "0.6"
	},
	{
		path: "/why-choose-us",
		changefreq: "monthly",
		priority: "0.6"
	},
	{
		path: "/pricing",
		changefreq: "monthly",
		priority: "0.6"
	},
	{
		path: "/contact",
		changefreq: "monthly",
		priority: "0.6"
	},
	{
		path: "/privacy",
		changefreq: "yearly",
		priority: "0.3"
	},
	{
		path: "/terms",
		changefreq: "yearly",
		priority: "0.3"
	},
	{
		path: "/login",
		changefreq: "yearly",
		priority: "0.3"
	},
	{
		path: "/signup",
		changefreq: "yearly",
		priority: "0.3"
	}
];
var Route$24 = createFileRoute("/sitemap.xml")({ server: { handlers: { GET: async () => {
	const lastmod = (/* @__PURE__ */ new Date()).toISOString().slice(0, 10);
	const xml = `<?xml version="1.0" encoding="UTF-8"?>\n<urlset xmlns="http://www.sitemaps.org/schemas/sitemap/0.9">\n${entries.map((e) => [
		`  <url>`,
		`    <loc>${BASE_URL}${e.path}</loc>`,
		`    <lastmod>${lastmod}</lastmod>`,
		e.changefreq ? `    <changefreq>${e.changefreq}</changefreq>` : null,
		e.priority ? `    <priority>${e.priority}</priority>` : null,
		`  </url>`
	].filter(Boolean).join("\n")).join("\n")}\n</urlset>`;
	return new Response(xml, { headers: {
		"Content-Type": "application/xml",
		"Cache-Control": "public, max-age=3600"
	} });
} } } });
var $$splitComponentImporter$21 = () => import("./signup-DdL96lrA.mjs");
var Route$23 = createFileRoute("/signup")({
	beforeLoad: () => {
		throw redirect({
			to: "/auth",
			search: { mode: "signup" }
		});
	},
	component: lazyRouteComponent($$splitComponentImporter$21, "component")
});
var $$splitComponentImporter$20 = () => import("./reset-password-ChxjJYWE.mjs");
var Route$22 = createFileRoute("/reset-password")({
	head: () => ({ meta: [{ title: "Reset password — UniversalTools" }, {
		name: "robots",
		content: "noindex"
	}] }),
	component: lazyRouteComponent($$splitComponentImporter$20, "component")
});
var $$splitComponentImporter$19 = () => import("./privacy-Cc95H9Lg.mjs");
var Route$21 = createFileRoute("/privacy")({
	head: () => ({
		meta: [
			{ title: "Privacy Policy | UniversalTools" },
			{
				name: "description",
				content: "How UniversalTools handles your data. Files never leave your device — all processing runs in your browser."
			},
			{
				property: "og:title",
				content: "Privacy Policy — UniversalTools"
			},
			{
				property: "og:url",
				content: "/privacy"
			}
		],
		links: [{
			rel: "canonical",
			href: "/privacy"
		}]
	}),
	component: lazyRouteComponent($$splitComponentImporter$19, "component")
});
var SITE_URL = "https://universaltools.in";
var SITE_NAME = "UniversalTools";
var OG_IMAGE = "https://universaltools.in/og-image.png";
function imageMeta() {
	return [
		{
			property: "og:image",
			content: OG_IMAGE
		},
		{
			property: "og:image:alt",
			content: "UniversalTools — all-in-one online toolbox"
		},
		{
			name: "twitter:image",
			content: OG_IMAGE
		}
	];
}
var $$splitComponentImporter$18 = () => import("./pricing-CZa6uqF7.mjs");
var Route$20 = createFileRoute("/pricing")({
	head: () => ({
		meta: [
			{ title: "Pricing — Free, Premium & Pro Lifetime Deal | UniversalTools" },
			{
				name: "description",
				content: "Compare Free, Premium ($5/mo) and Pro lifetime ($50 — 50% off, limited time). Unlimited PDF, image, text, code & productivity tools in your browser."
			},
			{
				name: "keywords",
				content: "universaltools pricing, free online tools, pdf tools pricing, image tools pricing, lifetime deal, premium tools subscription"
			},
			{
				property: "og:title",
				content: "UniversalTools Pricing — Free, Premium & Pro Lifetime"
			},
			{
				property: "og:description",
				content: "Free forever plan, Premium at $5/mo, and a limited-time Pro lifetime deal at $50 (was $100)."
			},
			{
				property: "og:type",
				content: "website"
			},
			{
				property: "og:url",
				content: `${SITE_URL}/pricing`
			},
			{
				name: "twitter:card",
				content: "summary_large_image"
			},
			{
				name: "twitter:title",
				content: "UniversalTools Pricing"
			},
			{
				name: "twitter:description",
				content: "Free forever, $5/mo Premium, or $50 lifetime Pro (limited time)."
			}
		],
		links: [{
			rel: "canonical",
			href: `${SITE_URL}/pricing`
		}],
		scripts: [{
			type: "application/ld+json",
			children: JSON.stringify({
				"@context": "https://schema.org",
				"@type": "FAQPage",
				mainEntity: [
					{
						"@type": "Question",
						name: "Are UniversalTools really free?",
						acceptedAnswer: {
							"@type": "Answer",
							text: "Yes. All text, code, color, password and productivity tools are unlimited and free forever. PDF and image tools have a small daily cap on free tiers."
						}
					},
					{
						"@type": "Question",
						name: "What's the difference between guest and free account?",
						acceptedAnswer: {
							"@type": "Answer",
							text: "Guests get 3 PDF/image runs per day. A free account raises that to 10 per day and unlocks favorites and history."
						}
					},
					{
						"@type": "Question",
						name: "What does the Pro lifetime deal include?",
						acceptedAnswer: {
							"@type": "Answer",
							text: "One payment of $50 (regularly $100) unlocks unlimited PDF & image processing, all future tools, and use across multiple devices — for life."
						}
					},
					{
						"@type": "Question",
						name: "Can I cancel Premium anytime?",
						acceptedAnswer: {
							"@type": "Answer",
							text: "Yes. Premium is billed monthly and can be cancelled at any time from your account."
						}
					},
					{
						"@type": "Question",
						name: "Are my files uploaded anywhere?",
						acceptedAnswer: {
							"@type": "Answer",
							text: "No. Every tool runs 100% in your browser — files never leave your device."
						}
					}
				]
			})
		}]
	}),
	component: lazyRouteComponent($$splitComponentImporter$18, "component")
});
var $$splitComponentImporter$17 = () => import("./login-BH6-GzYA.mjs");
var Route$19 = createFileRoute("/login")({
	beforeLoad: () => {
		throw redirect({
			to: "/auth",
			search: { mode: "signin" }
		});
	},
	component: lazyRouteComponent($$splitComponentImporter$17, "component")
});
var $$splitComponentImporter$16 = () => import("./favorites-BwE8XEEg.mjs");
var Route$18 = createFileRoute("/favorites")({
	head: () => ({
		meta: [
			{ title: "Favorites — Your Saved Tools | UniversalTools" },
			{
				name: "description",
				content: "Quick access to the UniversalTools tools you've bookmarked."
			},
			{
				property: "og:title",
				content: "Your Favorite Tools — UniversalTools"
			},
			{
				property: "og:url",
				content: "/favorites"
			}
		],
		links: [{
			rel: "canonical",
			href: "/favorites"
		}]
	}),
	component: lazyRouteComponent($$splitComponentImporter$16, "component")
});
var $$splitComponentImporter$15 = () => import("./contact-BdMIJTGX.mjs");
var Route$17 = createFileRoute("/contact")({
	head: () => ({
		meta: [
			{ title: "Contact — UniversalTools" },
			{
				name: "description",
				content: "Reach the UniversalTools team for support, partnerships or feedback. Email prashantnadar2223@gmail.com or call +91 96533 86506."
			},
			{
				property: "og:title",
				content: "Contact UniversalTools"
			},
			{
				property: "og:description",
				content: "Get in touch with the UniversalTools team — email, phone, and contact form."
			},
			{
				property: "og:type",
				content: "website"
			},
			{
				property: "og:url",
				content: `${SITE_URL}/contact`
			},
			{
				name: "twitter:card",
				content: "summary_large_image"
			},
			{
				name: "twitter:title",
				content: "Contact UniversalTools"
			},
			{
				name: "twitter:description",
				content: "Get in touch with the UniversalTools team — email, phone, and contact form."
			},
			...imageMeta()
		],
		links: [{
			rel: "canonical",
			href: `${SITE_URL}/contact`
		}],
		scripts: [{
			type: "application/ld+json",
			children: JSON.stringify({
				"@context": "https://schema.org",
				"@type": "ContactPage",
				name: "Contact UniversalTools",
				url: `${SITE_URL}/contact`,
				description: "Reach the UniversalTools team for support, partnerships or feedback.",
				mainEntity: {
					"@type": "Organization",
					name: "UniversalTools",
					url: SITE_URL,
					contactPoint: [{
						"@type": "ContactPoint",
						email: "prashantnadar2223@gmail.com",
						telephone: "+91-96533-86506",
						contactType: "customer support",
						availableLanguage: ["English", "Hindi"]
					}]
				}
			})
		}]
	}),
	component: lazyRouteComponent($$splitComponentImporter$15, "component")
});
var emailRegex = /^[A-Za-z0-9._%+-]+@[A-Za-z0-9.-]+\.[A-Za-z]{2,}$/;
var hasLetter = /[A-Za-z]/;
object({
	name: string().min(1, "Name is required").max(50, "Name must be 50 characters or less").regex(/^[A-Za-z]+(?: [A-Za-z]+)*$/, "Only letters and spaces between words are allowed"),
	email: string().trim().min(1, "Email is required").max(50, "Email must be 50 characters or less").regex(emailRegex, "Enter a valid email address"),
	subject: string().trim().min(10, "Subject must be at least 10 characters").max(100, "Subject must be 100 characters or less").regex(hasLetter, "Subject can't be only numbers or symbols"),
	message: string().trim().min(20, "Message must be at least 20 characters").max(500, "Message must be 500 characters or less").regex(hasLetter, "Message can't be only numbers or symbols")
});
var $$splitComponentImporter$14 = () => import("./auth--5dpptPK.mjs");
var Route$16 = createFileRoute("/auth")({
	validateSearch: (raw) => ({
		redirect: typeof raw.redirect === "string" ? raw.redirect : void 0,
		mode: raw.mode === "signup" || raw.mode === "forgot" ? raw.mode : "signin"
	}),
	head: () => ({
		meta: [
			{ title: "Sign in — UniversalTools" },
			{
				name: "description",
				content: "Sign in or create your UniversalTools account."
			},
			{
				name: "robots",
				content: "noindex"
			}
		],
		links: [{
			rel: "canonical",
			href: "/auth"
		}]
	}),
	component: lazyRouteComponent($$splitComponentImporter$14, "component")
});
var $$splitComponentImporter$13 = () => import("./about-CEaMtYYa.mjs");
var Route$15 = createFileRoute("/about")({
	head: () => ({
		meta: [
			{ title: "About — UniversalTools" },
			{
				name: "description",
				content: "UniversalTools brings together 30+ browser-based utilities for text, PDFs and images, all built around privacy and speed."
			},
			{
				property: "og:title",
				content: "About UniversalTools"
			},
			{
				property: "og:description",
				content: "Why we built UniversalTools — one privacy-first home for everyday text, PDF and image tasks."
			},
			{
				property: "og:type",
				content: "website"
			},
			{
				property: "og:url",
				content: `${SITE_URL}/about`
			},
			{
				name: "twitter:card",
				content: "summary_large_image"
			},
			{
				name: "twitter:title",
				content: "About UniversalTools"
			},
			{
				name: "twitter:description",
				content: "Why we built UniversalTools — one privacy-first home for everyday text, PDF and image tasks."
			},
			...imageMeta()
		],
		links: [{
			rel: "canonical",
			href: `${SITE_URL}/about`
		}],
		scripts: [{
			type: "application/ld+json",
			children: JSON.stringify({
				"@context": "https://schema.org",
				"@type": "AboutPage",
				name: "About UniversalTools",
				url: `${SITE_URL}/about`,
				description: "About UniversalTools — one privacy-first home for everyday text, PDF and image tasks.",
				publisher: {
					"@type": "Organization",
					name: "UniversalTools",
					url: SITE_URL
				}
			})
		}]
	}),
	component: lazyRouteComponent($$splitComponentImporter$13, "component")
});
var $$splitComponentImporter$12 = () => import("./route-Di7iQBCH.mjs");
var Route$14 = createFileRoute("/_authenticated")({
	ssr: false,
	beforeLoad: async ({ location }) => {
		const { data: { session } } = await supabase.auth.getSession();
		if (!session?.user) throw redirect({
			to: "/auth",
			search: {
				redirect: location.href,
				mode: "signin"
			}
		});
		return { user: session.user };
	},
	component: lazyRouteComponent($$splitComponentImporter$12, "component")
});
var $$splitComponentImporter$11 = () => import("./routes-DpCGhPas.mjs");
var Route$13 = createFileRoute("/")({
	head: () => ({
		meta: [
			{ title: "UniversalTools — Free Text, PDF, Image, Code & Password Tools" },
			{
				name: "description",
				content: "50+ free online tools: word counter, PDF merger, image resizer, JSON formatter, password generator and more. Runs in your browser."
			},
			{
				property: "og:title",
				content: "UniversalTools — Free Online Tools"
			},
			{
				property: "og:description",
				content: "50+ free tools for text, PDF, image, code and password work. No uploads, no sign-up."
			},
			{
				property: "og:type",
				content: "website"
			},
			{
				property: "og:url",
				content: `${SITE_URL}/`
			},
			{
				name: "twitter:card",
				content: "summary_large_image"
			},
			{
				name: "twitter:title",
				content: "UniversalTools — Free Online Tools"
			},
			{
				name: "twitter:description",
				content: "50+ free tools for text, PDF, image, code and password work. No uploads, no sign-up."
			},
			...imageMeta()
		],
		links: [{
			rel: "canonical",
			href: `${SITE_URL}/`
		}],
		scripts: [{
			type: "application/ld+json",
			children: JSON.stringify({
				"@context": "https://schema.org",
				"@type": "WebSite",
				name: "UniversalTools",
				url: `${SITE_URL}/`,
				description: "50+ free online tools for text, PDF, image, code and password work.",
				potentialAction: {
					"@type": "SearchAction",
					target: `${SITE_URL}/?q={search_term_string}`,
					"query-input": "required name=search_term_string"
				}
			})
		}, {
			type: "application/ld+json",
			children: JSON.stringify({
				"@context": "https://schema.org",
				"@type": "Organization",
				name: "UniversalTools",
				url: SITE_URL,
				logo: `${SITE_URL}/favicon.png`,
				contactPoint: {
					"@type": "ContactPoint",
					email: "prashantnadar2223@gmail.com",
					telephone: "+91-96533-86506",
					contactType: "customer support"
				}
			})
		}]
	}),
	component: lazyRouteComponent($$splitComponentImporter$11, "component")
});
function toolCategoryJsonLd(opts) {
	const url = `${SITE_URL}${opts.path}`;
	return [
		{
			type: "application/ld+json",
			children: JSON.stringify({
				"@context": "https://schema.org",
				"@type": "CollectionPage",
				name: opts.name,
				url,
				description: opts.description,
				keywords: opts.keywords.join(", "),
				isPartOf: {
					"@type": "WebSite",
					name: SITE_NAME,
					url: SITE_URL
				},
				publisher: {
					"@type": "Organization",
					name: SITE_NAME,
					url: SITE_URL
				}
			})
		},
		{
			type: "application/ld+json",
			children: JSON.stringify({
				"@context": "https://schema.org",
				"@type": "ItemList",
				name: opts.name,
				url,
				numberOfItems: opts.tools.length,
				itemListElement: opts.tools.map((t, i) => ({
					"@type": "ListItem",
					position: i + 1,
					name: t.name,
					url: `${SITE_URL}${t.url}`,
					...t.description ? { description: t.description } : {}
				}))
			})
		},
		{
			type: "application/ld+json",
			children: JSON.stringify({
				"@context": "https://schema.org",
				"@type": "BreadcrumbList",
				itemListElement: [{
					"@type": "ListItem",
					position: 1,
					name: "Home",
					item: SITE_URL
				}, {
					"@type": "ListItem",
					position: 2,
					name: opts.name,
					item: url
				}]
			})
		}
	];
}
var $$splitComponentImporter$10 = () => import("./tools.text-C6BEDM60.mjs");
var Route$12 = createFileRoute("/tools/text")({
	head: () => ({
		meta: [
			{ title: "Text Tools — Word Counter, Case Converter, Cleaner & Encoder | UniversalTools" },
			{
				name: "description",
				content: "Free online text tools: word & character counter, reading time, uppercase/lowercase & title case converter, whitespace cleaner, remove special characters, base64/URL encoder, slug generator, find & replace, ROT13, binary converter and text compare."
			},
			{
				name: "keywords",
				content: "word counter, character counter, reading time, uppercase, lowercase, title case, sentence case, remove extra spaces, remove special characters, base64 encoder, url encoder, slug generator, find and replace, rot13, text to binary, text compare, text tools online"
			},
			{
				property: "og:title",
				content: "Text Tools — Word Counter, Case Converter & Cleaner"
			},
			{
				property: "og:description",
				content: "Word & character counter, case converters, whitespace cleaner, encoders and more — all in your browser."
			},
			{
				property: "og:type",
				content: "website"
			},
			{
				property: "og:url",
				content: "https://universaltools.in/tools/text"
			},
			{
				name: "twitter:card",
				content: "summary_large_image"
			},
			{
				name: "twitter:title",
				content: "Text Tools — UniversalTools"
			},
			{
				name: "twitter:description",
				content: "Word & character counter, case converters, cleaners and encoders — all in your browser."
			},
			...imageMeta()
		],
		links: [{
			rel: "canonical",
			href: "https://universaltools.in/tools/text"
		}],
		scripts: toolCategoryJsonLd({
			path: "/tools/text",
			name: "Text Tools",
			description: "Free browser-based text utilities: counters, case converters, cleaners, encoders and comparators.",
			keywords: [
				"word counter",
				"character counter",
				"reading time",
				"case converter",
				"remove special characters",
				"base64 encoder",
				"slug generator",
				"find and replace",
				"text compare"
			],
			tools: [
				{
					name: "Word & Character Counter",
					url: "/tools/text#word-count",
					description: "Count words, characters, sentences and reading time."
				},
				{
					name: "Case Converter",
					url: "/tools/text#transform",
					description: "UPPERCASE, lowercase, Title Case, Sentence case, reverse and invert."
				},
				{
					name: "Text Cleaner",
					url: "/tools/text#clean",
					description: "Remove extra spaces, special characters, numbers and empty lines."
				},
				{
					name: "Base64 / URL Encoder",
					url: "/tools/text#encode",
					description: "Encode and decode Base64 and URL strings."
				},
				{
					name: "Slug Generator",
					url: "/tools/text#slug",
					description: "Turn any text into a URL-safe slug."
				},
				{
					name: "Find & Replace",
					url: "/tools/text#find-replace",
					description: "Bulk replace text with optional regex."
				},
				{
					name: "Text Compare",
					url: "/tools/text#compare",
					description: "Compare two texts line by line."
				}
			]
		})
	}),
	component: lazyRouteComponent($$splitComponentImporter$10, "component")
});
var $$splitComponentImporter$9 = () => import("./tools.productivity-CzWq2aaL.mjs");
var Route$11 = createFileRoute("/tools/productivity")({
	head: () => ({
		meta: [
			{ title: "Productivity Tools — Timer, To-Do, Calculators, Converters | UniversalTools" },
			{
				name: "description",
				content: "Free productivity tools: countdown timer, to-do list, calculator, currency, unit converters (length, mass, area, time, data), timezone converter, finance (loan/EMI, investment), date difference, discount, BMI, temperature and GST calculators."
			},
			{
				name: "keywords",
				content: "timer, to do list, calculator, currency converter, unit converter, length converter, mass converter, area converter, time converter, data converter, timezone converter, date difference, discount calculator, bmi calculator, temperature converter, gst calculator, loan emi, sip calculator"
			},
			{
				property: "og:title",
				content: "Productivity Tools — UniversalTools"
			},
			{
				property: "og:description",
				content: "Timers, calculators and unit converters — free and in your browser."
			},
			{
				property: "og:type",
				content: "website"
			},
			{
				property: "og:url",
				content: "https://universaltools.in/tools/productivity"
			},
			{
				name: "twitter:card",
				content: "summary_large_image"
			},
			{
				name: "twitter:title",
				content: "Productivity Tools — UniversalTools"
			},
			{
				name: "twitter:description",
				content: "Timers, calculators and unit converters, free in your browser."
			},
			...imageMeta()
		],
		links: [{
			rel: "canonical",
			href: "https://universaltools.in/tools/productivity"
		}],
		scripts: (() => {
			const tools = [
				{
					name: "Timer",
					url: "/tools/productivity#timer",
					description: "Free online countdown timer with alarm — set minutes and seconds and get an audible alert when time is up."
				},
				{
					name: "To-Do List",
					url: "/tools/productivity#todo",
					description: "Free browser-based to-do list. Tasks are stored locally on your device — no sign-in required."
				},
				{
					name: "Calculator",
					url: "/tools/productivity#calculator",
					description: "Free online calculator for basic arithmetic, percentages and quick math expressions."
				},
				{
					name: "Currency Converter",
					url: "/tools/productivity#currency",
					description: "Convert between USD, EUR, GBP, INR, JPY and other major currencies with reference rates."
				},
				{
					name: "Timezone Converter",
					url: "/tools/productivity#timezone",
					description: "Convert times across world timezones — meeting planner style, in your browser."
				},
				{
					name: "Unit Converter",
					url: "/tools/productivity#unit",
					description: "Quick general-purpose unit converter for everyday values."
				},
				{
					name: "Length Converter",
					url: "/tools/productivity#length",
					description: "Convert meters, centimeters, millimeters, kilometers, miles, feet and inches instantly."
				},
				{
					name: "Mass / Weight Converter",
					url: "/tools/productivity#mass",
					description: "Convert kilograms, grams, tonnes, milligrams, pounds, ounces and carats."
				},
				{
					name: "Area Converter",
					url: "/tools/productivity#area",
					description: "Convert square meters, square feet, acres and hectares."
				},
				{
					name: "Time Converter",
					url: "/tools/productivity#time",
					description: "Convert years, days, hours, minutes, seconds, milliseconds and microseconds."
				},
				{
					name: "Data Size Converter",
					url: "/tools/productivity#data",
					description: "Convert bits, bytes, KB, MB, GB, TB and PB."
				},
				{
					name: "Temperature Converter",
					url: "/tools/productivity#temperature",
					description: "Convert Celsius, Fahrenheit and Kelvin temperatures."
				},
				{
					name: "Finance Calculator",
					url: "/tools/productivity#finance",
					description: "Loan EMI calculator and SIP investment return calculator in one place."
				},
				{
					name: "Date Difference Calculator",
					url: "/tools/productivity#date-diff",
					description: "Calculate years, months and days between any two dates."
				},
				{
					name: "Discount Calculator",
					url: "/tools/productivity#discount",
					description: "Find the final price after applying a percentage discount."
				},
				{
					name: "BMI Calculator",
					url: "/tools/productivity#bmi",
					description: "Body Mass Index calculator with metric and imperial input."
				},
				{
					name: "GST Calculator",
					url: "/tools/productivity#gst",
					description: "Add or remove GST from any amount at any tax rate."
				},
				{
					name: "Volume Converter",
					url: "/tools/productivity#volume",
					description: "Convert liters, milliliters, cubic meters, gallons, quarts, pints, cups and more."
				},
				{
					name: "Speed Converter",
					url: "/tools/productivity#speed",
					description: "Convert m/s, km/h, mph, knots, mach and speed of light."
				},
				{
					name: "Numeral System Converter",
					url: "/tools/productivity#numeral",
					description: "Convert numbers between binary, octal, decimal and hexadecimal."
				}
			];
			const base = toolCategoryJsonLd({
				path: "/tools/productivity",
				name: "Productivity Tools",
				description: "Free browser-based productivity utilities: timers, calculators, and unit converters.",
				keywords: [
					"timer",
					"to do",
					"calculator",
					"unit converter",
					"timezone",
					"finance",
					"loan emi",
					"bmi",
					"gst"
				],
				tools
			});
			const perTool = tools.map((t) => ({
				type: "application/ld+json",
				children: JSON.stringify({
					"@context": "https://schema.org",
					"@type": "SoftwareApplication",
					name: t.name,
					url: `https://universaltools.in${t.url}`,
					applicationCategory: "UtilitiesApplication",
					operatingSystem: "Any (browser)",
					description: t.description,
					offers: {
						"@type": "Offer",
						price: "0",
						priceCurrency: "USD"
					},
					isPartOf: {
						"@type": "WebSite",
						name: "UniversalTools",
						url: "https://universaltools.in"
					}
				})
			}));
			return [...base, ...perTool];
		})()
	}),
	component: lazyRouteComponent($$splitComponentImporter$9, "component")
});
var $$splitComponentImporter$8 = () => import("./tools.pdf-DGN2G7cP.mjs");
var Route$10 = createFileRoute("/tools/pdf")({
	ssr: false,
	head: () => ({
		meta: [
			{ title: "PDF Tools — Merge, Split, Compress, Rotate, Watermark & Unlock | UniversalTools" },
			{
				name: "description",
				content: "Free in-browser PDF tools: merge PDFs, split PDF, compress PDF, rotate pages, remove & extract pages, add page numbers, add watermark, crop PDF, unlock PDF, convert JPG/PNG to PDF and PDF to JPG — files never leave your device."
			},
			{
				name: "keywords",
				content: "merge pdf, split pdf, compress pdf, rotate pdf, watermark pdf, page numbers pdf, extract pdf pages, remove pdf pages, unlock pdf, protect pdf, jpg to pdf, png to pdf, pdf to jpg, crop pdf, online pdf tools"
			},
			{
				property: "og:title",
				content: "PDF Tools — Merge, Split, Compress & More"
			},
			{
				property: "og:description",
				content: "Merge, split, rotate, protect, watermark and compress PDFs — 100% in your browser."
			},
			{
				property: "og:type",
				content: "website"
			},
			{
				property: "og:url",
				content: "https://universaltools.in/tools/pdf"
			},
			{
				name: "twitter:card",
				content: "summary_large_image"
			},
			{
				name: "twitter:title",
				content: "PDF Tools — UniversalTools"
			},
			{
				name: "twitter:description",
				content: "Merge, split, rotate, protect and watermark PDFs — 100% in your browser."
			},
			...imageMeta()
		],
		links: [{
			rel: "canonical",
			href: "https://universaltools.in/tools/pdf"
		}],
		scripts: toolCategoryJsonLd({
			path: "/tools/pdf",
			name: "PDF Tools",
			description: "Free browser-based PDF utilities: merge, split, compress, rotate, watermark, unlock and convert.",
			keywords: [
				"merge pdf",
				"split pdf",
				"compress pdf",
				"rotate pdf",
				"unlock pdf",
				"watermark pdf",
				"jpg to pdf",
				"pdf to jpg"
			],
			tools: [
				{
					name: "Merge PDF",
					url: "/tools/pdf#merge",
					description: "Combine multiple PDF files into one."
				},
				{
					name: "Split PDF",
					url: "/tools/pdf#split",
					description: "Split a PDF by page ranges."
				},
				{
					name: "Compress PDF",
					url: "/tools/pdf#compress",
					description: "Reduce PDF file size."
				},
				{
					name: "Rotate PDF",
					url: "/tools/pdf#rotate",
					description: "Rotate PDF pages 90°, 180° or 270°."
				},
				{
					name: "Remove Pages",
					url: "/tools/pdf#remove-pages",
					description: "Delete specific pages from a PDF."
				},
				{
					name: "Extract Pages",
					url: "/tools/pdf#extract-pages",
					description: "Keep only selected pages."
				},
				{
					name: "Add Page Numbers",
					url: "/tools/pdf#page-numbers",
					description: "Number the pages of a PDF."
				},
				{
					name: "Add Watermark",
					url: "/tools/pdf#watermark",
					description: "Stamp a text watermark on every page."
				},
				{
					name: "Crop PDF",
					url: "/tools/pdf#crop",
					description: "Crop margins from a PDF."
				},
				{
					name: "Unlock PDF",
					url: "/tools/pdf#unlock",
					description: "Remove password protection from a PDF."
				},
				{
					name: "Protect PDF",
					url: "/tools/pdf#protect",
					description: "Add a password to a PDF."
				},
				{
					name: "JPG / PNG to PDF",
					url: "/tools/pdf#jpg-to-pdf",
					description: "Convert images into a single PDF."
				},
				{
					name: "PDF to JPG",
					url: "/tools/pdf#pdf-to-jpg",
					description: "Render PDF pages as JPG images."
				},
				{
					name: "Word to PDF",
					url: "/tools/pdf#word-to-pdf",
					description: "Convert Word documents to PDF."
				},
				{
					name: "PowerPoint to PDF",
					url: "/tools/pdf#powerpoint-to-pdf",
					description: "Convert PowerPoint presentations to PDF."
				},
				{
					name: "Excel to PDF",
					url: "/tools/pdf#excel-to-pdf",
					description: "Convert Excel spreadsheets to PDF."
				},
				{
					name: "HTML to PDF",
					url: "/tools/pdf#html-to-pdf",
					description: "Convert HTML pages to PDF."
				},
				{
					name: "PDF to Word",
					url: "/tools/pdf#pdf-to-word",
					description: "Convert PDF into editable Word documents."
				},
				{
					name: "PDF to PowerPoint",
					url: "/tools/pdf#pdf-to-powerpoint",
					description: "Convert PDF into editable PowerPoint presentations."
				},
				{
					name: "PDF to Excel",
					url: "/tools/pdf#pdf-to-excel",
					description: "Extract PDF tables into Excel spreadsheets."
				},
				{
					name: "PDF to PDF/A",
					url: "/tools/pdf#pdf-to-pdfa",
					description: "Convert a PDF to the PDF/A archival standard."
				},
				{
					name: "Sign PDF",
					url: "/tools/pdf#sign",
					description: "Add a digital signature to a PDF."
				},
				{
					name: "Redact PDF",
					url: "/tools/pdf#redact",
					description: "Permanently redact sensitive content from a PDF."
				},
				{
					name: "Compare PDF",
					url: "/tools/pdf#compare",
					description: "Compare two PDFs and highlight differences."
				}
			]
		})
	}),
	component: lazyRouteComponent($$splitComponentImporter$8, "component")
});
var $$splitComponentImporter$7 = () => import("./tools.password-BYD_n-Mb.mjs");
var Route$9 = createFileRoute("/tools/password")({
	head: () => ({
		meta: [
			{ title: "Password Tools — Strong Password Generator & Strength Test | UniversalTools" },
			{
				name: "description",
				content: "Create strong random passwords with custom length, uppercase, lowercase, numbers and symbols. Test password strength with our free password checker. Also generates memorable passphrases and numeric PINs — 100% offline in your browser."
			},
			{
				name: "keywords",
				content: "password generator, strong password generator, random password, password strength meter, password strength test, password checker, secure password, passphrase generator, pin generator, how strong is my password, online password tools"
			},
			{
				property: "og:title",
				content: "Password Generator & Strength Test — UniversalTools"
			},
			{
				property: "og:description",
				content: "Generate strong passwords, check strength and create passphrases — securely, offline in your browser."
			},
			{
				property: "og:type",
				content: "website"
			},
			{
				property: "og:url",
				content: "https://universaltools.in/tools/password"
			},
			{
				name: "twitter:card",
				content: "summary_large_image"
			},
			{
				name: "twitter:title",
				content: "Password Generator & Strength Test — UniversalTools"
			},
			{
				name: "twitter:description",
				content: "Generate strong passwords, check strength and create passphrases in your browser."
			},
			...imageMeta()
		],
		links: [{
			rel: "canonical",
			href: "https://universaltools.in/tools/password"
		}],
		scripts: toolCategoryJsonLd({
			path: "/tools/password",
			name: "Password Tools",
			description: "Free browser-based password utilities: generator, strength meter, passphrase and PIN.",
			keywords: [
				"password generator",
				"password strength",
				"password test",
				"random password",
				"passphrase generator",
				"pin generator",
				"secure password"
			],
			tools: [
				{
					name: "Password Generator",
					url: "/tools/password#generate",
					description: "Strong random passwords with custom length and character mix."
				},
				{
					name: "Password Strength Meter",
					url: "/tools/password#strength",
					description: "Test how strong your password is."
				},
				{
					name: "Passphrase Generator",
					url: "/tools/password#passphrase",
					description: "Memorable multi-word passphrases."
				},
				{
					name: "PIN Generator",
					url: "/tools/password#pin",
					description: "Numeric PIN codes, 4 to 12 digits."
				}
			]
		})
	}),
	component: lazyRouteComponent($$splitComponentImporter$7, "component")
});
var $$splitComponentImporter$6 = () => import("./tools.image-V4q6sOuU.mjs");
var Route$8 = createFileRoute("/tools/image")({
	head: () => ({
		meta: [
			{ title: "Image Tools — Resize, Crop, Compress, Convert JPG/PNG/WebP | UniversalTools" },
			{
				name: "description",
				content: "Free in-browser image tools: resize, crop, rotate, flip, compress, apply filters, adjust brightness & contrast, add watermark, convert JPG/PNG/WebP, view EXIF metadata and convert images to Base64."
			},
			{
				name: "keywords",
				content: "image resizer, image compressor, image cropper, rotate image, flip image, image converter, jpg to png, png to webp, image watermark, brightness contrast, image to base64, exif metadata, online image tools"
			},
			{
				property: "og:title",
				content: "Image Tools — Resize, Crop, Compress & Convert"
			},
			{
				property: "og:description",
				content: "Resize, crop, rotate, filter and convert JPG/PNG/WebP images — no uploads, no wait."
			},
			{
				property: "og:type",
				content: "website"
			},
			{
				property: "og:url",
				content: "https://universaltools.in/tools/image"
			},
			{
				name: "twitter:card",
				content: "summary_large_image"
			},
			{
				name: "twitter:title",
				content: "Image Tools — UniversalTools"
			},
			{
				name: "twitter:description",
				content: "Resize, crop, rotate, filter and convert JPG/PNG/WebP images in your browser."
			},
			...imageMeta()
		],
		links: [{
			rel: "canonical",
			href: "https://universaltools.in/tools/image"
		}],
		scripts: toolCategoryJsonLd({
			path: "/tools/image",
			name: "Image Tools",
			description: "Free browser-based image utilities: resize, crop, compress, convert, watermark and inspect.",
			keywords: [
				"image resizer",
				"image compressor",
				"image converter",
				"image cropper",
				"image watermark",
				"jpg to png",
				"png to webp",
				"image to base64"
			],
			tools: [
				{
					name: "Resize Image",
					url: "/tools/image#resize",
					description: "Resize by pixels or percentage."
				},
				{
					name: "Crop Image",
					url: "/tools/image#crop",
					description: "Crop image to any region."
				},
				{
					name: "Rotate Image",
					url: "/tools/image#rotate",
					description: "Rotate 90°, 180° or 270°."
				},
				{
					name: "Flip Image",
					url: "/tools/image#flip",
					description: "Flip horizontally or vertically."
				},
				{
					name: "Compress Image",
					url: "/tools/image#compress",
					description: "Reduce JPG/PNG file size."
				},
				{
					name: "Convert Format",
					url: "/tools/image#convert",
					description: "Convert between JPG, PNG and WebP."
				},
				{
					name: "Brightness & Contrast",
					url: "/tools/image#adjust",
					description: "Adjust brightness and contrast."
				},
				{
					name: "Add Watermark",
					url: "/tools/image#watermark",
					description: "Overlay a text watermark."
				},
				{
					name: "Image to Base64",
					url: "/tools/image#base64",
					description: "Encode any image as a Base64 data URI."
				},
				{
					name: "Image Metadata",
					url: "/tools/image#meta",
					description: "View width, height and EXIF details."
				}
			]
		})
	}),
	component: lazyRouteComponent($$splitComponentImporter$6, "component")
});
var $$splitComponentImporter$5 = () => import("./tools.color-DBuRuQHm.mjs");
var Route$7 = createFileRoute("/tools/color")({
	head: () => ({
		meta: [
			{ title: "Color Tools — Picker, Converter, Contrast, Gradient, Tailwind Finder | UniversalTools" },
			{
				name: "description",
				content: "Free color tools: color picker, HEX ↔ RGB ↔ HSL ↔ HWB ↔ CMYK converter, blender, shades and tints, WCAG contrast analyzer, multi-stop gradient builder and nearest Tailwind color class finder."
			},
			{
				name: "keywords",
				content: "color picker, color converter, hex to rgb, rgb to hex, hsl, hwb, cmyk, color mixer, color blender, wcag contrast checker, contrast analyzer, gradient generator, css gradient, tailwind color finder, nearest tailwind class, shades and tints"
			},
			{
				property: "og:title",
				content: "Color Tools — Picker, Converter, Contrast & Gradient"
			},
			{
				property: "og:description",
				content: "Everything you need for colors in the browser: picker, converters, WCAG contrast checker, gradient builder and Tailwind finder."
			},
			{
				property: "og:type",
				content: "website"
			},
			{
				property: "og:url",
				content: "https://universaltools.in/tools/color"
			},
			{
				name: "twitter:card",
				content: "summary_large_image"
			},
			{
				name: "twitter:title",
				content: "Color Tools — UniversalTools"
			},
			{
				name: "twitter:description",
				content: "Pick, convert, blend and check colors — free and in your browser."
			},
			...imageMeta()
		],
		links: [{
			rel: "canonical",
			href: "https://universaltools.in/tools/color"
		}],
		scripts: toolCategoryJsonLd({
			path: "/tools/color",
			name: "Color Tools",
			description: "Free browser-based color utilities: picker, converters, mixer, WCAG contrast, gradients and Tailwind finder.",
			keywords: [
				"color picker",
				"color converter",
				"hex rgb hsl hwb cmyk",
				"color mixer",
				"wcag contrast",
				"gradient builder",
				"tailwind color finder"
			],
			tools: [
				{
					name: "Color Picker",
					url: "/tools/color#picker",
					description: "Pick a color and grab HEX / RGB / HSL."
				},
				{
					name: "Color Converter",
					url: "/tools/color#converter",
					description: "Convert between HEX, RGB, HSL, HWB and CMYK."
				},
				{
					name: "Color Mixer",
					url: "/tools/color#mixer",
					description: "Blend two colors to find the in-between."
				},
				{
					name: "Color HEX Explorer",
					url: "/tools/color#hex",
					description: "Hex breakdown, shades and tints."
				},
				{
					name: "HSL Explorer",
					url: "/tools/color#hsl",
					description: "Hue, saturation, lightness."
				},
				{
					name: "HWB Explorer",
					url: "/tools/color#hwb",
					description: "Hue, whiteness, blackness (CSS4)."
				},
				{
					name: "CMYK Explorer",
					url: "/tools/color#cmyk",
					description: "Print-ready CMYK values."
				},
				{
					name: "RGB Channels",
					url: "/tools/color#rgb",
					description: "Red, green, blue channel breakdown."
				},
				{
					name: "Contrast Analyzer",
					url: "/tools/color#contrast",
					description: "WCAG AA/AAA contrast checker."
				},
				{
					name: "Gradient Builder",
					url: "/tools/color#gradient",
					description: "Multi-stop CSS gradients."
				},
				{
					name: "Tailwind Color Finder",
					url: "/tools/color#tailwind",
					description: "Nearest Tailwind class for any color."
				}
			]
		})
	}),
	component: lazyRouteComponent($$splitComponentImporter$5, "component")
});
var $$splitComponentImporter$4 = () => import("./tools.code-BrtA75vN.mjs");
var Route$6 = createFileRoute("/tools/code")({
	head: () => ({
		meta: [
			{ title: "Code Tools — HTML Editor, JSON, JWT, Regex, Hashes, Markdown | UniversalTools" },
			{
				name: "description",
				content: "Free in-browser code tools: HTML/CSS/JS live editor, JSON/XML/HTML/SQL formatters, JWT decoder, regex tester, UUID and hash generator (MD5, SHA-1, SHA-256, SHA-512), Markdown to HTML, number base converter, AES phrase encryption and browser feature detector."
			},
			{
				name: "keywords",
				content: "html live editor, json formatter, xml formatter, sql formatter, jwt decoder, regex tester, uuid generator, md5, sha256, sha512, timestamp converter, color converter, html minifier, html formatter, css beautifier, markdown to html, number base converter, binary hex converter, aes encrypt, php formatter, browser feature detection, online code tools"
			},
			{
				property: "og:title",
				content: "Code Tools — JSON, XML, JWT, Regex & More"
			},
			{
				property: "og:description",
				content: "Format JSON/XML/SQL, decode JWTs, test regex, generate UUIDs and hashes — right in the browser."
			},
			{
				property: "og:type",
				content: "website"
			},
			{
				property: "og:url",
				content: "https://universaltools.in/tools/code"
			},
			{
				name: "twitter:card",
				content: "summary_large_image"
			},
			{
				name: "twitter:title",
				content: "Code Tools — UniversalTools"
			},
			{
				name: "twitter:description",
				content: "Format JSON/XML/SQL, decode JWTs, test regex, generate UUIDs and hashes."
			},
			...imageMeta()
		],
		links: [{
			rel: "canonical",
			href: "https://universaltools.in/tools/code"
		}],
		scripts: toolCategoryJsonLd({
			path: "/tools/code",
			name: "Code Tools",
			description: "Free browser-based developer utilities: formatters, decoders, regex tester and generators.",
			keywords: [
				"json formatter",
				"xml formatter",
				"jwt decoder",
				"regex tester",
				"uuid generator",
				"md5",
				"sha256",
				"timestamp converter",
				"color converter"
			],
			tools: [
				{
					name: "JSON Formatter",
					url: "/tools/code#json",
					description: "Format, minify and validate JSON."
				},
				{
					name: "XML Formatter",
					url: "/tools/code#xml",
					description: "Pretty-print and minify XML."
				},
				{
					name: "SQL Formatter",
					url: "/tools/code#sql",
					description: "Beautify SQL statements."
				},
				{
					name: "HTML Minifier",
					url: "/tools/code#html",
					description: "Minify HTML markup."
				},
				{
					name: "CSS Beautifier",
					url: "/tools/code#css",
					description: "Format CSS rules."
				},
				{
					name: "JS Beautifier",
					url: "/tools/code#js",
					description: "Format and minify JavaScript."
				},
				{
					name: "JWT Decoder",
					url: "/tools/code#jwt",
					description: "Inspect JWT header and payload."
				},
				{
					name: "Regex Tester",
					url: "/tools/code#regex",
					description: "Test regular expressions live."
				},
				{
					name: "UUID Generator",
					url: "/tools/code#uuid",
					description: "Generate v4 UUIDs."
				},
				{
					name: "Hash Generator",
					url: "/tools/code#hash-gen",
					description: "MD5, SHA-1, SHA-256, SHA-512 hashes."
				},
				{
					name: "Timestamp Converter",
					url: "/tools/code#timestamp",
					description: "Convert Unix timestamps."
				},
				{
					name: "Color Converter",
					url: "/tools/code#color-convert",
					description: "HEX ↔ RGB ↔ HSL."
				},
				{
					name: "HTML Live Editor",
					url: "/tools/code#html-editor",
					description: "Live HTML/CSS/JS sandbox."
				},
				{
					name: "Markdown to HTML",
					url: "/tools/code#markdown",
					description: "Render Markdown as HTML."
				},
				{
					name: "Number Base Converter",
					url: "/tools/code#number-base",
					description: "Binary, octal, decimal, hex."
				},
				{
					name: "HTML Formatter",
					url: "/tools/code#html-format",
					description: "Pretty-print HTML markup."
				},
				{
					name: "PHP Formatter",
					url: "/tools/code#php-format",
					description: "Re-indent PHP source."
				},
				{
					name: "Phrase Encrypt / Decrypt",
					url: "/tools/code#phrase-crypt",
					description: "AES-GCM symmetric encryption with a passphrase."
				},
				{
					name: "Browser Feature Detection",
					url: "/tools/code#browser-features",
					description: "Report which web APIs are supported."
				}
			]
		})
	}),
	component: lazyRouteComponent($$splitComponentImporter$4, "component")
});
var $$splitComponentImporter$3 = () => import("./dashboard-DxIyB5eF.mjs");
var Route$5 = createFileRoute("/_authenticated/dashboard")({
	head: () => ({ meta: [{ title: "Dashboard — UniversalTools" }, {
		name: "robots",
		content: "noindex"
	}] }),
	component: lazyRouteComponent($$splitComponentImporter$3, "component")
});
var $$splitComponentImporter$2 = () => import("../_admin-Dhuu_2UW.mjs");
var Route$4 = createFileRoute("/_authenticated/_admin")({ component: lazyRouteComponent($$splitComponentImporter$2, "component") });
var $$splitComponentImporter$1 = () => import("./profile-DbOWILjz.mjs");
var Route$3 = createFileRoute("/_authenticated/_admin/profile")({
	head: () => ({ meta: [{ title: "My Profile — UniversalTools" }, {
		name: "robots",
		content: "noindex"
	}] }),
	component: lazyRouteComponent($$splitComponentImporter$1, "component")
});
var $$splitComponentImporter = () => import("./admin-BWXQ45wu.mjs");
var Route$2 = createFileRoute("/_authenticated/_admin/admin")({
	head: () => ({ meta: [{ title: "Admin panel — UniversalTools" }, {
		name: "robots",
		content: "noindex"
	}] }),
	component: lazyRouteComponent($$splitComponentImporter, "component")
});
function csvCell$1(v) {
	if (v == null) return "";
	const s = typeof v === "object" ? JSON.stringify(v) : String(v);
	if (/[",\n\r]/.test(s)) return `"${s.replace(/"/g, "\"\"")}"`;
	return s;
}
function csvRow$1(cells) {
	return cells.map(csvCell$1).join(",") + "\n";
}
async function requireAdmin$1(request) {
	const url = processModule.env.SUPABASE_URL;
	const key = processModule.env.SUPABASE_PUBLISHABLE_KEY;
	const auth = request.headers.get("authorization") || "";
	if (!auth.toLowerCase().startsWith("bearer ")) return { error: new Response("Unauthorized", { status: 401 }) };
	const supabase = createClient(url, key, {
		global: { headers: { Authorization: auth } },
		auth: {
			persistSession: false,
			autoRefreshToken: false
		}
	});
	const { data: u, error: uErr } = await supabase.auth.getUser();
	if (uErr || !u.user) return { error: new Response("Unauthorized", { status: 401 }) };
	const { data: ok, error: rErr } = await supabase.rpc("has_role", {
		_user_id: u.user.id,
		_role: "admin"
	});
	if (rErr || !ok) return { error: new Response("Forbidden", { status: 403 }) };
	return {
		supabase,
		userId: u.user.id
	};
}
var Route$1 = createFileRoute("/api/admin/export/tool-usage")({ server: { handlers: { GET: async ({ request }) => {
	const gate = await requireAdmin$1(request);
	if ("error" in gate) return gate.error;
	const { supabase, userId } = gate;
	const url = new URL(request.url);
	const from = url.searchParams.get("from");
	const to = url.searchParams.get("to");
	const actor = url.searchParams.get("actor");
	const tool = url.searchParams.get("tool");
	const kind = url.searchParams.get("kind") || "all";
	const PAGE = 1e3;
	let offset = 0;
	let total = 0;
	const stream = new ReadableStream({ async start(controller) {
		const enc = new TextEncoder();
		controller.enqueue(enc.encode(csvRow$1([
			"kind",
			"actor_key",
			"email",
			"tool_slug",
			"created_at",
			"country_code"
		])));
		try {
			while (true) {
				const { data, error } = await supabase.rpc("admin_usage_search", {
					_actor: actor,
					_tool: tool,
					_from: from,
					_to: to,
					_kind: kind,
					_limit: PAGE,
					_offset: offset
				});
				if (error) throw error;
				const rows = data ?? [];
				if (!rows.length) break;
				for (const r of rows) controller.enqueue(enc.encode(csvRow$1([
					r.kind,
					r.actor_key,
					r.email,
					r.tool_slug,
					r.created_at,
					r.country_code
				])));
				total += rows.length;
				if (rows.length < PAGE) break;
				offset += PAGE;
			}
			await supabase.from("audit_logs").insert({
				actor_id: userId,
				action: "admin_export_tool_usage_csv",
				metadata: {
					from,
					to,
					actor,
					tool,
					kind,
					rows: total
				}
			});
		} catch (e) {
			controller.enqueue(enc.encode(`# error: ${e.message}\n`));
		} finally {
			controller.close();
		}
	} });
	return new Response(stream, { headers: {
		"Content-Type": "text/csv; charset=utf-8",
		"Content-Disposition": `attachment; filename="tool-usage-${(/* @__PURE__ */ new Date()).toISOString().slice(0, 10)}.csv"`,
		"Cache-Control": "no-store"
	} });
} } } });
function csvCell(v) {
	if (v == null) return "";
	const s = typeof v === "object" ? JSON.stringify(v) : String(v);
	if (/[",\n\r]/.test(s)) return `"${s.replace(/"/g, "\"\"")}"`;
	return s;
}
function csvRow(cells) {
	return cells.map(csvCell).join(",") + "\n";
}
async function requireAdmin(request) {
	const url = processModule.env.SUPABASE_URL;
	const key = processModule.env.SUPABASE_PUBLISHABLE_KEY;
	const auth = request.headers.get("authorization") || "";
	if (!auth.toLowerCase().startsWith("bearer ")) return { error: new Response("Unauthorized", { status: 401 }) };
	const supabase = createClient(url, key, {
		global: { headers: { Authorization: auth } },
		auth: {
			persistSession: false,
			autoRefreshToken: false
		}
	});
	const { data: u, error: uErr } = await supabase.auth.getUser();
	if (uErr || !u.user) return { error: new Response("Unauthorized", { status: 401 }) };
	const { data: ok, error: rErr } = await supabase.rpc("has_role", {
		_user_id: u.user.id,
		_role: "admin"
	});
	if (rErr || !ok) return { error: new Response("Forbidden", { status: 403 }) };
	return {
		supabase,
		userId: u.user.id
	};
}
var Route = createFileRoute("/api/admin/export/audit-logs")({ server: { handlers: { GET: async ({ request }) => {
	const gate = await requireAdmin(request);
	if ("error" in gate) return gate.error;
	const { supabase, userId } = gate;
	const url = new URL(request.url);
	const from = url.searchParams.get("from");
	const to = url.searchParams.get("to");
	const actor = url.searchParams.get("actor");
	const action = url.searchParams.get("action");
	const PAGE = 1e3;
	let offset = 0;
	let total = 0;
	const stream = new ReadableStream({ async start(controller) {
		const enc = new TextEncoder();
		controller.enqueue(enc.encode(csvRow([
			"id",
			"actor_id",
			"email",
			"action",
			"metadata",
			"created_at"
		])));
		try {
			while (true) {
				const { data, error } = await supabase.rpc("admin_audit_search", {
					_actor: actor,
					_action: action,
					_from: from,
					_to: to,
					_limit: PAGE,
					_offset: offset
				});
				if (error) throw error;
				const rows = data ?? [];
				if (!rows.length) break;
				for (const r of rows) controller.enqueue(enc.encode(csvRow([
					r.id,
					r.actor_id,
					r.email,
					r.action,
					r.metadata,
					r.created_at
				])));
				total += rows.length;
				if (rows.length < PAGE) break;
				offset += PAGE;
			}
			await supabase.from("audit_logs").insert({
				actor_id: userId,
				action: "admin_export_audit_logs_csv",
				metadata: {
					from,
					to,
					actor,
					action,
					rows: total
				}
			});
		} catch (e) {
			controller.enqueue(enc.encode(`# error: ${e.message}\n`));
		} finally {
			controller.close();
		}
	} });
	return new Response(stream, { headers: {
		"Content-Type": "text/csv; charset=utf-8",
		"Content-Disposition": `attachment; filename="audit-logs-${(/* @__PURE__ */ new Date()).toISOString().slice(0, 10)}.csv"`,
		"Cache-Control": "no-store"
	} });
} } } });
var WhyChooseUsRoute = Route$26.update({
	id: "/why-choose-us",
	path: "/why-choose-us",
	getParentRoute: () => Route$27
});
var TermsRoute = Route$25.update({
	id: "/terms",
	path: "/terms",
	getParentRoute: () => Route$27
});
var SitemapDotxmlRoute = Route$24.update({
	id: "/sitemap.xml",
	path: "/sitemap.xml",
	getParentRoute: () => Route$27
});
var SignupRoute = Route$23.update({
	id: "/signup",
	path: "/signup",
	getParentRoute: () => Route$27
});
var ResetPasswordRoute = Route$22.update({
	id: "/reset-password",
	path: "/reset-password",
	getParentRoute: () => Route$27
});
var PrivacyRoute = Route$21.update({
	id: "/privacy",
	path: "/privacy",
	getParentRoute: () => Route$27
});
var PricingRoute = Route$20.update({
	id: "/pricing",
	path: "/pricing",
	getParentRoute: () => Route$27
});
var LoginRoute = Route$19.update({
	id: "/login",
	path: "/login",
	getParentRoute: () => Route$27
});
var FavoritesRoute = Route$18.update({
	id: "/favorites",
	path: "/favorites",
	getParentRoute: () => Route$27
});
var ContactRoute = Route$17.update({
	id: "/contact",
	path: "/contact",
	getParentRoute: () => Route$27
});
var AuthRoute = Route$16.update({
	id: "/auth",
	path: "/auth",
	getParentRoute: () => Route$27
});
var AboutRoute = Route$15.update({
	id: "/about",
	path: "/about",
	getParentRoute: () => Route$27
});
var AuthenticatedRouteRoute = Route$14.update({
	id: "/_authenticated",
	getParentRoute: () => Route$27
});
var IndexRoute = Route$13.update({
	id: "/",
	path: "/",
	getParentRoute: () => Route$27
});
var ToolsTextRoute = Route$12.update({
	id: "/tools/text",
	path: "/tools/text",
	getParentRoute: () => Route$27
});
var ToolsProductivityRoute = Route$11.update({
	id: "/tools/productivity",
	path: "/tools/productivity",
	getParentRoute: () => Route$27
});
var ToolsPdfRoute = Route$10.update({
	id: "/tools/pdf",
	path: "/tools/pdf",
	getParentRoute: () => Route$27
});
var ToolsPasswordRoute = Route$9.update({
	id: "/tools/password",
	path: "/tools/password",
	getParentRoute: () => Route$27
});
var ToolsImageRoute = Route$8.update({
	id: "/tools/image",
	path: "/tools/image",
	getParentRoute: () => Route$27
});
var ToolsColorRoute = Route$7.update({
	id: "/tools/color",
	path: "/tools/color",
	getParentRoute: () => Route$27
});
var ToolsCodeRoute = Route$6.update({
	id: "/tools/code",
	path: "/tools/code",
	getParentRoute: () => Route$27
});
var AuthenticatedDashboardRoute = Route$5.update({
	id: "/dashboard",
	path: "/dashboard",
	getParentRoute: () => AuthenticatedRouteRoute
});
var AuthenticatedAdminRoute = Route$4.update({
	id: "/_admin",
	getParentRoute: () => AuthenticatedRouteRoute
});
var AuthenticatedAdminProfileRoute = Route$3.update({
	id: "/profile",
	path: "/profile",
	getParentRoute: () => AuthenticatedAdminRoute
});
var AuthenticatedAdminAdminRoute = Route$2.update({
	id: "/admin",
	path: "/admin",
	getParentRoute: () => AuthenticatedAdminRoute
});
var ApiAdminExportToolUsageRoute = Route$1.update({
	id: "/api/admin/export/tool-usage",
	path: "/api/admin/export/tool-usage",
	getParentRoute: () => Route$27
});
var ApiAdminExportAuditLogsRoute = Route.update({
	id: "/api/admin/export/audit-logs",
	path: "/api/admin/export/audit-logs",
	getParentRoute: () => Route$27
});
var AuthenticatedAdminRouteChildren = {
	AuthenticatedAdminAdminRoute,
	AuthenticatedAdminProfileRoute
};
var AuthenticatedRouteRouteChildren = {
	AuthenticatedAdminRoute: AuthenticatedAdminRoute._addFileChildren(AuthenticatedAdminRouteChildren),
	AuthenticatedDashboardRoute
};
var rootRouteChildren = {
	IndexRoute,
	AuthenticatedRouteRoute: AuthenticatedRouteRoute._addFileChildren(AuthenticatedRouteRouteChildren),
	AboutRoute,
	AuthRoute,
	ContactRoute,
	FavoritesRoute,
	LoginRoute,
	PricingRoute,
	PrivacyRoute,
	ResetPasswordRoute,
	SignupRoute,
	SitemapDotxmlRoute,
	TermsRoute,
	WhyChooseUsRoute,
	ToolsCodeRoute,
	ToolsColorRoute,
	ToolsImageRoute,
	ToolsPasswordRoute,
	ToolsPdfRoute,
	ToolsProductivityRoute,
	ToolsTextRoute,
	ApiAdminExportAuditLogsRoute,
	ApiAdminExportToolUsageRoute
};
var routeTree = Route$27._addFileChildren(rootRouteChildren)._addFileTypes();
function Spinner({ size = 28, label = "Loading", className = "" }) {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", {
		role: "status",
		"aria-live": "polite",
		"aria-label": label,
		className: `inline-flex items-center justify-center ${className}`,
		children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
			className: "animate-spin rounded-full border-[3px] border-blue-200 border-t-blue-600 dark:border-slate-700 dark:border-t-blue-400",
			style: {
				width: size,
				height: size
			}
		}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", {
			className: "sr-only",
			children: [label, "…"]
		})]
	});
}
function FullPageSpinner({ label = "Loading page" }) {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		role: "status",
		"aria-live": "polite",
		className: "flex min-h-[60vh] w-full flex-col items-center justify-center gap-4 bg-white dark:bg-slate-950",
		children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Spinner, {
			size: 44,
			label
		}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
			className: "text-sm font-medium text-slate-500 dark:text-slate-400",
			children: [label, "…"]
		})]
	});
}
/**
* Runtime safeguard: the app must never carry a hardcoded "bootstrap admin"
* email that auto-promotes a signup to admin. If any client code accidentally
* introduces such a pattern (e.g. `if (email === "owner@x.com") grantAdmin(...)`),
* this assertion catches it at boot in development and logs a loud warning in
* production instead of silently shipping the vulnerability.
*
* Server-side, the same invariant is enforced by:
*  - `handle_new_user()` hard-coding role='user' only
*  - the `prevent_admin_self_grant` trigger on `public.user_roles`
*  - the RESTRICTIVE RLS policy requiring `has_role(auth.uid(), 'admin')`
*
* Admin promotion is only possible via `admin_set_role` RPC called by an
* already-authenticated admin. No email-based path exists in any layer.
*/
var FORBIDDEN_PATTERNS = [
	/bootstrap[_-]?admin[_-]?email/i,
	/admin[_-]?bootstrap[_-]?email/i,
	/grant[_-]?admin[_-]?for[_-]?bootstrap/i
];
function assertNoAdminBootstrap(source) {
	if (!source) return;
	for (const p of FORBIDDEN_PATTERNS) if (p.test(source)) {
		const msg = `[security] admin bootstrap pattern detected: ${p}`;
		console.error(msg);
	}
}
/**
* Boot-time check: scan a curated allow-list of module-scope constants for
* any leaked "bootstrap admin" email. Kept intentionally narrow — this is a
* safety net, not a linter substitute.
*/
function runAdminBootstrapAudit(constants) {
	for (const [name, value] of Object.entries(constants)) {
		if (typeof value !== "string") continue;
		assertNoAdminBootstrap(`${name}=${value}`);
		if (/admin/i.test(name) && /@/.test(value)) {
			const msg = `[security] suspicious admin-email constant "${name}" — admin role must come from user_roles table, never a hardcoded email.`;
			console.error(msg);
		}
	}
}
runAdminBootstrapAudit({ NODE_ENV: "production" });
var getRouter = () => {
	return createRouter({
		routeTree,
		context: { queryClient: new QueryClient() },
		scrollRestoration: true,
		defaultPreload: "intent",
		defaultPreloadStaleTime: 0,
		defaultPendingComponent: () => /* @__PURE__ */ (0, import_jsx_runtime.jsx)(FullPageSpinner, {}),
		defaultPendingMs: 200,
		defaultPendingMinMs: 200,
		defaultNotFoundComponent: () => /* @__PURE__ */ (0, import_jsx_runtime.jsx)(NotFound, {})
	});
};
//#endregion
export { getRouter };
