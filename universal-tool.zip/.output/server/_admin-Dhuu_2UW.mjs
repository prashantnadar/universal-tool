import { o as __toESM } from "./_runtime.mjs";
import { nt as require_react } from "./_libs/@hookform/resolvers+[...].mjs";
import { t as supabase } from "./_ssr/client-CxWkeBjE.mjs";
import { t as logUsage } from "./_ssr/usage-log-DqdX7H0u.mjs";
import { M as redirect, b as useRouter, f as Outlet, g as Link } from "./_libs/@tanstack/react-router+[...].mjs";
import { r as require_jsx_runtime } from "./_libs/react+tanstack__react-query.mjs";
import { t as Slot } from "./_libs/radix-ui__react-slot.mjs";
import { n as clsx, t as cva } from "./_libs/class-variance-authority+clsx.mjs";
import { t as twMerge } from "./_libs/tailwind-merge.mjs";
import { i as ShieldAlert, o as LoaderCircle } from "./_libs/lucide-react.mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/_admin-Dhuu_2UW.js
var import_react = /* @__PURE__ */ __toESM(require_react());
var import_jsx_runtime = require_jsx_runtime();
function cn(...inputs) {
	return twMerge(clsx(inputs));
}
var buttonVariants = cva("inline-flex items-center justify-center gap-2 whitespace-nowrap rounded-md text-sm font-medium cursor-pointer transition-colors focus-visible:outline-none focus-visible:ring-1 focus-visible:ring-ring disabled:pointer-events-none disabled:opacity-50 disabled:cursor-not-allowed [&_svg]:pointer-events-none [&_svg]:size-4 [&_svg]:shrink-0", {
	variants: {
		variant: {
			default: "bg-primary text-primary-foreground shadow hover:bg-primary/90",
			destructive: "bg-destructive text-destructive-foreground shadow-sm hover:bg-destructive/90",
			outline: "border border-input bg-background shadow-sm hover:bg-accent hover:text-accent-foreground",
			secondary: "bg-secondary text-secondary-foreground shadow-sm hover:bg-secondary/80",
			ghost: "hover:bg-accent hover:text-accent-foreground",
			link: "text-primary underline-offset-4 hover:underline"
		},
		size: {
			default: "h-9 px-4 py-2",
			sm: "h-8 rounded-md px-3 text-xs",
			lg: "h-10 rounded-md px-8",
			icon: "h-9 w-9"
		}
	},
	defaultVariants: {
		variant: "default",
		size: "default"
	}
});
var Button = import_react.forwardRef(({ className, variant, size, asChild = false, ...props }, ref) => {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)(asChild ? Slot : "button", {
		className: cn(buttonVariants({
			variant,
			size,
			className
		})),
		ref,
		...props
	});
});
Button.displayName = "Button";
var alertVariants = cva("relative w-full rounded-lg border px-4 py-3 text-sm [&>svg+div]:translate-y-[-3px] [&>svg]:absolute [&>svg]:left-4 [&>svg]:top-4 [&>svg]:text-foreground [&>svg~*]:pl-7", {
	variants: { variant: {
		default: "bg-background text-foreground",
		destructive: "border-destructive/50 text-destructive dark:border-destructive [&>svg]:text-destructive"
	} },
	defaultVariants: { variant: "default" }
});
var Alert = import_react.forwardRef(({ className, variant, ...props }, ref) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
	ref,
	role: "alert",
	className: cn(alertVariants({ variant }), className),
	...props
}));
Alert.displayName = "Alert";
var AlertTitle = import_react.forwardRef(({ className, ...props }, ref) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)("h5", {
	ref,
	className: cn("mb-1 font-medium leading-none tracking-tight", className),
	...props
}));
AlertTitle.displayName = "AlertTitle";
var AlertDescription = import_react.forwardRef(({ className, ...props }, ref) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
	ref,
	className: cn("text-sm [&_p]:leading-relaxed", className),
	...props
}));
AlertDescription.displayName = "AlertDescription";
function AdminGate() {
	const router = useRouter();
	const [state, setState] = (0, import_react.useState)({ status: "checking" });
	const check = async () => {
		setState({ status: "checking" });
		logUsage("admin_gate", {
			status: "ok",
			message: "check_start"
		});
		const { data: userData, error: userErr } = await supabase.auth.getUser();
		if (userErr || !userData.user) throw redirect({
			to: "/auth",
			search: {
				redirect: "/admin",
				mode: "signin"
			}
		});
		const { data, error } = await supabase.rpc("has_role", {
			_user_id: userData.user.id,
			_role: "admin"
		});
		if (error) {
			logUsage("admin_gate", {
				status: "error",
				message: error.message
			});
			setState({
				status: "error",
				message: error.message
			});
			return;
		}
		const next = data ? { status: "ok" } : { status: "denied" };
		logUsage("admin_gate", { status: next.status === "ok" ? "ok" : "denied" });
		setState(next);
	};
	(0, import_react.useEffect)(() => {
		check().catch(() => {});
	}, []);
	if (state.status === "checking") return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "flex items-center justify-center min-h-[60vh] text-muted-foreground",
		children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(LoaderCircle, { className: "mr-2 h-4 w-4 animate-spin" }), " Verifying admin access…"]
	});
	if (state.status === "ok") return /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Outlet, {});
	const isError = state.status === "error";
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
		className: "max-w-lg mx-auto mt-16 px-4",
		children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Alert, {
			variant: "destructive",
			children: [
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)(ShieldAlert, { className: "h-4 w-4" }),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)(AlertTitle, { children: "Admin access required" }),
				/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(AlertDescription, {
					className: "space-y-3",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", { children: isError ? `We couldn't verify your admin access${state.message ? `: ${state.message}` : ""}. This is usually a temporary connection issue.` : "Your account does not have admin permissions. If you believe this is a mistake, contact the workspace owner." }), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "flex gap-2",
						children: [
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
								size: "sm",
								onClick: () => check(),
								children: "Retry"
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
								size: "sm",
								variant: "outline",
								onClick: () => router.invalidate(),
								children: "Reload"
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
								asChild: true,
								size: "sm",
								variant: "ghost",
								children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Link, {
									to: "/dashboard",
									children: "Back to dashboard"
								})
							})
						]
					})]
				})
			]
		})
	});
}
//#endregion
export { AdminGate as component };
