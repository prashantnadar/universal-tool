//#region node_modules/.nitro/vite/services/ssr/assets/_tanstack-start-manifest_v-lSCLrOI_.js
var tsrStartManifest = () => ({ routes: {
	__root__: {
		filePath: "E:/universal-tool/src/routes/__root.tsx",
		children: [
			"/",
			"/_authenticated",
			"/about",
			"/auth",
			"/contact",
			"/favorites",
			"/login",
			"/pricing",
			"/privacy",
			"/reset-password",
			"/signup",
			"/sitemap.xml",
			"/terms",
			"/why-choose-us",
			"/tools/code",
			"/tools/color",
			"/tools/image",
			"/tools/password",
			"/tools/pdf",
			"/tools/productivity",
			"/tools/text",
			"/api/admin/export/audit-logs",
			"/api/admin/export/tool-usage"
		],
		preloads: [
			"/assets/index-1K1CYJ4G.js",
			"/assets/rolldown-runtime-DAXXjFlN.js",
			"/assets/useStore-PiVi24NI.js",
			"/assets/client-CjF64JdE.js",
			"/assets/preload-helper-CZgWQFsJ.js"
		],
		scripts: [{ attrs: {
			type: "module",
			async: !0,
			src: "/assets/index-1K1CYJ4G.js"
		} }]
	},
	"/": {
		filePath: "E:/universal-tool/src/routes/index.tsx",
		children: void 0,
		preloads: [
			"/assets/routes-BYL_OU9n.js",
			"/assets/Layout-DE4XmbcJ.js",
			"/assets/createLucideIcon-B68HukcN.js",
			"/assets/usage-limits-TEVxzN-i.js",
			"/assets/Reveal-BeD4HdPn.js",
			"/assets/usage-tracking-gxCMe9A2.js"
		]
	},
	"/_authenticated": {
		filePath: "E:/universal-tool/src/routes/_authenticated/route.tsx",
		children: ["/_authenticated/_admin", "/_authenticated/dashboard"],
		preloads: ["/assets/route-CVWN7vMs.js"]
	},
	"/about": {
		filePath: "E:/universal-tool/src/routes/about.tsx",
		children: void 0,
		preloads: [
			"/assets/about-B7J1efxy.js",
			"/assets/Layout-DE4XmbcJ.js",
			"/assets/Reveal-BeD4HdPn.js"
		]
	},
	"/auth": {
		filePath: "E:/universal-tool/src/routes/auth.tsx",
		children: void 0,
		preloads: [
			"/assets/auth-qfd7U5Z9.js",
			"/assets/Layout-DE4XmbcJ.js",
			"/assets/zod-C24EXIpa.js"
		]
	},
	"/contact": {
		filePath: "E:/universal-tool/src/routes/contact.tsx",
		children: void 0,
		preloads: [
			"/assets/contact-BXGvjgrn.js",
			"/assets/Layout-DE4XmbcJ.js",
			"/assets/Reveal-BeD4HdPn.js"
		]
	},
	"/favorites": {
		filePath: "E:/universal-tool/src/routes/favorites.tsx",
		children: void 0,
		preloads: [
			"/assets/favorites-D0o5qKuI.js",
			"/assets/Layout-DE4XmbcJ.js",
			"/assets/Reveal-BeD4HdPn.js"
		]
	},
	"/login": {
		filePath: "E:/universal-tool/src/routes/login.tsx",
		children: void 0,
		preloads: ["/assets/login-DJ7LAi8J.js"]
	},
	"/pricing": {
		filePath: "E:/universal-tool/src/routes/pricing.tsx",
		children: void 0,
		preloads: [
			"/assets/pricing-CZfH6Z7j.js",
			"/assets/Layout-DE4XmbcJ.js",
			"/assets/Reveal-BeD4HdPn.js"
		]
	},
	"/privacy": {
		filePath: "E:/universal-tool/src/routes/privacy.tsx",
		children: void 0,
		preloads: [
			"/assets/privacy-BRrcD65-.js",
			"/assets/Layout-DE4XmbcJ.js",
			"/assets/Reveal-BeD4HdPn.js"
		]
	},
	"/reset-password": {
		filePath: "E:/universal-tool/src/routes/reset-password.tsx",
		children: void 0,
		preloads: [
			"/assets/reset-password-CpfyhXo5.js",
			"/assets/Layout-DE4XmbcJ.js",
			"/assets/zod-C24EXIpa.js"
		]
	},
	"/signup": {
		filePath: "E:/universal-tool/src/routes/signup.tsx",
		children: void 0,
		preloads: ["/assets/signup-DJ7LAi8J.js"]
	},
	"/terms": {
		filePath: "E:/universal-tool/src/routes/terms.tsx",
		children: void 0,
		preloads: [
			"/assets/terms-yW63y5eF.js",
			"/assets/Layout-DE4XmbcJ.js",
			"/assets/Reveal-BeD4HdPn.js"
		]
	},
	"/why-choose-us": {
		filePath: "E:/universal-tool/src/routes/why-choose-us.tsx",
		children: void 0,
		preloads: [
			"/assets/why-choose-us-Dkl3i0aI.js",
			"/assets/Layout-DE4XmbcJ.js",
			"/assets/Reveal-BeD4HdPn.js"
		]
	},
	"/_authenticated/_admin": {
		filePath: "E:/universal-tool/src/routes/_authenticated/_admin.tsx",
		children: ["/_authenticated/_admin/admin", "/_authenticated/_admin/profile"],
		preloads: [
			"/assets/_admin-BgPQvuHF.js",
			"/assets/clsx-CjueKrWZ.js",
			"/assets/createLucideIcon-B68HukcN.js",
			"/assets/usage-log-Br56MF8-.js"
		]
	},
	"/_authenticated/dashboard": {
		filePath: "E:/universal-tool/src/routes/_authenticated/dashboard.tsx",
		children: void 0,
		preloads: [
			"/assets/dashboard-PucdH6ib.js",
			"/assets/Layout-DE4XmbcJ.js",
			"/assets/usage-limits-TEVxzN-i.js"
		]
	},
	"/tools/code": {
		filePath: "E:/universal-tool/src/routes/tools.code.tsx",
		children: void 0,
		preloads: [
			"/assets/tools.code-VS-6QnCO.js",
			"/assets/Layout-DE4XmbcJ.js",
			"/assets/purify.es-ZPrpXrUc.js",
			"/assets/Reveal-BeD4HdPn.js",
			"/assets/usage-tracking-gxCMe9A2.js",
			"/assets/CopyDownload-CnK5R-Lh.js"
		]
	},
	"/tools/color": {
		filePath: "E:/universal-tool/src/routes/tools.color.tsx",
		children: void 0,
		preloads: [
			"/assets/tools.color-BBxqx71i.js",
			"/assets/Layout-DE4XmbcJ.js",
			"/assets/Reveal-BeD4HdPn.js",
			"/assets/usage-tracking-gxCMe9A2.js",
			"/assets/CopyDownload-CnK5R-Lh.js"
		]
	},
	"/tools/image": {
		filePath: "E:/universal-tool/src/routes/tools.image.tsx",
		children: void 0,
		preloads: [
			"/assets/tools.image-Dd_07AK2.js",
			"/assets/Layout-DE4XmbcJ.js",
			"/assets/use-metered-category-D8VsiMHa.js",
			"/assets/Reveal-BeD4HdPn.js",
			"/assets/usage-tracking-gxCMe9A2.js",
			"/assets/Skeleton-Dt6SQh3g.js"
		]
	},
	"/tools/password": {
		filePath: "E:/universal-tool/src/routes/tools.password.tsx",
		children: void 0,
		preloads: [
			"/assets/tools.password-DpEvncBB.js",
			"/assets/Layout-DE4XmbcJ.js",
			"/assets/Reveal-BeD4HdPn.js",
			"/assets/usage-tracking-gxCMe9A2.js",
			"/assets/CopyDownload-CnK5R-Lh.js"
		]
	},
	"/tools/pdf": {
		filePath: "E:/universal-tool/src/routes/tools.pdf.tsx",
		children: void 0,
		preloads: [
			"/assets/tools.pdf-D7dprw40.js",
			"/assets/Layout-DE4XmbcJ.js",
			"/assets/use-metered-category-D8VsiMHa.js",
			"/assets/Reveal-BeD4HdPn.js",
			"/assets/usage-tracking-gxCMe9A2.js",
			"/assets/Skeleton-Dt6SQh3g.js"
		]
	},
	"/tools/productivity": {
		filePath: "E:/universal-tool/src/routes/tools.productivity.tsx",
		children: void 0,
		preloads: [
			"/assets/tools.productivity-CKSxBdit.js",
			"/assets/Layout-DE4XmbcJ.js",
			"/assets/Reveal-BeD4HdPn.js",
			"/assets/usage-tracking-gxCMe9A2.js",
			"/assets/CopyDownload-CnK5R-Lh.js"
		]
	},
	"/tools/text": {
		filePath: "E:/universal-tool/src/routes/tools.text.tsx",
		children: void 0,
		preloads: [
			"/assets/tools.text-CY5I-RV1.js",
			"/assets/Layout-DE4XmbcJ.js",
			"/assets/Reveal-BeD4HdPn.js",
			"/assets/usage-tracking-gxCMe9A2.js",
			"/assets/Skeleton-Dt6SQh3g.js",
			"/assets/CopyDownload-CnK5R-Lh.js"
		]
	},
	"/_authenticated/_admin/admin": {
		filePath: "E:/universal-tool/src/routes/_authenticated/_admin/admin.tsx",
		children: void 0,
		preloads: ["/assets/admin-B4xi2XAy.js", "/assets/Layout-DE4XmbcJ.js"]
	},
	"/_authenticated/_admin/profile": {
		filePath: "E:/universal-tool/src/routes/_authenticated/_admin/profile.tsx",
		children: void 0,
		preloads: [
			"/assets/profile-B8wUN9CC.js",
			"/assets/Layout-DE4XmbcJ.js",
			"/assets/sweetalert2.all-D3CpTGPs.js"
		]
	}
} });
//#endregion
export { tsrStartManifest };
