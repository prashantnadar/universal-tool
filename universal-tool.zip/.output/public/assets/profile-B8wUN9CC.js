import{o as e}from"./rolldown-runtime-DAXXjFlN.js";import{c as t,q as n}from"./useStore-PiVi24NI.js";import{n as r}from"./client-CjF64JdE.js";import{a as i,c as a,i as o,o as s,r as c,s as l,t as u}from"./Layout-DE4XmbcJ.js";import{o as d}from"./index-1K1CYJ4G.js";import{t as f}from"./sweetalert2.all-D3CpTGPs.js";var p=e(n()),m=e(f()),h=t();function g(){let{user:e,role:t,plan:n,isAdmin:f,signOut:g,refresh:_}=d(),[v,y]=(0,p.useState)(null),[b,x]=(0,p.useState)(``),[S,C]=(0,p.useState)(!0),[w,T]=(0,p.useState)(!1),[E,D]=(0,p.useState)(!1),[O,k]=(0,p.useState)({totalToolsUsed:0,todayUsage:0,lastToolUsed:null}),A=e?.id===`f0a17059-c9ac-46e1-859c-82bd1487f069`;(0,p.useEffect)(()=>{j()},[]);async function j(){try{C(!0);let[t,n]=await Promise.all([i(),s()]);y(t),k(n),x(t.display_name??e?.user_metadata?.display_name??``)}catch(e){m.default.fire({icon:`error`,title:`Unable to load profile`,text:e.message})}finally{C(!1)}}let M=(0,p.useMemo)(()=>v?.avatar_url?v.avatar_url:null,[v]);async function N(){if(!b.trim()){m.default.fire({icon:`warning`,title:`Display name required`});return}try{T(!0),await l(b),await _(),await j(),m.default.fire({icon:`success`,title:`Profile Updated`,timer:1500,showConfirmButton:!1})}catch(e){m.default.fire({icon:`error`,title:`Update Failed`,text:e.message})}finally{T(!1)}}async function P(e){let t=e.target.files?.[0];if(t)try{D(!0),console.log(`1`);let e=await a(t);window.dispatchEvent(new Event(`avatar-updated`)),console.log(`2`),y(t=>t&&{...t,avatar_url:e}),console.log(`3`),await _(),window.dispatchEvent(new Event(`avatar-updated`)),console.log(`4`),m.default.fire({icon:`success`,title:`Avatar Updated`,timer:1500,showConfirmButton:!1})}catch(e){console.error(e),m.default.fire({icon:`error`,title:`Upload Failed`,text:String(e)})}finally{console.log(`5`),D(!1)}}async function F(){let{value:e}=await m.default.fire({title:`Change Password`,html:`
      <div style="text-align:left">

        <div style="position:relative;margin-bottom:12px;">
          <input
            id="new-password"
            type="password"
            class="swal2-input"
            placeholder="New Password"
            style="width:100%;margin:0;padding-right:45px;"
          />
       <button
  id="toggle-new-password"
  type="button"
  style="
    position:absolute;
    right:12px;
    top:50%;
    transform:translateY(-50%);
    border:none;
    background:none;
    cursor:pointer;
    color:#64748b;
  "
  aria-label="Show password"
>
  <svg width="18" height="18" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2">
    <path d="M1 12s4-8 11-8 11 8 11 8-4 8-11 8S1 12 1 12z"/>
    <circle cx="12" cy="12" r="3"/>
  </svg>
</button>
        </div>

        <div style="position:relative;">
          <input
            id="confirm-password"
            type="password"
            class="swal2-input"
            placeholder="Confirm Password"
            style="width:100%;margin:0;padding-right:45px;"
          />
          <button
  id="toggle-confirm-password"
  type="button"
  style="
    position:absolute;
    right:12px;
    top:50%;
    transform:translateY(-50%);
    border:none;
    background:none;
    cursor:pointer;
    color:#64748b;
  "
  aria-label="Show password"
>
  <svg width="18" height="18" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2">
    <path d="M1 12s4-8 11-8 11 8 11 8-4 8-11 8S1 12 1 12z"/>
    <circle cx="12" cy="12" r="3"/>
  </svg>
</button>
        </div>

        <p style="margin-top:12px;font-size:12px;color:#64748b;">
          8–20 characters with uppercase, lowercase, number & special character.
        </p>

      </div>
    `,showCancelButton:!0,confirmButtonText:`Update Password`,focusConfirm:!1,didOpen:()=>{let e=document.getElementById(`new-password`),t=document.getElementById(`confirm-password`);document.getElementById(`toggle-new-password`)?.addEventListener(`click`,()=>{e.type=e.type===`password`?`text`:`password`}),document.getElementById(`toggle-confirm-password`)?.addEventListener(`click`,()=>{t.type=t.type===`password`?`text`:`password`})},preConfirm:()=>{let e=document.getElementById(`new-password`).value.trim(),t=document.getElementById(`confirm-password`).value.trim();if(!/^(?=.*[a-z])(?=.*[A-Z])(?=.*\d)(?=.*[!@#$%^&*(),.?":{}|<>_\-+=/\\[\]]).{8,20}$/.test(e)){m.default.showValidationMessage(`Password must be 8–20 characters and include uppercase, lowercase, number and special character.`);return}if(e!==t){m.default.showValidationMessage(`Passwords do not match.`);return}return e}});if(e)try{await c(e),await m.default.fire({icon:`success`,title:`Password Changed`,text:`Your password has been updated successfully.`})}catch(e){await m.default.fire({icon:`error`,title:`Unable to change password`,text:e.message})}}async function I(){(await m.default.fire({title:`Logout?`,text:`You will need to login again.`,icon:`question`,showCancelButton:!0,confirmButtonText:`Logout`})).isConfirmed&&await g()}async function L(){let{value:e}=await m.default.fire({icon:`warning`,title:`Delete Account`,html:`
            <p style="margin-bottom:12px">
                This action is permanent and cannot be undone.
            </p>

            <p style="margin-bottom:12px">
                Type <b>DELETE</b> below to continue.
            </p>
        `,input:`text`,inputPlaceholder:`Type DELETE`,confirmButtonText:`Delete Account`,confirmButtonColor:`#dc2626`,showCancelButton:!0});if(e===`DELETE`)try{await o(),await m.default.fire({icon:`success`,title:`Account Deleted`,text:`Your account has been deleted successfully.`}),await g()}catch(e){m.default.fire({icon:`error`,title:`Delete Failed`,text:e.message})}}return S?(0,h.jsx)(u,{children:(0,h.jsx)(`section`,{className:`mx-auto max-w-5xl px-4 py-10`,children:(0,h.jsxs)(`div`,{className:`space-y-4 animate-pulse`,children:[(0,h.jsx)(`div`,{className:`h-10 w-64 rounded bg-slate-200 dark:bg-slate-700`}),(0,h.jsx)(`div`,{className:`h-72 rounded-xl bg-slate-200 dark:bg-slate-700`}),(0,h.jsx)(`div`,{className:`h-60 rounded-xl bg-slate-200 dark:bg-slate-700`})]})})}):(0,h.jsx)(u,{children:(0,h.jsxs)(`section`,{className:`mx-auto max-w-5xl px-4 py-10`,children:[(0,h.jsxs)(`div`,{className:`mb-8 flex items-center justify-between`,children:[(0,h.jsxs)(`div`,{children:[(0,h.jsx)(`h1`,{className:`text-3xl font-bold text-slate-900 dark:text-white`,style:{fontFamily:`'Space Grotesk', sans-serif`},children:`My Profile`}),(0,h.jsx)(`p`,{className:`mt-2 text-sm text-slate-500`,children:`Manage your Universal Tools account.`})]}),(0,h.jsxs)(`div`,{className:`flex gap-3`,children:[(0,h.jsx)(`button`,{onClick:I,className:`rounded-lg border border-red-300 px-4 py-2 text-sm font-medium text-red-600 hover:bg-red-50 dark:border-red-800 dark:hover:bg-red-950`,children:`Logout`}),(0,h.jsx)(r,{to:`/dashboard`,className:`rounded-lg border border-slate-200 px-4 py-2 text-sm hover:bg-slate-100 dark:border-slate-700 dark:hover:bg-slate-800`,children:`Back`})]})]}),(0,h.jsxs)(`div`,{className:`grid gap-6 lg:grid-cols-3`,children:[(0,h.jsx)(`div`,{className:`rounded-2xl border border-slate-200 bg-white p-6 shadow-sm dark:border-slate-800 dark:bg-slate-900`,children:(0,h.jsxs)(`div`,{className:`flex flex-col items-center`,children:[M?(0,h.jsx)(`img`,{src:M,alt:`Avatar`,className:`h-28 w-28 rounded-full border-4 border-blue-500 object-cover`}):(0,h.jsx)(`div`,{className:`flex h-28 w-28 items-center justify-center rounded-full bg-blue-600 text-4xl font-bold text-white`,children:b.charAt(0).toUpperCase()}),(0,h.jsxs)(`label`,{className:`mt-4 cursor-pointer rounded-lg bg-blue-600 px-4 py-2 text-sm font-semibold text-white hover:bg-blue-700`,children:[E?`Uploading...`:`Upload Avatar`,(0,h.jsx)(`input`,{hidden:!0,type:`file`,accept:`image/*`,onChange:P})]}),(0,h.jsx)(`h2`,{className:`mt-6 text-center text-xl font-bold text-slate-900 dark:text-white`,children:b}),(0,h.jsx)(`p`,{className:`mt-2 break-all text-center text-sm text-slate-500`,children:e?.email}),(0,h.jsxs)(`div`,{className:`mt-5 flex flex-wrap justify-center gap-2`,children:[A?(0,h.jsx)(`span`,{className:`rounded-full bg-blue-400 dark:bg-blue-500 px-2 py-1 text-xs font-bold text-white dark:text-white animate-pulse`,children:`👑 SUPER ADMIN`}):f?(0,h.jsx)(`span`,{className:`rounded-full bg-blue-600 px-3 py-1 text-xs font-semibold text-white`,children:`ADMIN`}):(0,h.jsx)(`span`,{className:`rounded-full bg-slate-200 px-3 py-1 text-xs font-semibold dark:bg-slate-700`,children:`USER`}),(0,h.jsx)(`span`,{className:`rounded-full px-3 py-1 text-xs font-semibold ${n===`premium`?`bg-emerald-600 text-white`:`bg-slate-200 dark:bg-slate-700`}`,children:n.toUpperCase()})]})]})}),(0,h.jsxs)(`div`,{className:`space-y-6 lg:col-span-2`,children:[(0,h.jsxs)(`div`,{className:`rounded-2xl border border-slate-200 bg-white p-6 shadow-sm dark:border-slate-800 dark:bg-slate-900`,children:[(0,h.jsx)(`h2`,{className:`text-lg font-semibold text-slate-900 dark:text-white`,children:`Account Information`}),(0,h.jsxs)(`div`,{className:`mt-6 grid gap-5`,children:[(0,h.jsxs)(`div`,{children:[(0,h.jsxs)(`label`,{className:`text-xs font-semibold uppercase text-slate-500`,children:[`Name\xA0`,(0,h.jsx)(`span`,{children:`(${b.length} / 20)`})]}),(0,h.jsx)(`input`,{value:b,placeholder:`Enter your name`,maxLength:20,onChange:e=>x(e.target.value),className:`mt-2 w-full rounded-lg border border-slate-300 bg-white px-4 py-3 outline-none focus:border-blue-500 dark:border-slate-700 dark:bg-slate-800`})]}),(0,h.jsxs)(`div`,{children:[(0,h.jsx)(`label`,{className:`text-xs font-semibold uppercase text-slate-500`,children:`Email`}),(0,h.jsx)(`div`,{className:`mt-2 rounded-lg border border-slate-200 bg-slate-50 px-4 py-3 break-all dark:border-slate-700 dark:bg-slate-800 cursor-not-allowed`,children:v?.email??e?.email})]}),(0,h.jsxs)(`div`,{className:`grid gap-4 md:grid-cols-2`,children:[(0,h.jsxs)(`div`,{children:[(0,h.jsx)(`label`,{className:`text-xs font-semibold uppercase text-slate-500`,children:`Role`}),(0,h.jsx)(`div`,{className:`mt-2 rounded-lg border border-slate-200 bg-slate-50 px-4 py-3 dark:border-slate-700 dark:bg-slate-800 cursor-not-allowed`,children:t?.toUpperCase()})]}),(0,h.jsxs)(`div`,{children:[(0,h.jsx)(`label`,{className:`text-xs font-semibold uppercase text-slate-500`,children:`Current Plan`}),(0,h.jsx)(`div`,{className:`mt-2 rounded-lg border border-slate-200 bg-slate-50 px-4 py-3 dark:border-slate-700 dark:bg-slate-800 cursor-not-allowed`,children:n.toUpperCase()})]})]}),(0,h.jsx)(`button`,{onClick:N,disabled:w,className:`rounded-lg bg-blue-600 px-5 py-3 font-semibold text-white transition hover:bg-blue-700 disabled:opacity-50`,children:w?`Saving...`:`Save Profile`})]})]}),(0,h.jsxs)(`div`,{className:`rounded-2xl border border-slate-200 bg-white p-6 shadow-sm dark:border-slate-800 dark:bg-slate-900`,children:[(0,h.jsxs)(`div`,{className:`flex items-center justify-between`,children:[(0,h.jsxs)(`div`,{children:[(0,h.jsx)(`h2`,{className:`text-lg font-semibold text-slate-900 dark:text-white`,children:`Subscription`}),(0,h.jsx)(`p`,{className:`mt-2 text-sm text-slate-500`,children:`Your current subscription plan.`})]}),n!==`premium`&&(0,h.jsx)(r,{to:`/pricing`,className:`rounded-lg bg-blue-600 px-5 py-2 text-sm font-semibold text-white hover:bg-blue-700`,children:`Upgrade`})]}),(0,h.jsxs)(`div`,{className:`mt-6 grid gap-4 sm:grid-cols-2`,children:[(0,h.jsxs)(`div`,{className:`rounded-xl border border-slate-200 p-5 dark:border-slate-700`,children:[(0,h.jsx)(`p`,{className:`text-xs uppercase text-slate-500`,children:`Current Plan`}),(0,h.jsx)(`h3`,{className:`mt-2 text-2xl font-bold`,children:n===`premium`?`💎 Premium`:`🆓 Free`})]}),(0,h.jsxs)(`div`,{className:`rounded-xl border border-slate-200 p-5 dark:border-slate-700`,children:[(0,h.jsx)(`p`,{className:`text-xs uppercase text-slate-500`,children:`Account Status`}),(0,h.jsx)(`h3`,{className:`mt-2 text-2xl font-bold text-emerald-600`,children:`Active`})]})]})]}),(0,h.jsxs)(`div`,{className:`rounded-2xl border border-slate-200 bg-white p-6 shadow-sm dark:border-slate-800 dark:bg-slate-900`,children:[(0,h.jsx)(`h2`,{className:`text-lg font-semibold text-slate-900 dark:text-white`,children:`Security`}),(0,h.jsx)(`p`,{className:`mt-2 text-sm text-slate-500`,children:`Change your account password securely.`}),(0,h.jsx)(`button`,{onClick:F,className:`mt-5 rounded-lg border border-slate-300 px-5 py-3 text-sm font-semibold hover:bg-slate-100 dark:border-slate-700 dark:hover:bg-slate-800`,children:`Change Password`})]}),(0,h.jsxs)(`div`,{className:`rounded-2xl border border-slate-200 bg-white p-6 shadow-sm dark:border-slate-800 dark:bg-slate-900`,children:[(0,h.jsx)(`h2`,{className:`text-lg font-semibold text-slate-900 dark:text-white`,children:`Usage Information`}),(0,h.jsxs)(`div`,{className:`mt-6 grid gap-4 md:grid-cols-2 xl:grid-cols-4`,children:[(0,h.jsxs)(`div`,{className:`rounded-xl border border-slate-200 p-4 dark:border-slate-700`,children:[(0,h.jsx)(`div`,{className:`text-xs uppercase text-slate-500`,children:`Total Tools Used`}),(0,h.jsx)(`div`,{className:`mt-2 text-2xl font-bold`,children:O.totalToolsUsed})]}),(0,h.jsxs)(`div`,{className:`rounded-xl border border-slate-200 p-4 dark:border-slate-700`,children:[(0,h.jsx)(`div`,{className:`text-xs uppercase text-slate-500`,children:`Today's Usage`}),(0,h.jsx)(`div`,{className:`mt-2 text-2xl font-bold`,children:O.todayUsage})]}),(0,h.jsxs)(`div`,{className:`rounded-xl border border-slate-200 p-4 dark:border-slate-700`,children:[(0,h.jsx)(`div`,{className:`text-xs uppercase text-slate-500`,children:`Last Tool Used`}),(0,h.jsx)(`div`,{className:`mt-2 break-words text-sm font-semibold`,children:O.lastToolUsed??`No usage yet`})]}),(0,h.jsxs)(`div`,{className:`rounded-xl border border-slate-200 p-4 dark:border-slate-700`,children:[(0,h.jsx)(`div`,{className:`text-xs uppercase text-slate-500`,children:`Current Plan`}),(0,h.jsx)(`div`,{className:`mt-2 text-xl font-bold`,children:n===`premium`?`💎 Premium`:`🆓 Free`})]})]})]}),(0,h.jsxs)(`div`,{className:`rounded-2xl border border-red-300 bg-red-50 p-6 shadow-sm dark:border-red-900 dark:bg-red-950/20`,children:[(0,h.jsx)(`h2`,{className:`text-lg font-bold text-red-600`,children:`⚠ Danger Zone`}),(0,h.jsx)(`p`,{className:`mt-2 text-sm text-slate-600 dark:text-slate-400`,children:`Permanently delete your account, avatar, profile, subscriptions, usage history and all associated data. This action cannot be undone.`}),(0,h.jsx)(`button`,{onClick:L,className:`mt-6 rounded-lg bg-red-600 px-5 py-3 font-semibold text-white hover:bg-red-700`,children:`Delete Account`})]})]})]})]})})}export{g as component};